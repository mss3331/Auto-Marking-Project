//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include <stdlib.h>
#include <string.h>
#include<time.h>

#define MAXBUF		256
void func(int clientfd);

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    struct sockaddr_in self;

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

    printf("Socket created.\n");
    int MY_PORT;
    printf("Networking 1>start server: ");
    scanf("%d",&MY_PORT);
    printf("Port Number= %d.\n",MY_PORT);

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}

    puts("Waiting for incoming connections...");
    struct sockaddr_in client_addr;
    int addrlen=sizeof(client_addr);
    clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
    printf("Connection accepted from %s:%d\n", inet_ntoa(self.sin_addr), ntohs(self.sin_port));
    func(clientfd);
    /*---close connection---*/
	close(clientfd);


	/*---clean up (should never get here!)---*/
	close(sockfd);
    WSACleanup();
	return 0;
	}


void func(int clientfd){
    int n=0,numD=0,numD1=0,numD2=0,numD3=0;
    for (;;){
        char buff[MAXBUF],check[]="exit server",checkD[]="date",checkD1[]="date1",checkD2[]="date2",checkD3[]="date3";
        int thing=recv(clientfd, buff, MAXBUF, 0);
        for (int x=0;x<strlen(check);x++){
            n=buff[x]-check[x];
            if (n!=0){
                break;
            }
        }
        for (int x=0;x<thing;x++){
            numD=buff[x]-checkD[x];
            if (numD!=0){
                break;
            }
        }
        for (int x=0;x<thing;x++){
            numD1=buff[x]-checkD1[x];
            if (numD1!=0){
                break;
            }
        }
        for (int x=0;x<thing;x++){
            numD2=buff[x]-checkD2[x];
            if (numD2!=0){
                break;
            }
        }
        for (int x=0;x<thing;x++){
            numD3=buff[x]-checkD3[x];
            if (numD3!=0){
                break;
            }
        }
        if (numD==0){
            int temp;
            char day[10];
            time_t t;
            t = time(NULL);
            struct tm tm = *localtime(&t);
            temp=tm.tm_mday;
            sprintf(day,"%d",temp);
            send(clientfd,day,sizeof(char)*2,0);
            send(clientfd,"-",sizeof(char),0);
            temp=tm.tm_mon+1;
            sprintf(day,"%d",temp);
            send(clientfd,day,sizeof(char)*2,0);
            send(clientfd,"-",sizeof(char),0);
            temp=tm.tm_year+90;
            sprintf(day,"%d",temp);
            send(clientfd,day,sizeof(char)*2,0);
            temp=tm.tm_hour;
            sprintf(day,"%d",temp);
            send(clientfd," ",sizeof(char),0);
            send(clientfd,day,sizeof(char)*2,0);
        }
        else if (numD1==0){
            int temp;
            char day[10];
            time_t t;
            t = time(NULL);
            struct tm tm = *localtime(&t);
            temp=tm.tm_year+1900;
            sprintf(day,"%d",temp);
            send(clientfd,day,sizeof(char)*4,0);
        }
        else if (numD2==0){
            int temp;
            char day[10];
            time_t t;
            t = time(NULL);
            struct tm tm = *localtime(&t);
            temp=tm.tm_hour;
            sprintf(day,"%d",temp);
            send(clientfd,day,sizeof(char)*2,0);
        }
        else if (numD3==0){
            int temp;
            char day[10];
            time_t t;
            t = time(NULL);
            struct tm tm = *localtime(&t);
            temp=tm.tm_mday;
            sprintf(day,"%d",temp);
            send(clientfd,day,sizeof(char)*2,0);
            send(clientfd,"-",sizeof(char),0);
            temp=tm.tm_mon+1;
            switch(temp)
            {
                case 1:
                    send(clientfd,"Jan-",sizeof(char)*4,0);
                    break;
                case 2:
                    send(clientfd,"Feb-",sizeof(char)*4,0);
                    break;
                case 3:
                    send(clientfd,"Mar-",sizeof(char)*4,0);
                    break;
                case 4:
                    send(clientfd,"Apr-",sizeof(char)*4,0);
                    break;
                case 5:
                    send(clientfd,"May-",sizeof(char)*4,0);
                    break;
                case 6:
                    send(clientfd,"Jun-",sizeof(char)*4,0);
                    break;
                case 7:
                    send(clientfd,"Jul-",sizeof(char)*4,0);
                    break;
                case 8:
                    send(clientfd,"Aug-",sizeof(char)*4,0);
                    break;
                case 9:
                    send(clientfd,"Sep-",sizeof(char)*4,0);
                    break;
                case 10:
                    send(clientfd,"Oct-",sizeof(char)*4,0);
                    break;
                case 11:
                    send(clientfd,"Nov-",sizeof(char)*4,0);
                    break;
                case 12:
                    send(clientfd,"Dec-",sizeof(char)*4,0);
                    break;
            }
            temp=tm.tm_year+90;
            sprintf(day,"%d",temp);
            send(clientfd,day,sizeof(char)*2,0);
        }
        else if (n!=0&numD!=0&numD1!=0&numD2!=0){
            for (int x=0;x<thing;x++){
                if((buff[x]>='a')&&(buff[x]<='z')){
                    buff[x]-=32;
                }
            }
            printf("\nmessage length: %d",thing);
            send(clientfd, buff, thing,0);
        }
        else {
            break;
        }
    }
}




