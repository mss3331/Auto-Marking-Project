#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include <stdlib.h>
#include <string.h>

#define MAXBUF		256
void func(int serverfd);
int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd;
    struct sockaddr_in self;

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
	sockfd= socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0 )
	{
		perror("Socket");
		exit(errno);
	}

    printf("Socket created.\n");
    int MY_PORT;
    printf("Networking 1>start client: ");
    scanf("%d",&MY_PORT);
    printf("Port Number= %d\n",MY_PORT);

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = inet_addr("127.0.0.1");
    connect(sockfd,(struct sockaddr*)&self,sizeof(self));
    printf("connected\n");
    func(sockfd);
	/*---clean up (should never get here!)---*/
	close(sockfd);
    WSACleanup();
	return 0;

}
void func(int serverfd){
    char message[MAXBUF],server_reply[MAXBUF];
    int n;
    while(1){
        printf("Please enter your string: ");
        fgets(message, sizeof(message), stdin);
        char temp[MAXBUF];
        for(int x=0;x<strlen(message);x++){
            if (message[x]==10){
                temp[x]='\0';
            }
            else{
                temp[x]=message[x];
            }
        }
        if (strcmp(temp,"exit client")==0){
            break;
        }
        else{
        send(serverfd,message,strlen(message),0);
        n=recv(serverfd,server_reply,MAXBUF,0);
        server_reply[n]='\0';
		printf("%s\n",server_reply);
		}
    }
}
