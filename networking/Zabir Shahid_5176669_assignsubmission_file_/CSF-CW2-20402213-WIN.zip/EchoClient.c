
#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include <string.h>

int main(int argc , char *argv[])
{
	WSADATA wsa;
	SOCKET sockfd;
	struct sockaddr_in server;
	char buffer[256], server_reply[256]; //character array to hold messages from user and server

	printf("\nInitialising Winsock...");
	if (WSAStartup(MAKEWORD(2,2),&wsa) != 0) //initializing socket
	{
		printf("Failed. Error Code : %d",WSAGetLastError());
		return 1;
	}
	
	printf("Initialised.\n");
	
	//Create a socket
	if((sockfd = socket(AF_INET , SOCK_STREAM , 0 )) == INVALID_SOCKET)
	{
		printf("Could not create socket : %d" , WSAGetLastError());
	}

	printf("Socket created.\n");
	int port; //integer variable to hold port number
	printf("Enter server port number\n");
	scanf("%d",&port); //takes port number input from user
	
	
	server.sin_addr.s_addr = inet_addr("127.0.0.1"); //local ip address
	server.sin_family = AF_INET;
	server.sin_port = htons( port ); //server port number

	//Connect to remote server
	if (connect(sockfd , (struct sockaddr *)&server , sizeof(server)) < 0) //connects to server or shows error if failed
	{
		puts("connect error");
		return 1;
	}
	printf("connected");
	
	//Send some data
	while(1){
	memset(buffer, 0, sizeof(buffer)); //clear buffer
	gets(buffer); //takes message input from user

	if(strcasecmp("exit client",buffer)==0){ //break loop and close connection if user inputs exit client
		break;
	}
	send(sockfd , buffer , sizeof(buffer),0); //send message to server
	recv(sockfd, server_reply , 256 , 0); //receive message from server
	
	
	puts(server_reply); //display server response
	}
	close(sockfd); //closes and terminates connection to server
	WSACleanup();

	return 0;
}