//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include <stdlib.h>
#include <string.h>

#define MAXBUF		256

int main(int argc , char *argv[])
{	int string;
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    struct sockaddr_in self;
	char buffer[MAXBUF];

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");
	//port=atoi(argv[1]);
	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	//bzero(&self, sizeof(self));
	int port;
	port=atoi(argv[3]);
	self.sin_family = AF_INET;
	self.sin_port = htons(port);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	/*---forever... ---*/

while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		printf("IP address is: %s\n", inet_ntoa(client_addr.sin_addr)); //displaying ip address and port number
		printf("port is: %d\n",port);
		while(1){
		memset(buffer, 0, sizeof(buffer)); //clear buffer
		int recv_size=recv(clientfd, buffer, MAXBUF, 0); //receive message from server
		
		if (buffer[0] != '\r')
		{
		printf("The message length is %d\n",strlen(buffer)); //display message length if message is sent by user
		}
		
		strupr (buffer); //convert message to uppercase
		printf("\n");
		if(strcasecmp("exit server",buffer)==0) //break loop and close/terminate connection if user inputs exit server
		{
		break;
		}
		send(clientfd, buffer,recv_size, 0); //send converted message to client
		}

		/*---close connection---*/
		close(clientfd);
	}


	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}