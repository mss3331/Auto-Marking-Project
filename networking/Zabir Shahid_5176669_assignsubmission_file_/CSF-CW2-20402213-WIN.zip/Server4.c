//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    struct sockaddr_in self;
	char buffer[MAXBUF]; //character array to hold message

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");
	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	//bzero(&self, sizeof(self));
	int port; //int variable to hold port number
	port=atoi(argv[3]);
	self.sin_family = AF_INET;
	self.sin_port = htons(port);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 ) //wait for connection
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	time_t seconds=time(NULL); //time variables to calculate time
    struct tm* current_time=localtime(&seconds); 
	char month[4]; //character array to hold month name



	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		printf("IP address is: %s\n", inet_ntoa(client_addr.sin_addr)); //display ip address and port number
		printf("port is: %d\n",port);
		while(1){
		memset(buffer, 0, sizeof(buffer)); //clear buffer
		int recv_size=recv(clientfd, buffer, MAXBUF, 0); //receive message from client
		if (buffer[0] != '\r'){
		printf("The message length is %d\n",strlen(buffer));} //display message length if message is from user client
		strupr (buffer); //convert message to uppercase
		printf("\n");
		if(strcasecmp("exit server",buffer)==0) //break out of loop and terminate connection if client inputs exit server
		{
		break;
		}
		if(strcasecmp("date",buffer)==0){ //send current date and hour as message to client if client inputs date
		snprintf(buffer, 20, "%d-%d-%d %d\r\n",(current_time->tm_mday),(current_time->tm_mon+1),(current_time->tm_year -100),(current_time->tm_hour));
		send(clientfd, buffer,sizeof(buffer), 0);
		continue;
		}
		if(strcasecmp("date1",buffer)==0){ //send current year as message if client inputs date1
		snprintf(buffer, 20, "%d\r\n",(current_time->tm_year +1900));
		send(clientfd, buffer,sizeof(buffer), 0);
		continue;
		}
		if(strcasecmp("date2",buffer)==0){ //send current hour of the day as message if client inputs date 2
		snprintf(buffer, 5, " %d\r\n",(current_time->tm_hour));
		send(clientfd, buffer,sizeof(buffer), 0);
		continue;
		}
		if(strcasecmp("date3",buffer)==0){ //send date in the format dd-mon-yy if client inputs date 3 
		strftime(month,sizeof(month),"%b",current_time);
		snprintf(buffer, 20, "%d-%s-%d\r\n",(current_time->tm_mday),month,(current_time->tm_year -100));
		send(clientfd, buffer,sizeof(buffer), 0);
		continue;
		}
		
		send(clientfd, buffer,recv_size, 0);
		}

		/*---close connection---*/
		close(clientfd);
	}


	/*---clean up (should never get here!)---*/
		close(sockfd);
        WSACleanup();
	return 0;
}