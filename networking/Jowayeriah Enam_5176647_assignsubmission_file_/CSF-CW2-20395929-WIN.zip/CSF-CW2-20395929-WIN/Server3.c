#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include <ctype.h>
#include <windows.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#define MY_PORT     8989
#define MAXBUF		256

int main(int argc, char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd, clientfd;
    struct sockaddr_in self;
    char buffer[MAXBUF], set[100];
    //char clientaddr[16];  the clientaddr will store the IPv4
    int size;
    time_t t = time(NULL); //pass variable to point to current time
    struct tm *tmdt= localtime(&t);//using the structure to get current time and date

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

    /*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
    {
        perror("Socket");
        exit(errno);
    }

    printf("Socket created.\n");

    /*---initialize address/port structure---*/
    /* bzero(&self, sizeof(self));*/

    self.sin_family = AF_INET;
    self.sin_port = htons(MY_PORT);	// Host to Network Short (16-bit)
    self.sin_addr.s_addr = inet_addr("127.0.0.1");

    /*---assign a port number to the socket---*/
    //establish connection
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
    {
        perror("socket--bind");
        exit(errno);
    }

    puts("Bind done");

    /*---make it a "listening socket"---*/
    if ( listen(sockfd, 20) != 0 )
    {
        perror("socket--listen");
        exit(errno);
    }

    puts("Waiting for incoming connections...");

    /*---forever... ---*/
    //modify message to uppercase
    while (1)
    {
        struct sockaddr_in client_addr;
        int addrlen=sizeof(client_addr);

        /*---accept a connection (creating a data pipe)---*/
        clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
        while (size!=0)
        {
            printf("\nThe IP address is: %s\n", inet_ntoa(client_addr.sin_addr)); //finding ip address
            // finding the port number through client
            printf("The port number is: %d\n\n", ntohs(client_addr.sin_port));
            size=recv(clientfd, buffer, MAXBUF, 0);
            buffer[size]= '\0';
            for (int i=0; i<size; i++)
            {
                buffer[i]=toupper(buffer[i]);
            }
            if (strcmp(buffer, "DATE")==0){
                strftime(set, sizeof(set), "%d/%m/%y %H",tmdt);// set the date format within set
                printf("Today's date with time is: %s \r\n", set);
            }
            if (strcmp(buffer, "EXIT SERVER")!=0)
            {
                printf("The length of the message is: %d\n", strlen(buffer));
                send(clientfd, buffer, size, 0);
            }
            else{
                printf("Disconnected\n");
                close(clientfd);
                break;
            }
            recv(clientfd, buffer, MAXBUF, 0);
        }
    }

    /*---clean up (should never get here!)---*/
    close(sockfd);
    WSACleanup();
    return 0;
}

