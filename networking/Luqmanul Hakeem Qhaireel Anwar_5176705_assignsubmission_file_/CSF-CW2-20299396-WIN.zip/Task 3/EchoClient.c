//////////////////////////  Client.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#pragma comment(lib,"ws2_32.lib") //Winsock Library

#define MY_PORT		8989
#define MAXBUF		256

int main(int argc , char *argv[])
{
	char* localhost = "127.0.0.1";
	int i;
    WSADATA wsa;
    SOCKET server_socket;
   	struct sockaddr_in s;
	char buffer[256];

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create client socket---*/
    if ( (server_socket = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	s.sin_family = AF_INET;
	s.sin_port = htons(8989);	  // Host to Network Short (16-bit)
	s.sin_addr.s_addr = inet_addr(localhost);
	
	if(connect(server_socket,(struct sockaddr*)&s,sizeof(s)) < 0){
		printf("Error: %ld\n", WSAGetLastError());
		return 1;	
	}
	
	printf("Connected.\n");
	
	memset(buffer,0, 255); //empty buffer
	
	fgets(buffer,255,stdin); //gets user input and puts in buffer
	
	if(send(server_socket,buffer,strlen(buffer),0) == SOCKET_ERROR){
		printf("Error: %ld", WSAGetLastError());
		return 1;	
	}
	if(recv(server_socket,buffer,strlen(buffer),0) == SOCKET_ERROR){
		printf("Error: %ld", WSAGetLastError());
		return 1;	
	}
	printf("%s\n",buffer);
	
	
	closesocket(server_socket); 
	WSACleanup();
	return 0;
}
