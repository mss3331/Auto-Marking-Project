//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<ctype.h>

#define MAXBUF	256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];
	
	int MY_PORT;
	if(argc==2)
	{
		MY_PORT=atoi(argv[1]);
	}
	else {
		printf("wrong\n");
		return 1;
	}
	
    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;

	

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)

    {    

        struct sockaddr_in client_addr;

        int addrlen=sizeof(client_addr);

        int in;
        /*---accept a connection (creating a data pipe)---*/

        if((clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen)) > 0){



            printf("IP Address of Client is %s \n", inet_ntoa(client_addr.sin_addr));

            printf("Port number of Client is %d \n", ntohs(self.sin_port));

        }



        while(1){

            memset(buffer, 0, MAXBUF);

            in = recv(clientfd, buffer, MAXBUF, 0);

                if(strcmp(buffer, "exit server") == 0){

                    break;
                }

                if(in > 0){

                    if(buffer[0] != 13){

                            printf("The length of input is %d\n", strlen(buffer));

                    }
                    send(clientfd, strupr(buffer), in, 0);
            }
            else{
                break;

            }

        }



        /*---close connection---*/

        close(clientfd);

    }
	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}

