//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<time.h>

#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];
    size_t myPort;

    printf("Enter the port number that tickles your fancy:");
    scanf("%d",&myPort);

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");


	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(myPort);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");
	
		struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		
		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);

		printf("IP Address: %s\n",inet_ntoa(client_addr.sin_addr)); //display client IP
		printf("Port: %d\n",myPort); //display port number
        time_t myTime;
        struct tm tme;
        char* temp; //string 
	/*---forever... ---*/
	while (1)
	{
		buffer[recv(clientfd, buffer, MAXBUF, 0)]='\0'; //set NULL pointer to make it a proper string

        if (!strcmp(buffer,"exit server")) //exit if client input exit server
        break;
		else{
			if (buffer[0]!='\r'&&strcmp(buffer,"date")) //print length when string is not '\r'
			printf("Length:%d\n",strlen(buffer));

            if (!strcmp(buffer,"date")){  //if client inputs date 
                temp = malloc(20); //allocate memory for temp

                for (int i=0;i<MAXBUF;i++)  //re-initialise buffer
                buffer[i]='0';

                myTime = time(NULL);  //creating....
                tme = *localtime(&myTime);

                itoa(tme.tm_mday,buffer,10);
                strcat(buffer,"-");
                
                itoa(tme.tm_mon+1,temp,10);
                strcat(buffer,temp);
                strcat(buffer,"-");

                itoa(tme.tm_year%100,temp,10);
                strcat(buffer,temp);
                strcat(buffer," ");

                itoa(tme.tm_hour,temp,10);
                strcat(buffer,temp);   //...correct output

                send(clientfd, buffer, strlen(buffer), 0); //send the date and time

                free(temp); //free the allocated memory
            }
            else
			send(clientfd, strupr(buffer), strlen(buffer), 0); //standard upper case reply
		}
	}
	close(clientfd);
	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}

