//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>

#define MAXBUF		256

int main(int argc , char *argv[]){
    WSADATA wsa;
    int err;
    err = WSAStartup(MAKEWORD(2,2),&wsa); //startup client
    if (err){
        puts("Error Starting Up");
        return 0;
    }

    SOCKET s;
    s = socket(AF_INET,SOCK_STREAM,0); //create socket
    if (s==INVALID_SOCKET){
        printf("Error code:%d\n", WSAGetLastError());
        return 0;
    }
    else
    puts("Socket established!");

    int myPort;
    puts("Enter port number that you want to connect to.");
    scanf("%d\n",&myPort);

    struct sockaddr_in server; //initialise connection details

    server.sin_family=AF_INET;
    server.sin_port=htons(myPort);
    server.sin_addr.s_addr = inet_addr("127.0.0.1");

    connect(s,(struct sockaddr*)&server,sizeof(server));
    
    
    char buffer[MAXBUF];
    char reply[MAXBUF];

    while(1){
        gets(buffer); //get input

        if (!strcmp(buffer,"exit client")) //if user inputs exit client, break loop, exit
        break;

        send(s, buffer, strlen(buffer),0); //send msg to server
        
        reply[recv(s, reply, MAXBUF, 0)]='\0'; //catch server reply and set NULL terminator to make it a proper string

        printf("Server Reply:");
        puts(reply);    
    }

    close(s);
    WSACleanup();
}