//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<time.h>

#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];
    size_t myPort;

    printf("Enter the port number that tickles your fancy:");
    scanf("%d",&myPort);

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");


	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(myPort);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");
	
		struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		
		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);

		printf("IP Address: %s\n",inet_ntoa(client_addr.sin_addr)); //display client IP
		printf("Port: %d\n",myPort);   //display port number
        time_t myTime; 
        struct tm tme;
        char* temp;
	/*---forever... ---*/
	while (1)
	{
		buffer[recv(clientfd, buffer, MAXBUF, 0)]='\0';  //set NULL pointer to make it a proper string

        if (!strcmp(buffer,"exit server"))  //exit if client input exit server
        break;
		else{
			

            if (!strcmp(buffer,"date")){  //client input "date"
                temp = malloc(20);

                for (int i=0;i<MAXBUF;i++)
                buffer[i]='0';

                myTime = time(NULL);
                tme = *localtime(&myTime);

                itoa(tme.tm_mday,buffer,10);
                strcat(buffer,"-");
                
                itoa(tme.tm_mon+1,temp,10);
                strcat(buffer,temp);
                strcat(buffer,"-");

                itoa(tme.tm_year%100,temp,10);
                strcat(buffer,temp);
                strcat(buffer," ");

                itoa(tme.tm_hour,temp,10);
                strcat(buffer,temp);
                puts(buffer);

                send(clientfd, buffer, strlen(buffer), 0);

                free(temp);
            }
            else if (!strcmp(buffer,"date1")){  //client input "date1"

                for (int i=0;i<MAXBUF;i++)
                buffer[i]='0';

                myTime = time(NULL);
                tme = *localtime(&myTime);

                itoa(tme.tm_year+1900,buffer,10);

                send(clientfd, buffer, strlen(buffer), 0);
            }
            else if (!strcmp(buffer,"date2")){ //client input "date2"

                for (int i=0;i<MAXBUF;i++)
                buffer[i]='0';

                myTime = time(NULL);
                tme = *localtime(&myTime);

                itoa(tme.tm_hour,buffer,10);

                send(clientfd, buffer, strlen(buffer), 0);
            }
            else if (!strcmp(buffer,"date3")){ //client input "date3"
                temp = malloc(20);
                for (int i=0;i<MAXBUF;i++)
                buffer[i]='0';

                myTime = time(NULL);
                tme = *localtime(&myTime);

                itoa(tme.tm_mday,buffer,10);
                strcat(buffer,"-");

                switch(tme.tm_mon+1){  //select the current month
                    case 1:
                    temp = "Jan";
                    break;
                    case 2:
                    temp = "Feb";
                    break;
                    case 3:
                    temp = "Mar";
                    break;
                    case 4:
                    temp = "Apr";
                    break;
                    case 5:
                    temp = "May";
                    break;
                    case 6:
                    temp = "Jun";
                    break;
                    case 7:
                    temp = "Jul";
                    break;
                    case 8:
                    temp = "Aug";
                    break;
                    case 9:
                    temp = "Sep";
                    break;
                    case 10:
                    temp = "Oct";
                    break;
                    case 11:
                    temp = "Nov";
                    break;
                    case 12:
                    temp = "Dec";
                    break;
                }
            
                strcat(buffer,temp);
                strcat(buffer,"-");

                temp = malloc(10);
                itoa(tme.tm_year%100,temp,10);
                strcat(buffer,temp);

                send(clientfd, buffer, strlen(buffer), 0);

                free(temp);
            }
            else{
            if (buffer[0]!='\r')    //print length when string is not '\r'
			printf("Length:%d\n",strlen(buffer)); 
			send(clientfd, strupr(buffer), strlen(buffer), 0);
            }
		}
	}
	close(clientfd);
	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}

