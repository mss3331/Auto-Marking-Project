//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<ctype.h>
#include<string.h>


#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	
	struct sockaddr_in serv_addr;
	memset(&serv_addr, '0', sizeof(serv_addr));
	self.sin_family = AF_INET;
	printf("Start Server: %hu\n", atoi(argv[1]));
	self.sin_port = htons(atoi(argv[1]));	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
	
	
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");
        

	/*---make it a "listening socket"---*/
	int b, i, newSocket, welcomeSocket;
	struct sockaddr_in serverAddr;
 	struct sockaddr_storage serverStorage;
 	unsigned int addr_size = sizeof(serverStorage);
	welcomeSocket = socket(PF_INET, SOCK_STREAM, 0);
	
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");
        
        
        
	while(1){
		newSocket = accept(sockfd, (struct sockaddr *) &serverStorage, &addr_size);
      	b = 1;
      /*loop while connection is live*/
 		while(b!=0){
       		 b = recv(newSocket,buffer,1024,0);
  
 		for (i=0;i<b-1;i++){
          	buffer[i] = toupper(buffer[i]);
        }

        send(newSocket,buffer,b,0);
      }
      close(newSocket);
      	exit(0);
	}
	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		
		send(clientfd, buffer, recv(clientfd, buffer, MAXBUF, 0), 0);

		/*---close connection---*/
		close(clientfd);
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}

