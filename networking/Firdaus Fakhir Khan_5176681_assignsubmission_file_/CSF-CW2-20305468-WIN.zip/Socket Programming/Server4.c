//////////////////////////  Server4.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<time.h>



#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
		int MY_PORT;
		printf("- Networking 1>start server  ");
		scanf("%d",&MY_PORT);
		
	char buffer[MAXBUF];
	
	

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);
		int length;
		
		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);

	printf("\nIP address is: %s", inet_ntoa(client_addr.sin_addr));
		printf("\nport is: %d\n", (int) ntohs(client_addr.sin_port));
		
		
		while(1){
			memset(buffer,0,MAXBUF);
			int recv_size=recv(clientfd,buffer,MAXBUF,0);
			int m;
			int year;
			time_t t = time(NULL);
  struct tm tm = *localtime(&t);
			if(strcmp(buffer,"date")==0){
			printf("date now: %d-%02d-%02d %02d", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour);
			break;
			}
			else 
			if(strcmp(buffer,"date1")==0){
				printf("date1: %d\n",tm.tm_year + 1900);
				break;
			}
			else
			if(strcmp(buffer,"date2")==0){
				printf("date2: %02d",tm.tm_hour);
				break;
			}
			else
			if(strcmp(buffer,"date3")==0){
				printf("date3: %d-",tm.tm_mday);
				m=tm.tm_mon+1;
				switch(m)
    {
        case 1:
            printf("Jan-");
            break;
        case 2:
            printf("Feb-");
            break;
        case 3:
            printf("Mar-");
            break;
        case 4:
            printf("Apr-");
            break;
        case 5:
            printf("May-");
            break;
        case 6:
            printf("June-");
            break;
        case 7:
            printf("July-");
            break;
        case 8:
            printf("Aug-");
            break;
        case 9:
            printf("Sep-");
            break;
        case 10:
            printf("Oct-");
            break;
        case 11:
            printf("Nov-");
            break;
        case 12:
            printf("Dec-");
            break;
    }
			year= (tm.tm_year + 1900) % 100;
				printf("%d",year);
				
				break;
			}
			else 
			if(strcmp(buffer,"exit server")==0){
			printf("Disconnected from %s:%d\n", inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));
			break;
			}
		else	
		if(recv_size>0){
			strupr(buffer);
			puts(buffer);
			if(buffer[0]!='\r'){
				length=strlen(buffer);
				printf("\nlength of %s is %d",buffer,length);
			}
			send(clientfd,buffer, recv_size, 0);	
		}
		else{
			break;
		}
		
		}
		
		
		
		/*---close connection---*/
		close(clientfd);
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}