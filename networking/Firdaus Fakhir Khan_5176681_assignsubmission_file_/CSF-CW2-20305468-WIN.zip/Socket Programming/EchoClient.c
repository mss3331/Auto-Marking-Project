//////////////////////////  EchoClient.c ////////////////

#include<stdio.h>
#include<winsock2.h>
#include<io.h>
#include<string.h>
#include<time.h>

#define MY_PORT		8989
#define MAXBUFF		256


int main(int argc , char *argv[])
{
	
	printf("\nInitialising Winsock...");
    WSADATA wsa;
	int err;
	err = WSAStartup(MAKEWORD(2, 2), &wsa);
	if (err!=0){
		printf("Initialisation failed\n");
		return 1; // whether initialization failed
	}
	printf("Initialised.\n");

	// socket is created
	SOCKET s;
	s = socket(AF_INET, SOCK_STREAM, 0);
	if( s == INVALID_SOCKET ){
		printf("Socket that is created failed.\n");
		printf("Error code: %d\n", WSAGetLastError());
		return 1; // whether socket creation failed
	}
	printf("Socket is created.\n");

	//  Address are assigned
	struct sockaddr_in server;

	server.sin_family = AF_INET;
	server.sin_port = htons(MY_PORT);	  
	server.sin_addr.s_addr = inet_addr("127.0.0.1");

	// calling connect
	connect(s, (struct sockaddr *)&server, sizeof(server));
	//s:socket
	
	char message[MAXBUFF];
	//fill message with text before sending..
	char Server_Reply[MAXBUFF];

	while (1){
		// Send part
		printf("Enter your message: ");
		gets(message); // Gets message from client

		if (!strncmp(message, "exit client\0", 11)){ // if input is "exit client"
			break; // then break out of loop
		}
		else if ( send(s, message, strlen(message), 0) < 0 ){
			printf("send failed\n");
			return 1; // whether send is failed
		}

		// receive part
		if( recv(s, Server_Reply, MAXBUFF, 0) < 0 ){
			printf("receive failed\n");
			return 1; // whether receive is failed
		}
		puts(Server_Reply); // server reply is printed
	}

	
	close(s);

	WSACleanup();

	return 0;
}
