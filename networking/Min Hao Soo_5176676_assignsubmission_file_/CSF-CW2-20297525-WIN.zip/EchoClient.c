//////////////////////////  Client.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<ctype.h>

#define MY_PORT		server_port
#define MAXBUF		256

int main(int argc , char *argv[]){

    WSADATA wsa;
    SOCKET clientfd;
    struct sockaddr_in client;
    char message[MAXBUF];
    int server_port;

    /*-----------Initializing---------------*/
    printf("Enter Server Port Number:");
	scanf("%d", &server_port);

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Startup Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
    printf("Initialised.\n");

    /*---------------Client Socket----------------*/
    if  ((clientfd=socket(AF_INET,SOCK_STREAM,0))<0)
    {
        perror("Socket");
        exit (errno);
    }

    printf("\nSocket to Server Successfully Created!\n");

    /*------------Client Address Structure--------------*/
    client.sin_family=AF_INET;
    client.sin_port=htons(MY_PORT);
    client.sin_addr.s_addr=inet_addr("127.0.0.1");

    /*----------------Connection----------------*/
    
    if (connect(clientfd, (struct sockaddr*)&client, sizeof(client)) !=0)
    {
		printf("\nConnection failed to Server!\n");
		exit(errno);
	}
        puts("\nConnected to Server\n");

    /*--------------------Main Loop----------------------*/
    int clientStatus=1;
        while(clientStatus==1)
        {
            printf("Enter message to server:");    
            scanf(" %[^\n]s", message);

            if((strcmp(message,"exit client"))==0){
                printf("\nClient Terminated!\n");
                clientStatus=0;
                close(clientfd);
            }

            //must have a buffer....
            if (strlen(message)>0){
                int sendResult=send(clientfd,message,strlen(message)+1,0);
                //if can send
                if (sendResult!=SOCKET_ERROR)
                {
                    //receive from server
                    int messageStatus=recv(clientfd,message,MAXBUF,0);
                    //if there is a buffer...
                    if(messageStatus>0){
                        printf("\nServer Sent:%s\n",message);
                    }
                }
            }
        }

    /*---clean up (should never get here!)---*/
	close(clientfd);
	WSACleanup();
	return 0;
}