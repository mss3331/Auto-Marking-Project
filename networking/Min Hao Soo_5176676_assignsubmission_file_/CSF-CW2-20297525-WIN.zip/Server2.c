#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<ctype.h>
#include<stdlib.h>
#include<time.h>
#include<conio.h>

#define MY_PORT		user_defined_port
#define MAXBUF		256


int main(int argc, char* argv[])
{
	WSADATA wsa;
	SOCKET sockfd, clientfd;
	struct sockaddr_in self;
	char buffer[MAXBUF];
	int user_defined_port;
	int i;

	printf("Enter port number:");
	scanf("%d", &user_defined_port);


	printf("\nInitialising Winsock...");
	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
	{
		printf("Failed. Error Code : %d", WSAGetLastError());
		return 1;
	}

	printf("Initialised.\n");

	/*---create streaming socket---*/
	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		perror("Socket");
		exit(errno);
	}

	printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;

	/*---assign a port number to the socket---*/
	if (bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0)
	{
		perror("socket--bind");
		exit(errno);
	}

	puts("Bind done");

	/*---make it a "listening socket"---*/
	if (listen(sockfd, 20) != 0)
	{
		perror("socket--listen");
		exit(errno);
	}

	puts("Waiting for incoming connections...");



	/*---forever... ---*/
	while (1)
	{
		struct sockaddr_in client_addr;
		int addrlen = sizeof(client_addr);
		int recv_size = 1;
		int server_status = 1; //1=online

		//time------------------------------------------
		time_t t;
		t = time(NULL);
		struct tm tm = *localtime(&t);
		//----------------------------------------------

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);

		//displays ip address of client
		char* ip = inet_ntoa(client_addr.sin_addr);

		//printf target port and ip address of client
		printf("\nClient IP Address:%s",ip); 
		printf("\nClient Target Port Number:%d\n", MY_PORT);

		//multiple request
		while (server_status == 1) {
			recv_size = recv(clientfd, buffer, MAXBUF, 0);	//receive from client
			//print length of length 
			if (strcmp(buffer, "exit server") == 0) { //cmpare if buffer=exit command 
				printf("\nTerminated Request!\n");
				server_status = 0; //request exit
				break;
			}

			else {
				//Uppercase all letters in message
				for (i = 0; i <= recv_size - 1; i++) {
					buffer[i] = toupper(buffer[i]);
				}
				printf("\nMax Length of sent/received message is %d\n", i);
			}
			//In while loop send back to client 
			send(clientfd, buffer, recv_size, 0);
		}
		printf("\nClient Terminated!\n");
		/*---close connection---*/
		close(clientfd);
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
	WSACleanup();
	return 0;
}