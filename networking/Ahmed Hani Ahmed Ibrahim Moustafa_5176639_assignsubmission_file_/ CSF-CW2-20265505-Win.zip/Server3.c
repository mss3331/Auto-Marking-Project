//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include <time.h>

#define MY_PORT		8989
#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF]="";
	char buffer_date[MAXBUF]="";
	int i, n;
	int recvbuflen = MAXBUF;
	time_t time1 = time(NULL);
	struct tm *dt = localtime(&time1);
	/*char*ptr;
	 struct tm *tm_mday;
	 struct tm *tm_mon;
	 struct tm *tm_year;
	 struct tm *tm_hour; */

	/*sprintf(buffer_date, "%02d-%02d-%02d %02d", dt->tm_mday, dt->tm_mon+1, dt->tm_year +1900, dt->tm_hour)*/


	printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);
	self.sin_addr.s_addr = INADDR_ANY;

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}

        puts("Waiting for incoming connections...");


    /*To accept a connection on a socket*/
	struct sockaddr_in client_addr;
	int addrlen=sizeof(client_addr);

	clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);

	printf("%s : %d Connected \n" , inet_ntoa(client_addr.sin_addr) , ntohs(client_addr.sin_port));

	/*---forever... ---*/
	loop1:

	do
	{

		//int i->  set to equal the received data from client
		i = recv(clientfd, buffer, recvbuflen, 0);

		if(strcmp(buffer, "exit server") == 0){
                    exit (1);
                    break;
                }
        if(strcmp(buffer, "date") == 0){
                  sprintf(buffer_date, "%02d-%02d-%02d %02d", dt->tm_mday, dt->tm_mon+1, dt->tm_year +1900, dt->tm_hour);
                   send(clientfd, buffer_date, sizeof(buffer_date), 0); //sizeof added to get all cause buffer only will give 4 characters..

        }else if(strcmp(buffer, "date") != 0){

           send(clientfd, strupr(buffer), i, 0);



        }


		//reset  buffer again to handle  next request

		buffer[strcspn(buffer, "\r\n")] = 0;
		//displays  amount of bytes received by  server
		printf("Bytes received: %d\n", i);
		//set the memory of the  buffer variable to 0
		memset(buffer, 0, sizeof(buffer));

	}while (i > 0);

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}
