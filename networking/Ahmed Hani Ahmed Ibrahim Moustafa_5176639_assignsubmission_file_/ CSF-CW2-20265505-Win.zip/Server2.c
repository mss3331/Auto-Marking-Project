//////////////////////////  Server2.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>

#define MY_PORT		8989
#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF]="";
	int i, n;
	int recvbuflen = MAXBUF;


	printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);
	self.sin_addr.s_addr = INADDR_ANY;

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}

        puts("Waiting for incoming connections...");


    /*To accept a connection on a socket*/
	struct sockaddr_in client_addr;
	int addrlen=sizeof(client_addr);

	clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
	//display ip adress of client and port connected to
	printf("%s : %d Connected \n" , inet_ntoa(client_addr.sin_addr) , ntohs(client_addr.sin_port));

	/*---forever... ---*/


	do
	{
		//int i->  set to equal the received data from client
		i = recv(clientfd, buffer, recvbuflen, 0);

		if(strcmp(buffer, "exit server") == 0){
                    exit (1);
                    break;
                }


		// Echo the buffer back to the client
        n = send(clientfd, strupr(buffer), i, 0);
		//reset  buffer again to handle  next request

		buffer[strcspn(buffer, "\r\n")] = 0;
		//displays  amount of bytes received by  server
		printf("Bytes received: %d\n", i);
		//set the memory of the  buffer variable to 0
		memset(buffer, 0, sizeof(buffer));

	}while (i > 0);

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}
