//////////////////////////  Server2.c ////////////////
/**************************
 *                        *
 * Name: Ooi Jing Ru      *
 * Student ID: 20307168   *
 *                        *
 **************************/

#include <io.h>
#include <stdio.h>
#include <winsock2.h>
#include <string.h>

#define MY_PORT		8989
#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");
		
		
	/* prompt for port number */
	int portNum = 0;
	
	printf("Please enter a port number:\n");
	scanf("%d", &portNum);
	
	if (portNum < 1024) {
		printf("Input is less than 1024. Default port number 8989 will be used.\n");
		portNum = MY_PORT;
	} else if (portNum > 32767) {
		printf("Input is more than 32767. Default port number 8989 will be used.\n");
		portNum = MY_PORT;
	} 
	

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(portNum);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	
	struct sockaddr_in client_addr;
	int addrlen=sizeof(client_addr);
	int numByte;		//number of bytes received

	/*---accept a connection (creating a data pipe)---*/
	clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen); 
	
	/*---forever... ---*/	
	while (1)
	{		
		recv(clientfd, buffer, MAXBUF, MSG_PEEK);

		if(strncmp(buffer, "exit server", 11) == 0) {			
			close(clientfd);
			close(sockfd);
			WSACleanup();
			return 0;
		}
		
		int msg = 0;
		
		msg = recv(clientfd, buffer, MAXBUF, 0);
			
		printf("Client IP Address: %s\n", inet_ntoa(client_addr.sin_addr));
		printf("Port number: %d\n", portNum);
		printf("Length of message: %d\n", msg-2);

		send(clientfd, strupr(buffer), msg, 0);
	}
	
	/*---close connection---*/
	close(clientfd);
	
	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}

