//////////////////////////  EchoClient.c ////////////////
/**************************
 *                        *
 * Name: Ooi Jing Ru      *
 * Student ID: 20307168   *
 *                        *
 **************************/

#include <io.h>
#include <stdio.h>
#include <winsock2.h>
#include <string.h>

#define MY_PORT		8989
#define MAXBUF		256

int main(int argc , char *argv[]) {
	
	WSADATA wsa;
	int err;
	
	err = WSAStartup(MAKEWORD(2,2), &wsa);
	if(err != 0) {
		exit(0);
	}
	
	printf("Initialised.\n");
	
	SOCKET s;
	s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if(s == INVALID_SOCKET) {
		printf("Error code: %d\n", WSAGetLastError());
		shutdown(s, SD_BOTH);
		closesocket(s);
		WSACleanup();
		return 0;
	}
	
	printf("Socket created.\n");
	
	struct sockaddr_in server;
	server.sin_family = AF_INET;
	server.sin_port = htons(MY_PORT);	//big endian
	server.sin_addr.s_addr = inet_addr("127.0.0.1");	//IP -> binary
	
	printf("Initialized address/port structure.\n");
	
	int t = connect(s, (struct sockaddr *)&server, sizeof(server));
	
	if(t != 0) {
		printf("Socket not connected.\nError code: %d\n", WSAGetLastError());
		shutdown(s, SD_BOTH);
		closesocket(s);
		WSACleanup();
		return 0;
	}
	
	printf("Socket connected.\n");
	
	while(1) {
		
		char message[MAXBUF] = {0};
		//fill message with some text, before sending
		
		printf("Enter a message: ");
		fgets(message, MAXBUF, stdin);
		
		if(send(s, message, strlen(message), 0) < 0) {
			//send fail => handle it 
			printf("Send fail\n");
			printf("Error code: %d\n", WSAGetLastError());
			break;
		} 
		
		if(strncmp(message, "exit client", 11) == 0) {
			closesocket(s);
			WSACleanup();
			return 0;
		} 
		
		if(recv(s, message, strlen(message), 0) < 0) {
			//receive fail => handle it
			printf("Receive fail\n");
			printf("Error code: %d\n", WSAGetLastError());
		}
		printf("Server response: %s\n", message);
	}
	
	if(closesocket(s) != 0) {
		//close fail 
		printf("Close socket fail\n");
		printf("Error code: %d\n", WSAGetLastError());
	}
	
	if(WSACleanup() != 0) {
		//clean up fail 
		printf("Cleanup fail\n");
		printf("Error code: %d\n", WSAGetLastError());
	}	
	
	return 0;
}