//////////////////////////  Server1.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<ctype.h>
#include<string.h>

#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];
	int MY_PORT;
    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	puts("start server");
	printf("Input times for repetition:n\n");
	int n, i;
	scanf("%d", &n);

	printf("Input the port number:\n"); 
	scanf("%d",&MY_PORT);
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");
		


	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*creating data pipe*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		
		send(clientfd, buffer, recv(clientfd, buffer, MAXBUF, 0), 0);
		
		while(1)
			{
				store=recv(clientfd, buffer, MAXBUF, 0);
				send(clientfd, buffer, store, 0);
				printf("Message is : ");
				printf("%s\n",strupr(buffer));
		
				printf("The length of message is : %d\n",store);
				if(strcmp(buffer, b)==0)//if exit server is input
					{
						break;
					}
				memset(buffer,0,strlen(buffer));// reset buffer
					//prevent another loop back to recv
				store=recv(clientfd, buffer, MAXBUF, 0);
				send(clientfd, buffer, store, 0);
			}
		memset(buffer,0,strlen(buffer));/* reset buffer*/
		/*---close connection---*/
		close(clientfd);
	}
}
	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}
