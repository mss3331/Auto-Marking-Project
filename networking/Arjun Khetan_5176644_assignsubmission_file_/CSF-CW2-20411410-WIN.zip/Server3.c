//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<ctype.h>
#include <time.h>

#define MAXBUF		256
#define MY_PORT    8989

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char * buffer = malloc((MAXBUF + 1) * sizeof(char)); // We are allocating one extra byte (size of char) to make space for NULL in a string with 256 characters

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0) // We use highest version of winsock; and the second data structure receives details of implementation
    {
        printf("Failed. Error Code : %d",WSAGetLastError()); // return if value is not 0 (uses dynamically linked libraries)
        return 1; // Windows Socket API, also known as Winsock, is a type of application programming interface (API) used to communicate between Windows network software and network services.
    }
     
    printf("Initialised.\n"); // we have opened up winsock

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 ) // (Address family specification, socket type, particular protocol where TCP is default)
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit) // Big Endean
	self.sin_addr.s_addr = INADDR_ANY;  // IP -> Binary(you can specify it la, but here it is not exactly specified)

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr *)&self, sizeof(self)) != 0 ) // sockfd is also a socket
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

    struct sockaddr_in client_addr;
	int addrlen=sizeof(client_addr);

     /*---make it a "listening socket"---*/
    if ( listen(sockfd, 20) != 0 )
    {
        perror("socket--listen");
        exit(errno);
    }

    puts("Waiting for incoming connections...");

    /*---accept a connection (creating a data pipe)---*/
    clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);

    /*-----forever------*/
    int recv_bytes, send_bytes;
    do
    {   
        recv_bytes = recv(clientfd, buffer, MAXBUF, 0);
        buffer[recv_bytes] = '\0'; // We need to put a NULL terminator in the buffer stream because recv does not do that
        // Implementing the date command
        char command[] = "date";
        if ((strcmp(buffer, command)) == 0)
        {
            time_t t = time(NULL); // we need to send the current date and time to the client
            struct tm tm = *localtime(&t); // t is a pointer
            // We can put it a new string (char *)
            // Using this incredible function, we can create a string that can be sent to the server
            snprintf(buffer, MAXBUF, "%.2d%c%.2d%c%.2d%c%.2d%c%c", tm.tm_mday, '-', tm.tm_mon + 1, '-', tm.tm_year - 100, ' ', tm.tm_hour, 13, 10);
            // Sending the string using send
            send_bytes = send(clientfd, buffer, strlen(buffer), 0); // Need to put sizeof(char *)
        }
        else // If we receive anything other than the command, we will process it accordingly
        {
            char *ip = inet_ntoa(client_addr.sin_addr);
            send_bytes = send(clientfd, buffer, recv_bytes, 0); // int send (SOCKET s, const char * buffer/message, int len, int flags)	
            if (buffer[0] != 13)
                printf("\nClient IP Address: %s\nPort Number: %d\nMessage Length: %d\n", ip, MY_PORT, strlen(buffer)); // Attempting to use strlen to find message length
        }

        char exit[] = "exit server"; // exiting the server and closing the connection if "exit server" is entered
        if ((strcmp(buffer, exit)) == 0) 
        { /*---close connection---*/
            closesocket(sockfd);
            WSACleanup();
            return 0;
        }
    }
    while (recv_bytes > 0);
	return 0;
}

