//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<ctype.h>

#define SERVER_PORT	8989
#define MAXBUF		256

int main(int argc , char *argv[]) // For this, you need to keep your server window open. Otherwise it would not connect
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    struct sockaddr_in server; // Declaring a variable which can be used later

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0) // We use highest version of winsock; and the second data structure receives details of implementation
    {
        printf("Failed. Error Code : %d",WSAGetLastError()); // return if value is not 0 (uses dynamically linked libraries)
        return 1; // Windows Socket API, also known as Winsock, is a type of application programming interface (API) used to communicate between Windows network software and network services.
    }
    printf("Initialised.\n"); // we have opened up winsock

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 ) // (Address family specification, socket type, particular protocol where TCP is default)
	{
		perror("Socket");
		exit(errno);
	}
    printf("Socket created.\n");
	
	/*---initialize address/port structure---*/
	server.sin_family = AF_INET;
	server.sin_port = htons(SERVER_PORT); // Host to Network Short (16-bit) // Big Endean
	server.sin_addr.s_addr = inet_addr("127.0.0.1"); // converts a string containing an IPV4 dotted-decimal address into a proper address

	/*---assign a port number to the socket---*/
    if ( connect(sockfd, (struct sockaddr *) &server, sizeof(server)) != 0 ) // sockfd is also a socket
	{
		perror("socket--connect");
		puts("Make sure that a server such as Server2.exe is running in the background.");
		exit(errno);
	}
    puts("Connection with Server made.");
	puts("Ready to send.");

	char buffer[MAXBUF];

	struct sockaddr_in server_addr;
	int addrlen=sizeof(server_addr);
	
	/*---forever... ---*/
	int send_bytes, recv_bytes;
	do 
	{	
		gets(buffer); // Getting a string from the user which includes spaces 
		char clientexit[] = "exit client";
		/*---exiting client---*/
		if ((strcmp(buffer, clientexit)) == 0) 
		{
			puts("The client connection has now been terminated");
			close(clientfd);
			close(sockfd);
            WSACleanup(); 
            return 0;
		}
		/*---sending---*/
		send_bytes = send(sockfd, buffer, sizeof(buffer), 0); // sizeof(buffer) is used because send uses the number of bytes (not string length)
		if (send_bytes < 0)
		{
			perror("Send failed");
			exit(errno);
		}
		/*---receiving---*/
		char reply[256];
		recv_bytes = recv(sockfd, reply, sizeof(reply), 0); // It stops reading beyond this point on server.exe most likely because server is not accepting anymore
		// so it works with other servers but not server.exe
		if (recv_bytes < 0)
		{
			perror("Receive failed");
			exit(errno);
		}
		printf("%s\n", reply);
	}
	while(1);
	
	/*---close connection---*/
	close(clientfd);
	
	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}

