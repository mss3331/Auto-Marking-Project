//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<ctype.h>

#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];
    int MY_PORT = atoi(argv[1]); // Converting the 'string' retrieved using argv[1] to an integer which is then stored

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0) // We use highest version of winsock; and the second data structure receives details of implementation
    {
        printf("Failed. Error Code : %d",WSAGetLastError()); // return if value is not 0 (uses dynamically linked libraries)
        return 1; // Windows Socket API, also known as Winsock, is a type of application programming interface (API) used to communicate between Windows network software and network services.
    }
     
    printf("Initialised.\n"); // we have opened up winsock

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 ) // (Address family specification, socket type, particular protocol where TCP is default)
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit) // Big Endean
	self.sin_addr.s_addr = INADDR_ANY;  // IP -> Binary(you can specify it la, but here it is not exactly specified)

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr *)&self, sizeof(self)) != 0 ) // sockfd is also a socket
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");
	
	/*---forever... ---*/
	while(1) 
    {
		struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
        // Making the client's message to uppercase
        if (recv(clientfd, buffer, 256, 0) < 0)
        {
            puts("Receive failed"); // Only goes here if the message is not received 
        }

        for (int i = 0; i < strlen(buffer); i++)
        {
            
            buffer[i] = toupper(buffer[i]); 
        }

		send(clientfd, buffer, strlen(buffer), 0); // int send (SOCKET s, const char * buffer/message, int len, int flags)
        /*---close connection---*/
		close(clientfd);
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}

