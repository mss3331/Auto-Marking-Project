
//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include <ctype.h> //Used as to apply toupper
//#pragma comment(lib, "ws2_32.lib") //Winsock Library


int main(int argc , char *argv[])
{

    WSADATA wsa;
    SOCKET sockfd , clientfd , client_socket[30] , s;
    struct sockaddr_in self, client_addr;
    int max_clients = 20 , activity, addrlen, i, valread, j;
    char *message = "ECHO Daemon v1.0 \r\n";

	//size of our receive buffer, this is string length.
	int MAXRECV = 1024;
	//set of socket descriptors
    fd_set readfds;
	//1 extra for null character, string termination
	char *buffer;
	buffer =  (char*) malloc((MAXRECV + 1) * sizeof(char));

	for(i = 0 ; i < 30;i++)
	{
		client_socket[i] = 0;
	}

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

    printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(atoi(argv[1])); // Host to Network Short (16-bit) //Accepts any port number instead of the predefined one
	self.sin_addr.s_addr = INADDR_ANY;

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}

        puts("Waiting for incoming connections...");

    addrlen = sizeof(struct sockaddr_in);

	/*---forever... ---*/
	while (1)
    {
        //clear the socket fd set
        FD_ZERO(&readfds);

        //add sockfd socket to fd set
        FD_SET(sockfd, &readfds);

        //add child sockets to fd set
        for (  i = 0 ; i < max_clients ; i++)
        {
            s = client_socket[i];
            if(s > 0)
            {
                FD_SET( s , &readfds);
            }
        }

        //wait for an activity on any of the sockets, timeout is NULL , so wait indefinitely
        activity = select( 0 , &readfds , NULL , NULL , NULL);

        if ( activity == SOCKET_ERROR )
        {
            printf("select call failed with error code : %d" , WSAGetLastError());
			exit(EXIT_FAILURE);
        }

        //If something happened on the sockfd socket , then its an incoming connection
        if (FD_ISSET(sockfd , &readfds))
        {
            if ((clientfd = accept(sockfd , (struct sockaddr *)&client_addr, (int *)&addrlen))<0)
            {
                perror("accept");
                exit(EXIT_FAILURE);
            }

            //inform user of socket number - used in send and receive commands
            printf("New connection , socket fd is %d , IP : %s , port : %d \n" , clientfd , inet_ntoa(client_addr.sin_addr) , ntohs(client_addr.sin_port)); //display the port number and IP address

            //send new connection greeting message
            if( send(clientfd, message, strlen(message), 0) != strlen(message) )
            {
                perror("send failed");
            }

            puts("Welcome message sent successfully");

            //add new socket to array of sockets
            for (i = 0; i < max_clients; i++)
            {
                if (client_socket[i] == 0)
                {
                    client_socket[i] = clientfd;
                    printf("Adding to list of sockets at index %d \n" , i);
                    break;
                }
            }
        }

        //else its some IO operation on some other socket :)
        for (i = 0; i < max_clients; i++)
        {
            s = client_socket[i];
			//if client presend in read sockets
            if (FD_ISSET( s , &readfds))
            {
                //get details of the client
				getpeername(s , (struct sockaddr*)&client_addr , (int*)&addrlen);

				//Check if it was for closing , and also read the incoming message
				//recv does not place a null terminator at the end of the string (whilst printf %s assumes there is one).
                valread = recv( s , buffer, MAXRECV, 0);

				if( valread == SOCKET_ERROR)
				{
					int error_code = WSAGetLastError();
					if(error_code == WSAECONNRESET)
					{
						//Somebody disconnected , get his details and print
						printf("Host disconnected unexpectedly , ip %s , port %d \n" , inet_ntoa(client_addr.sin_addr) , ntohs(client_addr.sin_port));

						//Close the socket and mark as 0 in list for reuse
						closesocket( s );
						client_socket[i] = 0;
					}
					else
					{
						printf("recv failed with error code : %d" , error_code);
					}
				}
				if ( valread == 0)
                {
                    //Somebody disconnected , get his details and print
                    printf("Host disconnected , ip %s , port %d \n" , inet_ntoa(client_addr.sin_addr) , ntohs(client_addr.sin_port));

                    //Close the socket and mark as 0 in list for reuse
                    closesocket( s );
                    client_socket[i] = 0;
                }

                //Echo back the message that came in
                else
                {
                    if (strcmp(buffer, "exit server\r\n") == 0 || strcmp(buffer,"exit server\n") == 0 || strcmp(buffer,"exit server") == 0) //exit server
                    {
                        printf("Server Exit... , IP %s , port %d \n" , inet_ntoa(client_addr.sin_addr) , ntohs(client_addr.sin_port));
                        exit(0);
                    }
                    else
                    {
                        //add null character, if you want to use with printf/puts or other string handling functions
                        buffer[valread] = '\0';
                        for (j = 0; buffer[j] != '\0'; ++j);
                        printf("%s:%d - %sLength of the message = %d \n" , inet_ntoa(client_addr.sin_addr) , ntohs(client_addr.sin_port), buffer, j-2); //display the message length
                        send( s , buffer , valread , 0 );
                    }
                }
            }
        }
    }

	/*---clean up (should never get here!)---*/
	close(sockfd);
    WSACleanup();

	return 0;
}


