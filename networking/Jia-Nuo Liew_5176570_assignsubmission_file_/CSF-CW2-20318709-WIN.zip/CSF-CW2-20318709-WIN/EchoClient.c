//////////////////////////  EchoClient.c ////////////////
#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>

#define MY_PORT 	8989
#define MAXBUF		256
   
int main(int argc, char *argv[])
{
	//WSAStartup
	WSADATA wsa;
	SOCKET sendfd;
	struct sockaddr_in servaddr;
	int err, n, i;
	char buffer[256];
	
	printf("\nInitialising Winsock...");
	err = WSAStartup(MAKEWORD(2,2), &wsa);
	if (err != 0){
		return 1;
	}
	printf("Initialised.\n");
	
	//Socket
	SOCKET s;
	s = socket(AF_INET, SOCK_STREAM, 0);
	if (s == INVALID_SOCKET){
		printf("Error code: %d\n", WSAGetLastError());
	}
	else{
		printf("Socket created.\n");
	}

	memset(&servaddr, 0, sizeof(servaddr));
	struct sockaddr_in server;
	server.sin_family = AF_INET;
	server.sin_port = htons(8989);
	server.sin_addr.s_addr = inet_addr("127.0.0.1"); 
	
	//Connecting server
	if (connect(s, (struct sockaddr *)&server, sizeof(server)) != 0){
		printf("Connection failed with error code : %d", WSAGetLastError());
		exit(errno);
	}
		puts("Connected \n");
	
	//Chat
	while(1){
		struct sockaddr_in server;
		int addrlen=sizeof(server);
		
		while(1){
			//Send
			memset(buffer, 0, sizeof(buffer));				//reset buffer
			printf("Enter your message: ");
			
			for(n = 0; (buffer[n] = getchar()) != '\n'; n++);		//get buffer
						
			if(strncmp(buffer, "exit client", 11) == 0){			//terminator
				exit(0);
			}
			
			send(s, buffer, n, 0);

			//receive
			char reply[MAXBUF];
			memset(reply, 0, sizeof(reply));				//reset reply
			if (recv(s, reply, MAXBUF, 0) < 0){
				printf("Receive failed. \n");
			}
			else{
				printf("From Server: %s \n", reply);		//get reply
			}
		}
		close(s);
	}
	
	//cleanup
	close(s);
        WSACleanup();
	return 0;
}