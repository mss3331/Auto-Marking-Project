//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<time.h>

#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    struct sockaddr_in self;
	char buffer[MAXBUF];
		
	int My_Port;
	
	printf("- Network 1>start server: ");
	scanf("%d", &My_Port);
	printf("\n\n");

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET )
	{
		printf("Could not create socket : %d", WSAGetLastError());
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	memset(&self, 0, sizeof(self));
	
	self.sin_family = AF_INET;
	self.sin_port = htons( My_Port );	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
	if ( bind(sockfd, (struct sockaddr *)&self, sizeof(self)) == SOCKET_ERROR)
  //  if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		printf("Bind failed with error code : %d", WSAGetLastError());
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");
		
	/*---accept a connection (creating a data pipe)---*/
	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
			int addrlen=sizeof(client_addr);

				/*---accept a connection (creating a data pipe)---*/
				clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
				printf("\nIP address is: %s\n", inet_ntoa(client_addr.sin_addr));
				printf("Port number is: %d\n", ntohs(self.sin_port));
			while(1){
				int rev_size = recv(clientfd, buffer, MAXBUF, 0);
				
				if(strncmp(buffer, "exit server", 11) == 0){
					printf("Exit server\r\n");
					break;
				}
				
				if (buffer[0] != '\n' && buffer[0] != '\r'){
					time_t	t;							//this is to find the time
					struct tm* tp;
					
					t = time(NULL);
					tp = localtime(&t);
					
					if (rev_size == 4){							//this is to make sure that date + random things behind it would not print the formated date too.
						if (strncmp(buffer, "date", 4) == 0){
							time_t	t;							//this is to find the time
							struct tm* tp;
							
							t = time(NULL);
							tp = localtime(&t);
							
							//structuring the time into string buffer
							strftime(buffer, MAXBUF, "%d-%m-%Y %H\n\r", tp);		

							//sending the string buffer to client (strlen(buffer) is used as the length of the time is more than the rev_size)
							send(clientfd, buffer, strlen(buffer), 0);			
						}
						
						else{
							strupr(buffer);
							send(clientfd, buffer, rev_size, 0);
						}
					}
					else if (rev_size == 5){
						if(strncmp(buffer, "date1", 5) == 0){
							strftime(buffer, MAXBUF, "%Y\n\r", tp);	
							send(clientfd, buffer, strlen(buffer), 0);
						}
						else if(strncmp(buffer, "date2", 5) == 0){
							strftime(buffer, MAXBUF, "%H\n\r", tp);
							send(clientfd, buffer, strlen(buffer), 0);
						}
						else if(strncmp(buffer, "date3", 5) == 0){
							strftime(buffer, MAXBUF, "%d-%b-%y\n\r", tp);
							send(clientfd, buffer, strlen(buffer), 0);
						}
						else{
							strupr(buffer);
							send(clientfd, buffer, rev_size, 0);
						}
					}
					else{
						strupr(buffer);
						send(clientfd, buffer, rev_size, 0);
					}					
					if(rev_size == -1){			//if client exits
						break;
					}
					printf("Length of message: %d \r\n", rev_size);
				}
			}

		/*---close connection---*/
		close(clientfd);
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}