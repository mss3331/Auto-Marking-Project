//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<ctype.h>
#include<string.h>
#include <ws2tcpip.h>
#define MAXBUF		256

#pragma comment(lib,"ws2_32.lib") //Winsock Library.

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd, client;
    	struct sockaddr_in self;
	char buffer[MAXBUF];	
    int Port;
	scanf("%d",&Port); // allow user to input any port numbers.

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET )
	{
		printf("Could not create socket : %d", WSAGetLastError());
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	memset(&self,0, sizeof(self));
	self.sin_family = AF_INET;
	self.sin_port = htons(Port);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr *)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	struct sockaddr_in client_addr;
	int addrlen=sizeof(client_addr);
	
	/*---accept a connection (creating a data pipe)---*/	
	/*---forever... ---*/
	while((clientfd = accept(sockfd, (struct sockaddr *)&client_addr,&addrlen)))
	{
		puts("Connection accepted.\n");
		socklen_t client = sizeof(client_addr); // size of the clients.

		printf("IP: %s\t", inet_ntoa(client_addr.sin_addr)); // print out the client's IP address.

		getsockname(sockfd, (struct sockaddr *)&client_addr, &client);
		printf("Port: %d\n", (int)ntohs(client_addr.sin_port)); // print out client's Port number.
		
		if(clientfd < 0)
		{
			printf("Connection failed.\n");
			exit(0);  
		}
	while(1)
	{
		memset(&buffer,0, sizeof(buffer)); // memory reset input.
		int recv_size= recv(clientfd, buffer, MAXBUF, 0);
		printf("Length of string is %d\n",strlen(buffer)); // print out the length of the string.
		if(strncmp("exit server",buffer,11) == 0) // if user input "exit server".
		{
			printf("Disconnected.\n");
			exit(1); // terminate the server.
		}
		{
			for(int i=0;buffer[i]!=0;i++) // loop the string.
		{
			buffer[i]=toupper(buffer[i]); // change all characters inside the string to uppercase.
		}
			send(clientfd, buffer, recv_size, 0); // send back the string to the client.
			printf("From Client : %s\n",buffer);
			/*---close connection---*/
			close(clientfd);
		}
	}	
	}	

	/*---clean up (should never get here!)---*/
	close(sockfd);
    WSACleanup();
	return 0;
}