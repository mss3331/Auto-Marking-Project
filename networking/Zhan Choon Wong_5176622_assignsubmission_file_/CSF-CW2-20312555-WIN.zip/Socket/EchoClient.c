//////////////////////////  EchoClient.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<ctype.h>

int main(int argc , char *argv[])
{
	WSADATA wsa;
	SOCKET sockfd;
		struct sockaddr_in server;
		char message[256],server_reply[256];
	int recv_size,port,i=0;
		scanf("%d",&port);

	printf("Initialising Winsock...\n");
	if (WSAStartup(MAKEWORD(2,2),&wsa)!=0)
	{
		printf("Error code : %d",WSAGetLastError());
		return -1;
	}
	printf("Initialised.\n");

	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(sockfd == INVALID_SOCKET)
	{	
		printf("Could not create socket: %d\n", WSAGetLastError());
		return -1;
	}
	printf("socket is created.\n");
	
	server.sin_family= AF_INET; // ip address
	server.sin_port= htons(port);
	server.sin_addr.s_addr = inet_addr("127.0.0.1");

	//connect to the server
	if (connect(sockfd, (struct sockaddr *)&server, sizeof(server)) < 0)
	{
		printf("Connection error.\n");
		return -1;
	}
	puts("Connected to the server.\n");

	//send message to the server.
	for(;;)
	{	
		memset(&message,0,sizeof(message)); // clear memory inside the array.
		printf("\nEnter message: ");
		scanf(" %[^\n]",&message); // read string until "\n" is not found.
		
		
		if(strncmp("exit client",message,11) == 0) // if user input "exit client".
		{
			printf("Client Exit.\n");
			break; // break the looping.
		}
		else
		{		
		send(sockfd,message,sizeof(message),0); // send the message to the server.
		recv_size = recv(sockfd,server_reply,sizeof(server_reply),0); // receive the message from the server.
		printf("\nfrom server : %s", server_reply);
		}

	}
	
	/*---clean up (should never get here!)---*/
	close(sockfd);
	WSACleanup();
	return 0;
}
	