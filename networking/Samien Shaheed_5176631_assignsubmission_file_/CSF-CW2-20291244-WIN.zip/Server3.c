//////////////////////////  Server.c ////////////////

#include<io.h>
#include<time.h>
#include<stdio.h>
#include<string.h>
#include<winsock2.h>
#include<windows.h>

#define MAXBUF	256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF] = {'0'};
    char client_reply[MAXBUF] = {'0'}; // String to hold message to send to client

    time_t t = time(NULL);
    struct tm *tm = localtime(&t);

	// Atoi converts char argument into integer
	int port = atoi(argv[argc - 1]);

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(port);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY; 

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");
        puts("");

	while(1)
	{
		struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		// Display Client Info
		printf("Client has connected:\n");
		printf("IP address is: %s\n", inet_ntoa(client_addr.sin_addr));
		printf("Port Number is: %d\n", (int) ntohs(client_addr.sin_port));
		puts("");

		while(1)
		{
            // Empty array before starting loop
            memset(buffer,0,strlen(buffer));
			
			// Receive client input
			int recv_size = recv(clientfd, buffer, MAXBUF, 0);

			// Break out of loop if use inputs "exit server"
			if(!strcmp(buffer, "exit server"))
				break;
			
            if(!strcmp(buffer, "date"))
            {
			    sprintf(client_reply, "%d-%d-%d %d\n", tm->tm_mday, tm->tm_mon+1, tm->tm_year-100, tm->tm_hour);
                send(clientfd, client_reply, sizeof(client_reply), 0);
            } else {
                // Display length of message received from client
                printf("Length of message: %d\n", strlen(buffer));
                
                //Output to client
                send(clientfd, strupr(buffer), recv_size , 0);
            }

		}
		
	}
	
	/*---close connection---*/
	close(clientfd);
	
	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}

