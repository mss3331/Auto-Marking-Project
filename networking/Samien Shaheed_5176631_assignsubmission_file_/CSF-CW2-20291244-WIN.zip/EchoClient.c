#include<io.h>
#include<stdio.h>
#include<string.h>
#include<winsock2.h>
#include<windows.h>

#define MAXBUF 256

int main()
{
    WSADATA wsa;
    SOCKET sockfd, serverfd;
        struct sockaddr_in server;
    char message[MAXBUF];
    char server_reply[MAXBUF];

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");
    
    /*---initialize address/port structure---*/
    server.sin_addr.s_addr = inet_addr("127.0.0.1");
	server.sin_family = AF_INET;
	server.sin_port = htons(8989); // Host to Network Short (16-bit)

    //Connect to remote server
	if (connect(sockfd , (struct sockaddr *)&server , sizeof(server)) < 0)
	{
		perror("connect failed. Error");
		return 1;
	}

    printf("Connected\n");

    // Loop forever
    while(1)
    {
        printf("\nEnter message : ");
		
        // Receives input from user
        fgets(message, sizeof(message), stdin);
        if ((strlen(message) > 0) && (message[strlen (message) - 1] == '\n'))
                    message[strlen (message) - 1] = '\0';
        
        // Client exits if the user types in "exit client" 
        if(!strcmp(message, "exit client"))
            break;

        // Error check when sending info to server
        if(send(sockfd, message, strlen(message), 0) < 0)
        {
            printf("Send failed.");
            return 1;
        }
        
        // Error check when receiving info from server
        if(recv(sockfd, server_reply, MAXBUF, 0) < 0)
        {
            printf("Receive failed.");
            return 1;
        }
        
        // Displays server reply in client terminal
        printf("Server reply: %s", server_reply);

        // Empty array before starting next iteration
        memset(server_reply, 0, strlen(server_reply));
    }

    // Close connection and cleanup
    close(sockfd);
        WSACleanup();
    return 0;
}