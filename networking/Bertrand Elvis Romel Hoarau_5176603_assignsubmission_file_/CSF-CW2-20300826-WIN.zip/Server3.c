//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<time.h>

//#define MY_PORT		8989
#define MAXBUF		256

int main(int argc , char *argv[])
{   int MY_PORT, i, a;
time_t currentTime;
    struct tm *mytime;
    time(&currentTime);
    mytime = localtime(&currentTime);

while (1){
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/

    printf("- Networking 1>start server:\n");
	scanf("%d", &MY_PORT);

	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}

        puts("Waiting for incoming connections...");

	/*---forever... ---*/

        struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		printf("The IP address of the client is: %s\n", inet_ntoa(client_addr.sin_addr));//inet_ntoa convert host address to a string ipv4
	    printf("The port number is: %d\n", MY_PORT);

while(strncmp(buffer, "EXIT SERVER", MAXBUF)){//exit if buffer equal to EXIT SERVER
        memset(buffer, 0, MAXBUF);//set buffer to zero
        a = recv(clientfd, buffer, MAXBUF-2, 0);//get the length of the message

        for(i=0; i<a; i++){
            if(buffer[i] >= 'a' && buffer[i] <= 'z') {
                buffer[i] = buffer[i] - 32;		//to turn all non caps to capital letters
			}
        }

        if((strncmp(buffer, "DATE", MAXBUF)) == 0){//check if buffer equal to date

    memset(buffer, 0, MAXBUF);
    strftime(buffer, MAXBUF, "%d/%m/%y - %H", mytime);// if buffer equal to date send the current date and time in this format

    send(clientfd, buffer, MAXBUF, 0);
    }
else{
        printf("%s\n", buffer);
        printf("Message length is: %d\n", i);//printing length of message in server
		send(clientfd, buffer, a, 0);//returning message in capital
}
}
		/*---close connection---*/
		close(clientfd);

  memset(buffer, 0, MAXBUF);

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
}
	return 0;
}

