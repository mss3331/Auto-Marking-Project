//////////////////////////  EchoClient.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#define MY_PORT     8989// define the port number
#define MAXBUF		256

int main(int argc , char *argv[])
{   WSADATA wsa;
    int n;
    char buffer[MAXBUF];

    SOCKET sockfd ;
    	struct sockaddr_in self;

     printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");


	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}
        printf("Socket created.\n");

       memset(buffer, 0, MAXBUF); //setting buffer to zero
        /*---initialize address/port structure---*/
	//bzero(&self, sizeof(self));

	self.sin_family = AF_INET;
	self.sin_addr.s_addr = inet_addr("127.0.0.1");
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)

	if(connect(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0){
	printf("failed to connected to the server.\n");
    exit(0);
}
    else
        printf("successfully connected to the server\n");

    while(1){//infinite loop
        memset(buffer, 0, MAXBUF); // set buffer to 0/NULL
        printf("Enter a string:\n");
         n = 0;
        while((buffer[n++] = getchar()) != '\n')// get all the character until \n, and store it in arrray buffer
            ;

        send(sockfd, buffer, (n-1), 0);//send buffer (n-1 is to exclude the \n)
        memset(buffer, 0, MAXBUF);

        recv(sockfd, buffer, MAXBUF, 0); //receive the buffer from server
        printf("Server: %s\n", buffer);


        if((strncmp(buffer, "EXIT CLIENT", 11)) == 0){//check if string is equal to EXIT CLIENT if yes print client exit
            printf("Client exit\n");
            break;//break out of the infinite loop
        }

    }

  close(sockfd);

  return 0;
}
