/* server3.c by Leo Wolpert, adapted from Beej's
   server.c (http://www.ecst.csuchico.edu/~beej/guide/net/)
   This server allows a user to type in a message and send
   it to a client until one of them exits.
*/

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/wait.h>

#define MYPORT 6996    /* the port the client will be connecting to */

#define BACKLOG 10     /* Needed for "listen" in case many machines try to connect
                          this cuts it off at 10. */
#define MAXDATASIZE 100

main()
{
    int sockfd, new_fd;  /* listen on sock_fd, new connection on new_fd */
    struct sockaddr_in my_addr;    /* my address information */
    struct sockaddr_in their_addr; /* connector's address information */
    int sin_size;
    char yer_text[MAXDATASIZE]="HEY HEY HEY!!!\n";  /* String that is sent
                                                       from server to client */
    printf("Starting up server program.\n");
    printf("Enter strings to send to the client program or '/Q' to quit.\n");

    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1) 
    /* Create socket file descriptor */
    {
        perror("socket");
        exit(1);
    }

    my_addr.sin_family = AF_INET;         /* host byte order */
    my_addr.sin_port = htons(MYPORT);     /* short, network byte order */
    my_addr.sin_addr.s_addr = INADDR_ANY; /* automatically fill with my IP */
    bzero(&(my_addr.sin_zero), 8);        /* zero the rest of the struct */

    if (bind(sockfd, (struct sockaddr *)&my_addr, sizeof(struct sockaddr)) == -1) 
    /* Bind socket to specific address */
    {
        perror("bind");
        exit(1);
    }

    printf("Waiting for connection from remote machine.\n");
    if (listen(sockfd, BACKLOG) == -1) 
    /* Wait for connection */
    {
        perror("listen");
        exit(1);
    }

        sin_size = sizeof(struct sockaddr_in);
        if ((new_fd = accept(sockfd, (struct sockaddr *)&their_addr, &sin_size)) == -1) 
        /* Accept connection, make new file descriptor to write to */ 
        {
           perror("accept");
        }
        printf("server: got connection from %s\n",inet_ntoa(their_addr.sin_addr));
           
              while(scanf("%s", &yer_text))
              /*get text from user*/
              { 
                 if (send(new_fd, yer_text, strlen(yer_text), 0) == -1)
                 /* Send the message to the client */
                     perror("send");


                 if(yer_text[0]=='/' && yer_text[1]=='Q')
                 /* If the server types in /Q the program exits */
                 {
                    printf("\n\n\nGOODBYE!!!\n");
                    close(new_fd);
                    exit(0);
                 }
              }
           
        close(new_fd);  /* Close up the newly created FD */

        while(waitpid(-1,NULL,WNOHANG) > 0); /* clean up all child processes */
}
