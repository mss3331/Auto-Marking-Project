//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<windows.h>
#include<time.h>

#define MY_PORT		8989
#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer1[MAXBUF];
    char buffer2[MAXBUF];
	int length;
	char exitserver[] = "exit server";
    char senddate[] = "date";
	int port;
  	port = atoi(argv[1]);
	char* ip;

   char date[50]; // setting up date
   struct tm *local;
   time_t t;
   time(&t);
   local = localtime(&t);
   strftime(date, sizeof(date), "%d-%m-%y %I\r\n", local); // save date format dd/mm/yy hh to date



    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(port);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;
	ip = inet_ntoa(self.sin_addr);

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		printf("%s\n", inet_ntoa(client_addr.sin_addr));// print address
		printf("%d\n", port);// print portnum
        while(1){//loop 
			int recv_size = recv(clientfd, buffer1, MAXBUF, 0);
			length = strlen(buffer1);
		if( strcmp(buffer1, exitserver) == 0){//compare buffer1 and exitserver
            break;
        }
        else if( strcmp(buffer1, senddate) == 0){//compare buffer1 and senddate
            strcpy(buffer2, date); // copy data from date to buffer2
            send(clientfd, buffer2, sizeof(date), 0);// send bufer2 to client
			memset(buffer1, 0, sizeof(buffer1));// reset buffer1 and buffer2
			memset(buffer2, 0, sizeof(buffer2));
        }
        else{// else send capitalized message to client
			for(int i = 0; buffer1[i] != '\0'; i++){
				buffer2[i] = toupper(buffer1[i]);
			}
			if(buffer2[0] != '\r'){
					printf("%s", buffer2);
				}
			send(clientfd, buffer2, recv_size, 0);
			
			printf("%d\n", length);
			memset(buffer1, 0, sizeof(buffer1));
			memset(buffer2, 0, sizeof(buffer2));
			}
		}
        close(clientfd);
		return 0;
		/*---close connection---*/
		    
		
	}

	/*---clean up (should never get here!)---*/
	
	close(sockfd);
        WSACleanup();
	return 0;
}