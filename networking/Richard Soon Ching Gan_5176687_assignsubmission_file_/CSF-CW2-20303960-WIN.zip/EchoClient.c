#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<windows.h>

#define BUFFER 1024

int main(int argc, char** argv){
    WSADATA wsa;
    SOCKET s;
    int err;
    char input[BUFFER];
    char output[BUFFER];
    char exit[] = "exit client";
    int len;
    int port = 0;

    printf("Starting Client...\n");
    err = WSAStartup(MAKEWORD(2, 2), &wsa);
    if (err != 0){
        printf("Failed to start client. ");
        return 0;
    }
    printf("Client Started.\n");

    s = socket(AF_INET, SOCK_STREAM, 0);//creating socket
    printf("Aquiring Socket...\n");
    if( s == INVALID_SOCKET){
        printf("Error code: %d\n", WSAGetLastError());
        return 0;
    }
    printf("Socket Aquired.\n");
    struct sockaddr_in server;

    printf("Enter Port number:\n");//assigning values to address/port structure
    scanf("%d", &port);
    getchar();// get 'enter' key
    server.sin_family = AF_INET;
    server.sin_port = htons(port);
    server.sin_addr.s_addr = inet_addr("127.0.0.1");

    if(connect(s, (struct sockaddr *)&server, sizeof(server)) < 0){
        printf("Error");
        return 0;
    }
    printf("Enter message:\n");
    while(1){ //loop
        gets(input);
        if(strcmp(input, exit) == 0){ //check to see if input is 'exit client' if so break
            printf("exiting client...");
            break;
        }
        else{ //if not send input to server and receive output by sever
        send(s, input, strlen(input), 0);
        len = recv(s, output, BUFFER, 0);
        output[len] = '\0';
        printf("%s\n", output);// print output by server
        memset(input, 0, sizeof(input)); // reset input and output
        memset(output, 0, sizeof(output));
        }

    }
    close(s);
    WSACleanup();
}