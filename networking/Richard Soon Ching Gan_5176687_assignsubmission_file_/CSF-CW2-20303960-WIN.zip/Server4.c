//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<windows.h>
#include<time.h>

#define MY_PORT		8989
#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer1[MAXBUF];
    char buffer2[MAXBUF];
	int length;
	char exitserver[] = "exit server";
    char senddate[] = "date";
    char senddate1[] = "date1";
    char senddate2[] = "date2";
    char senddate3[] = "date3";
	int port;
  	port = atoi(argv[1]);
	char* ip;

   char date[50];// setting date
   char date1[50];
   char date2[50];
   char date3[50];
   struct tm *local;
   time_t t;
   time(&t);
   local = localtime(&t);
   strftime(date, sizeof(date), "%d-%m-%y %I\r\n", local);// save date format dd/mm/yy hh to date
   strftime(date1, sizeof(date1), "%Y\r\n", local);// save date format yyyy to date1
   strftime(date2, sizeof(date2), "%I\r\n", local);// save date format hh to date2
   strftime(date3, sizeof(date2), "%d-%b-%y\r\n", local);// save date format dd/mon/yy hh to date3



    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(port);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;
	ip = inet_ntoa(self.sin_addr);

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		printf("%s\n", inet_ntoa(client_addr.sin_addr));
		printf("%d\n", port);
        while(1){//loop
		int recv_size = recv(clientfd, buffer1, MAXBUF, 0);
		length = strlen(buffer1);
		if( strcmp(buffer1, exitserver) == 0){//compare buffer1 and exitserver
            break;
        }
        else if( strcmp(buffer1, senddate) == 0){//compare buffer1 and date, if true send date to client
            strcpy(buffer2, date);
            send(clientfd, buffer2, sizeof(date), 0);
			memset(buffer1, 0, sizeof(buffer1));
			memset(buffer2, 0, sizeof(buffer2));
        }
        else if( strcmp(buffer1, senddate1) == 0){//compare buffer1 and date1, if true send date1 to client
            strcpy(buffer2, date1);
            send(clientfd, buffer2, sizeof(date1), 0);
			memset(buffer1, 0, sizeof(buffer1));
			memset(buffer2, 0, sizeof(buffer2));
        }
        else if( strcmp(buffer1, senddate2) == 0){//compare buffer1 and date2, if true send date2 to client
            strcpy(buffer2, date2);
            send(clientfd, buffer2, sizeof(date2), 0);
			memset(buffer1, 0, sizeof(buffer1));
			memset(buffer2, 0, sizeof(buffer2));
        }
        else if( strcmp(buffer1, senddate3) == 0){//compare buffer1 and date3, if true send date3 to client
            strcpy(buffer2, date3);
            send(clientfd, buffer2, sizeof(date3), 0);
			memset(buffer1, 0, sizeof(buffer1));
			memset(buffer2, 0, sizeof(buffer2));
        }
        else{// else send capitalized message to client
			for(int i = 0; buffer1[i] != '\0'; i++){
				buffer2[i] = toupper(buffer1[i]);
			}
			if(buffer2[0] != '\r'){
					printf("%s\n", buffer2);
				}
			send(clientfd, buffer2, recv_size, 0);
			
			printf("%d\n", length);
			memset(buffer1, 0, sizeof(buffer1));
			memset(buffer2, 0, sizeof(buffer2));
			}
		}
        close(clientfd);
		return 0;
		/*---close connection---*/
		    
		
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}