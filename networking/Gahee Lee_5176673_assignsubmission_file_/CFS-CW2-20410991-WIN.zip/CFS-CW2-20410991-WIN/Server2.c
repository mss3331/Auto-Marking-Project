//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<stdlib.h>
#include<string.h>

#define MAXBUF		256

int main(int argc, char* argv[])
{
	WSADATA wsa;
	SOCKET sockfd, clientfd;
	struct sockaddr_in self;
	

	printf("\nInitialising Winsock...");
	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
	{
		printf("Failed. Error Code : %d", WSAGetLastError());
		return 1;
	}

	printf("Initialised.\n");

	/*---create streaming socket---*/
	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		perror("Socket");
		exit(errno);
	}

	printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(atoi(argv[1]));	// Port entered by the user
	self.sin_addr.s_addr = INADDR_ANY;

	/*---assign a port number to the socket---*/
	if (bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0)
	{
		perror("socket--bind");
		exit(errno);
	}

	puts("Bind done");

	/*---make it a "listening socket"---*/
	if (listen(sockfd, 20) != 0)
	{
		perror("socket--listen");
		exit(errno);
	}


	puts("Waiting for incoming connections...");

	struct sockaddr_in client_addr;
	int addrlen = sizeof(client_addr);

	/*---accept a connection (creating a data pipe)---*/
	clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);

	//Output the ip address and port number of the client to the server
	char str[1000] = "Ip Address : ";
	
	char str2[10];
	itoa(ntohs(client_addr.sin_port), str2, 10);

	strcat(str, inet_ntoa(client_addr.sin_addr));
	strcat(str, "Port : ");
	strcat(str, str2);
	printf("%s \n", str);


	close(clientfd);

	
	while (1)
	{
		int i = 0;
		char buffer[MAXBUF];
		
		int recieve = recv(clientfd, buffer, MAXBUF, 0);
		
		//if the client input message is “exit server" then, closes the connection and terminate
		if (strcmp(buffer, "exit server") == 0) {
			close(clientfd);
			break;
		}

		//Lowercase letters are converted into uppercase
		for (i = 0;buffer[i] ; i++) {

			if ((buffer[i] >= 'a') && (buffer[i] <= 'z')) {
				buffer[i] = buffer[i] - 'a' + 'A';
			}

		}

		//Checking the number of words 
		int sendSzie = send(clientfd, buffer, recieve, 0);

		memset(buffer, 0, sizeof buffer);

		//print the number of words
		printf("%d \n", sendSzie);
		close(clientfd);
		
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
	WSACleanup();
	return 0;
}

