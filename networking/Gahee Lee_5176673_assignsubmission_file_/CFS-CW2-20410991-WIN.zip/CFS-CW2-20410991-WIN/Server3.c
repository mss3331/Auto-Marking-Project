//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<stdlib.h>
#include<string.h>
#include <time.h>

#define MAXBUF		256

int main(int argc, char* argv[])
{
	WSADATA wsa;
	SOCKET sockfd, clientfd;
	struct sockaddr_in self;
	

	printf("\nInitialising Winsock...");
	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
	{
		printf("Failed. Error Code : %d", WSAGetLastError());
		return 1;
	}

	printf("Initialised.\n");

	/*---create streaming socket---*/
	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		perror("Socket");
		exit(errno);
	}

	printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(atoi(argv[1]));	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;

	/*---assign a port number to the socket---*/
	if (bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0)
	{
		perror("socket--bind");
		exit(errno);
	}

	puts("Bind done");

	/*---make it a "listening socket"---*/
	if (listen(sockfd, 20) != 0)
	{
		perror("socket--listen");
		exit(errno);
	}


	puts("Waiting for incoming connections...");

	struct sockaddr_in client_addr;
	int addrlen = sizeof(client_addr);

	/*---accept a connection (creating a data pipe)---*/
	clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
	//Output the ip address and port number of the client to the server
	char str[1000] = "Ip Address : ";
	
	char str2[10];
	itoa(ntohs(client_addr.sin_port), str2, 10);

	strcat(str, inet_ntoa(client_addr.sin_addr));
	strcat(str, "Port : ");
	strcat(str, str2);
	printf("%s \n", str);

	close(clientfd);
	
	while (1)
	{
		int i = 0;
		char buffer[MAXBUF];
		
		int recieve = recv(clientfd, buffer, MAXBUF, 0);

		int sendSzie = 0;
		if (strcmp(buffer, "exit server") == 0) { 	//if the client input message is “exit server" then, closes the connection and terminate
			printf("exit server");
			close(clientfd);
			break;
		}else if(strcmp(buffer, "date") == 0) {  // When data is input, output in dd-MM-yy hh format
			printf("date");
			time_t t = time(NULL);
			struct tm tm = *localtime(&t);

			int year = tm.tm_year + 1900-2000;
			int month = tm.tm_mon + 1;
			int day = tm.tm_mday;
			int hour = tm.tm_hour;

			char date[11] = "";
			char d[2];
			itoa(day, d, 10);
			
			if (day < 10) {
				date[0] = '0';
				date[1] = d[0];

			}
			else {
				date[0] = d[0];
				date[1] = d[1];
			}

			strcat(date, "-");
			
			char m[2];
			if (month < 10) {
				strcat(date, "0");
			}
			itoa(month, m, 10);
			strcat(date, m);
			strcat(date, "-");
			
			char y[2];
			itoa(year, y, 10);
			strcat(date, y);
			strcat(date, " ");
		
			char h[2];
			if (hour < 10) {
				strcat(date, "0");
			}
			itoa(hour, h, 10);
			strcat(date, h);
		
			sendSzie = send(clientfd, date, sizeof(date), 0);

		}else {
			//Lowercase letters are converted into uppercase
			for (i = 0; buffer[i]; i++) {

				if ((buffer[i] >= 'a') && (buffer[i] <= 'z')) {
					buffer[i] = buffer[i] - 'a' + 'A';
				}

			}
			 sendSzie = send(clientfd, buffer, recieve, 0);
		}

		memset(buffer, 0, sizeof buffer);

		printf("%d \n", sendSzie);
		close(clientfd);
		
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
	WSACleanup();
	return 0;
}

