//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>

#define MAXBUF 256


int main(int argc , char *argv[])
{
WSADATA wsa;
SOCKET sockfd , clientfd;
    struct sockaddr_in self;
char buffer[MAXBUF];


int MY_NEW_PORT;
if(argc==2)
{
    MY_NEW_PORT=atoi(argv[1]);
}
else {
    printf("Error, please try again\n");
	scanf("%d",&MY_NEW_PORT);
    return 1;
}

printf("\nInitialising Winsock...");
if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
{
    printf("Failed. Error Code : %d",WSAGetLastError());
    return 1;
}

printf("Initialised.\n");


/*---create streaming socket---*/
if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
{
    perror("Socket");
    exit(errno);
}


    printf("Socket created.\n");



/*---initialize address/port structure---*/
/* bzero(&self, sizeof(self));*/
self.sin_family = AF_INET;
self.sin_port = htons(MY_PORT); // Host to Network Short (16-bit)
self.sin_addr.s_addr = INADDR_ANY;


/*---assign a port number to the socket---*/
if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
{
    perror("socket--bind");
    exit(errno);
}



    puts("Bind done");


/*---make it a "listening socket"---*/
if ( listen(sockfd, 20) != 0 )
{
    perror("socket--listen");
    exit(errno);
}

    puts("Waiting for incoming connections...");



/*---forever... ---*/
printf("Please enter 'exit client' to close\n\n\n");
while (1)
{   struct sockaddr_in client_addr;
    int addrlen=sizeof(client_addr);
	int input;
	
	printf("enter input: ");
	gets(input);
	printf("\n");

    /*---accept a connection (creating a data pipe)---*/
     if(strlen(input) > 0)
	 {
	     int toresult = send(sockfd, userinput, strlen(userinput) + 1,0);
		 if(toresult != SOCKET_ERROR)
		 {
			 int bytereceive;
		     int bytereceive = recv(sockfd, buffer, MAXBUF, 0);
			 if(bytereceive > 0)
			 {
			     printf("SERVER reply: %s\n\n", buffer);
			 }
		 }
	 }
	 
	 if((strcmp(input, "exit client", 10)) == 0)
	 {  
	     close(sockfd);
		 exit(errno);
	 }
	 memset(buffer, 0, sizeof(buffer));
}


/*---clean up (should never get here!)---*/
close(sockfd);
    WSACleanup();
return 0;
}