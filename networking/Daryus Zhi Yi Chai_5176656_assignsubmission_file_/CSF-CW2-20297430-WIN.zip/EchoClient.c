//////////////////////////  Server.c ////////////////
#include<io.h>
#include<stdio.h>
#include<winsock2.h>


#define MAXBUF		256

int main(int argc, char *argv[])
{
	
    WSADATA wsa;
    SOCKET sockfd;
   	struct sockaddr_in server;
	char buffer[MAXBUF];

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");
	
	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	server.sin_family = AF_INET;
	server.sin_port = htons(8989);// Host to Network Short (16-bit)
	server.sin_addr.s_addr =inet_addr("127.0.0.1");


    if( connect(sockfd, (struct sockaddr *)&server, sizeof(server)) < 0)
    {
       printf("\n Error : Connect Failed \n");
       return 1;
    } 


	/*---forever... ---*/
	while (1)
	{	
		int readsize;
	
  		printf("New Message To Echo: ");
        fgets(buffer,MAXBUF,stdin);  
		
		if(strlen(buffer) == 0)
		{
            printf("Sorry, you are trying to send an empty message\n");
            break;  
        }

 
	   if( send(sockfd , buffer , strlen(buffer) , 0) < 0)
        {
            puts("Send failed");
            return 1;
        }

  		if (strcmp(buffer,"exit client\n")==0)
		{
			break;	
		}
		
        readsize = recv(sockfd, buffer, sizeof(buffer)-1,0);
        if( readsize > 0 )
        {
            buffer[MAXBUF] = '\0';
            printf("%s\n",buffer);
        }
        else{
            break;
        }
    	
	}    
	
	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}
