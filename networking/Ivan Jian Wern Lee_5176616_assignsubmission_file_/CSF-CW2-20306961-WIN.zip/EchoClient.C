#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

int main()
{
   int client_to_server;
   char *myfifo = "/tmp/client2server";

   int server_to_client;
   char *myfifo2 = "/tmp/server2client";

   char str[255];

   /* write str to the FIFO */
   client_to_server = open(myfifo, O_WRONLY);
   server_to_client = open(myfifo2, O_RDONLY);
   while(1)
   {
       printf("\n> ");
   scanf("%s", str);
   write(client_to_server, str, sizeof(str));
   read(server_to_client,str,sizeof(str));
   printf("From server: %s\n",str);
   }

   close(client_to_server);
   close(server_to_client);

   /* remove the FIFO */
   unlink("/tmp/server2client");
   unlink("/tmp/client2server");

   return 0;
}