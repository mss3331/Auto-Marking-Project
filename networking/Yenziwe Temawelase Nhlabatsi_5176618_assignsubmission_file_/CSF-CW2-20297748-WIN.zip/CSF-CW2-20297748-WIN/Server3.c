//////////////////////////  Server3.c ////////////////

#include<io.h>
#include<stdio.h>
#include<string.h>
#include<time.h>
#include<winsock2.h>


#define MAXBUF      256

int main(int argc , char *argv[])
{
    while(1)                                                                            	//infinite loop
    {
        WSADATA wsa;
        SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
        char buffer[MAXBUF], MY_PORT[5];
        int in=0;

    memset(MY_PORT, 0, 5);
    printf("Enter port number: \n");                                                    	//allows user to enter target port number each time new connection established
    while((MY_PORT[in++] = getchar()) != '\n');

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");																	//prints if socket could not be created
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(atoi(MY_PORT));	  												//convert port number from string to integer
	self.sin_addr.s_addr = INADDR_ANY;

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done. \n");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}

        puts("Waiting for incoming connections...");

		struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		do																					//completes floowing code until user enters 'exit server'
	{
		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		printf("Connected to client %c via port %u \n", self.sin_addr.s_addr, MY_PORT);		//prints out IP address and port number

		send(clientfd, strupr(buffer), recv(clientfd, buffer, MAXBUF, 0), 0);				//strupr converts user input to uppercase

		if ((strcmp(buffer, "DATE"))==0)                                                    //prints date and time (DD-MM-YYYY HH) if user enters date
		{
		    time_t t;
		    t = time(NULL);
		    struct tm tm = *localtime(&t);
		    printf("%d-%d-%d %d \n", tm.tm_mday, tm.tm_mon+1, tm.tm_year+1900, tm.tm_hour); //add 1 to month so it starts counting from 1 not 0; add 1990 to year as it counts years since 1900
		}


		printf("String length is %u \n\n", strlen(buffer));                                 //prints the length of the user's input

	} while ((strcmp(buffer, "EXIT SERVER"))!=0);											// condition and end of do...while loop
    /*---close connection---*/
		close(clientfd);


     /*---clean up (should never get here!)---*/
        close(sockfd);
        WSACleanup();
    }
        return 0;
}
