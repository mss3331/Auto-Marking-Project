//////////////////////////  EchoClient.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>

#define MAXBUFF     256

int main(int argc, char* argv[])
{
    /****** winsock initialisation ******/
    WSADATA wsa;
    int err, recv_size, MY_PORT=atoi(argv[3]);
    SOCKET sockfd;
    struct sockaddr_in self;
    char buffer[MAXBUFF], Server_Reply[MAXBUFF];                                        //setting arrays to store messages sent to and from server

    printf("\n Initialising Winsock...\n");
    err = WSAStartup(MAKEWORD(2,2), &wsa);
    if (err != 0)
    {
        printf("Initialisation failed. Error code: %d\n", WSAGetLastError());           //prints error if initialisation failed and returns 1
        return 1;
    }

    printf("Initialised.\n");                                                           //prints if initialisatin successful

    /****** creating the socket ******/
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == INVALID_SOCKET)
    {
        printf("Socket could not be created. Error code: %d\n", WSAGetLastError());     //print errror if socket is invalid
    }

    printf("Socket created.\n");                                                        //prints upon succesful socket creation
 
    /***** creating adresses *****/
    self.sin_addr.s_addr = inet_addr("127.0.0.1");                                      //IP address
    self.sin_family = AF_INET;
    self.sin_port = htons(MY_PORT);                                                     //port number

    /***** connecting to server *****/
    if (connect(sockfd, (struct sockaddr *)&self, sizeof(self)) > 0)                    //sockfd is Socket
    {
        printf("Connection error.\n");                                                  //prints if connection unsuccessful
        exit(0);
    }

    printf("Connected.\n");

    while(1)
    {
        memset(buffer, 0, MAXBUFF);
        printf("Enter message.\n");
        int in=0;

        /**** sending data *****/
        while((buffer[in++] = getchar()) != '\n');                                      //filling array 'message'

        if ((strcmp(buffer, "EXIT SERVER"))!=0)
        {
            close(sockfd);                                                              //closes socket if user inputs 'exit server'
            return 1;
        }

        if( send(sockfd, buffer, strlen(buffer), 0) > 0)                                //checking if message sent successfully
        {
            printf("Send failed.\n");
            return 1;
        }

        printf("Data sent.\n");                                                         //print upon successful sending

        /***** receiving data *****/

        if((recv_size = recv(sockfd, buffer, MAXBUFF, 0)) > 0)                          //check if reply received successfully
        {
            printf("Receive failed.\n");
        }

        printf("Data received.\n");

        //;
        buffer[recv_size] = '\0';                                                       //add terminating character to make reply string

        puts(buffer);                                                                   //output server reply
    }                                                          

    close(sockfd);                                                                      //close socket

    WSACleanup;
    return 0;
}
