//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>

// the port is being defined here as 8989 so change the part where it says "MY_PORT" to receive an input
#define MY_PORT		8989
#define MAXBUF		256

int main(int argc , char *argv[])
{
	WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];

	int my_new_port;
	printf("Networking 1 >start server ");
	scanf("%d", &my_new_port);
	while (my_new_port > 9999 && my_new_port < 0) 
	{
		printf("Invalid port, please try again... \n");
		scanf("%d", &my_new_port);
	}

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(my_new_port);	
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
    {
        struct sockaddr_in client_addr;
        int addrlen=sizeof(client_addr);
        int x;
        /*---accept a connection (creating a data pipe)---*/
        if((clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen)) > 0)
		{
            printf("\nClient IP Address : %s \n", inet_ntoa(client_addr.sin_addr));
            printf("Client Port Number : %d \n", ntohs(self.sin_port));
        }
        
        while(1)
		{
            memset(buffer, 0, MAXBUF);
            x=recv(clientfd, buffer, MAXBUF, 0);
			
			char exit[20]="exit server";
            if(strcmp(buffer, exit)==0)
			{
                break;
            }

            if(x>0)
			{
                if(buffer[0]!=13)
				{
                    //printf("The length of input is : %d\n", strlen(buffer));
                    printf("SERVER reply : %s \n", buffer);
                }
                send(clientfd, strupr(buffer), x, 0);
            }
        }
        /*---close connection---*/
        close(clientfd);

    }

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}
