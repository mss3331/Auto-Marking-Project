//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>

// the port is being defined here as 8989 so change the part where it says "MY_PORT" to receive an input
#define MY_PORT		8989
#define MAXBUF		256

int main(int argc , char *argv[])
{
	// something needed to be initialised. socket fd stuff is for the port being the locations of the port and the details of the port so u will know which port to use after calling it. Same for client fd. its a socket for the client 
    // wsa is specifically for windows. 
	WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	// buffer for memory because u need to read things from the port that u have specified 
	char buffer[MAXBUF];

	// put new port that u will use later on 
	int my_new_port;
	printf("Networking 1 >start server ");
	scanf("%d", &my_new_port);
	while (my_new_port > 9999 && my_new_port < 0) 
	{
		printf("Invalid port, please try again... \n");
		scanf("%d", &my_new_port);
	}

    printf("\nInitialising Winsock...");
	// just detecting error makign sure wsa is what it is expected to be 
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	// Here "MY_PORT" is being used
	// self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)

	// change it to take an input
	// from what the spec said is that it wanted it to take input of 
	self.sin_port = htons(my_new_port);	
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
	// just amkign sure that u have binded the socket
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		
		send(clientfd, strupr(buffer), recv(clientfd, buffer, MAXBUF, 0), 0);

		/*---close connection---*/
		close(clientfd);
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}
