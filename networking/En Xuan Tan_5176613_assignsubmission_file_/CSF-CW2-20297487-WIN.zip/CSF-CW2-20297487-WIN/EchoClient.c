// Client side
//cd C:\Users\HP\Documents\Autumn CompSci\Computer Fundamental\Coursework 2
//gcc EchoClient.c -o EchoClient -lws2_32
//EchoClient.exe 8989
//CLIENT AND SERVER MUST HAVE SAME PORT NO.

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<time.h>
#define MAXBUF 256

int main(int argc, char const *argv[])
{
	WSADATA wsa;
    SOCKET sockfd ;
	int n = 0, sen = 0;
	
	
	//declare address for socket
    struct sockaddr_in self;
	struct hostent *server;
	//buffer for message
	char buffer[MAXBUF] = {0} ; //
	
    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");
	
	//CREATE SOCKET
	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(1);
	}

    printf("Socket created.\n");
	
	self.sin_family = AF_INET;
	//argv[1] is used to take the port number in the command prompt.
	self.sin_port = htons(atoi(argv[1]));	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = inet_addr("127.0.0.1");
	
	
	int con;
	
	//Connect client to server
	con = connect( sockfd, (struct sockaddr *) &self, sizeof(self));
	
	if(con < 0)

     {
          printf("Client: connect() failed! Error code: %ld\n", WSAGetLastError());
		  exit(1);

     }

     else{

          printf("Connected\n");
		  
	 }
	
	
	//send and receive data continously
	do
	{
		
	//prompt input from user
	printf("Please enter the message: ");
	gets(buffer);
	
	//send input to server
	sen = send(sockfd, buffer, sizeof(buffer) , 0);
	if (sen < 0 ){
		printf("Send Failed");
		exit(1);
	}
	
		//receive message from server
		n = recv(sockfd, buffer, sizeof(buffer), 0);
		if ( n > 0 ){
			printf("%s\n", buffer);
		}else{
			printf("Received Failed\n");
			exit(1);
		}
		
	}while(strcmp(buffer, "exit server") != 0);//end do-while
	
/*---clean up (should never get here!)---*/
	close(sockfd);
    WSACleanup();
	return 0;
	
}