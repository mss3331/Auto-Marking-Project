//////////////////////////  Server.c ////////////////
//cd C:\Users\HP\Documents\Autumn CompSci\Computer Fundamental\Coursework 2
//gcc Server4.c -o Server4 -lws2_32
//Server4.exe 8989 

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<time.h>

//#define MY_PORT		8989
#define MAXBUF		256

int main(int argc , char *argv[])
{
	
	
    WSADATA wsa;
	//sockfd used to listen to client and clientfd is created
    SOCKET sockfd , clientfd;
	
	//declare address for socket
    struct sockaddr_in self;
	//byffer for message
	char buffer[MAXBUF];
	
	//declaration for date commands
	char s[100];		
	time_t t = time(NULL);
	struct tm tm = *localtime(&t);
	
    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");
	
	//CREATE SOCKET
	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(1);
	}

        printf("Socket created.\n");
	
	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	//argv[1] is used to take the port number in the command prompt.
	self.sin_port = htons(atoi(argv[1]));	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;   //accept any ip adress
	
	//BIND
	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(1);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(1);
	}
        
        puts("Waiting for incoming connections...");
		
	/*---forever... ---*/
	
	
	while(1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		printf("Connection Established\n");
		
		//keep accepting client requests unless "exit server" is typed in
		while(strcmp(buffer, "exit server") != 0)
		{
			
		//initialize buffer to 0
		for (int i = 0;i < MAXBUF - 1 ; i++ ){
			
		buffer[i] = 0;
		
		}
		
		//initialize s to 0 (for DATE function)
		for (int i = 0;i < 100 ; i++ ){
			
		s[i] = 0;
		
		}
		
		//receive client input
		recv(clientfd, buffer, MAXBUF, 0);
		
		//Impementation for EXIT SERVER command
		if ( strcmp(buffer, "exit server") == 0){
			
			printf("Client has closes the connection");
			close(clientfd); //close connection
			
		}
		
		//DISPLAY DATES
		else if ( strcmp(buffer, "date") == 0){
			
			sprintf(s,"CURRENT DATE: %d-%02d-%02d %02d\n", tm.tm_mday , tm.tm_mon + 1, (tm.tm_year + 1900)%100, tm.tm_hour );
		
			send(clientfd, s, sizeof(s) , 0);
			}
		else if ( strcmp(buffer, "date1") == 0){
			
			sprintf(s,"CURRENT YEAR: %d\n", tm.tm_year + 1900 );
		
			send(clientfd, s, sizeof(s) , 0);
			}
		else if ( strcmp(buffer, "date2") == 0){
			
			sprintf(s,"CURRENT HOUR: %02d\n", tm.tm_hour );
		
			send(clientfd, s, sizeof(s) , 0);
			}
		else if ( strcmp(buffer, "date3") == 0){
			char mon[4];
			if(tm.tm_mon + 1 == 1)
				strcpy( mon, "Jan" );
			else if(tm.tm_mon + 1 == 2)
				strcpy( mon, "Feb" );
			else if(tm.tm_mon + 1 == 3)
				strcpy( mon, "Mar" );
			else if(tm.tm_mon + 1 == 4)
				strcpy( mon, "Apr" );
			else if(tm.tm_mon + 1 == 5)
				strcpy( mon, "May" );
			else if(tm.tm_mon + 1 == 6)
				strcpy( mon, "Jun" );
			else if(tm.tm_mon + 1 == 7)
				strcpy( mon, "Jul" );
			else if(tm.tm_mon + 1 == 8)
				strcpy( mon, "Aug" );
			else if(tm.tm_mon + 1 == 9)
				strcpy( mon, "Sep" );
			else if(tm.tm_mon + 1 == 10)
				strcpy( mon, "Oct" );
			else if(tm.tm_mon + 1 == 11)
				strcpy( mon, "Nov" );
			else
				strcpy( mon, "Dec" );
			
			sprintf(s,"CURRENT DATE: %d-%s-%02d\n", tm.tm_mday , mon , (tm.tm_year + 1900)%100 );
		
			send(clientfd, s, sizeof(s) , 0);
			}
		
		else{
		//CONVERT TO UPPERCASE
		
		int sum = 0;
		for (int i = 0;i < buffer[i] ; i++ ){
			
          buffer[i] = toupper(buffer[i]);
		  sum+=1;
        }
		
		send(clientfd, buffer, MAXBUF , 0);
		
		
		//DISPLAY IP ADDRESS, PORT NUMBER, LENGTH OF MESSAGE SENT BY CLIENT
		printf("The IP address is: %s\n",inet_ntoa(client_addr.sin_addr));
		printf("The Port number is: %d\n",client_addr.sin_port);
		printf("Length of message sent by client: %d\n\n",sum);
		
		}
		
		}//end while
		
	}//end while

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}