//////////////////////////  Server.c ////////////////
//cd C:\Users\HP\Documents\Autumn CompSci\Computer Fundamental\Coursework 2
//gcc Server1.c -o Server1 -lws2_32
//Server1.exe 8989 

#include<io.h>
#include<stdio.h>
#include<winsock2.h>


//#define MY_PORT		8989
#define MAXBUF		256

int main(int argc , char *argv[])
{
	
	
    WSADATA wsa;
	//sockfd used to listen to client and clientfd is created
    SOCKET sockfd , clientfd;
	
	//declare address for socket
    struct sockaddr_in self;
	char buffer[MAXBUF];
	
    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");
	
	//CREATE SOCKET
	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(1);
	}

        printf("Socket created.\n");
	
	/*---initialize address/port structure---*/
	self.sin_family = AF_INET;
	//argv[1] is used to take the port number in the command prompt.
	self.sin_port = htons(atoi(argv[1]));	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  //accept any ip adress
	
	//BIND
	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(1);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(1);
	}
        
        puts("Waiting for incoming connections...");
		
	/*---forever... ---*/
	
	
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen = sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		printf("Connection Established\n");
		
		//initialize buffer to 0
		for (int i = 0;i < MAXBUF - 1 ; i++ ){
			
		buffer[i] = 0;
		
		}
		//receive client input
		recv(clientfd, buffer, MAXBUF, 0);
		
		printf("Message received from client: %s\n", buffer);
		
		//Impementation for EXIT SERVER command
		if ( strcmp(buffer, "exit server") == 0){
			printf("Client has closes the connection");
			close(clientfd);
			
		}
		else{
		//CONVERT TO UPPERCASE
		for (int i = 0;i < MAXBUF - 1 ; i++ ){
			
          buffer[i] = toupper(buffer[i]);
        }
		//send message to the client side
		printf("Message send to client: %s\n", buffer);
		send(clientfd, buffer, MAXBUF , 0);
		
		
		/*---close connection---*/
		close(clientfd);
		}
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}

