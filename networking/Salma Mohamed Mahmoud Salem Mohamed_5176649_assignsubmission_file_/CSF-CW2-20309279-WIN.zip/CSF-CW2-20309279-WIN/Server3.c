#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<ctype.h>
#include<string.h>
#include<time.h>
#include <windows.h>

#define MY_PORT		8989
#define MAX		256
#define Size 12
int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockServer , clientSocket;
    	struct sockaddr_in self;
	char message[MAX];
    char messagedate[MAX];
	int i,j ,temp;
	int numbytes,a;
    time_t t ;
	struct tm *tmp ;
	char MY_TIME[Size];
	time( &t );
    

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	
    if ( (sockServer = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;

	
    if ( bind(sockServer, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	
	if ( listen(sockServer, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}

        puts("Waiting for incoming connections...");

	
    while (1){

        struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		
		clientSocket = accept(sockServer, (struct sockaddr*)&client_addr, &addrlen);

		char *ip = inet_ntoa(client_addr.sin_addr);

        while (1){

        
        
        

        memset(message,0,sizeof(message));

        numbytes = recv(clientSocket, message, MAX, 0);
        if (strncmp(message,"date",4)==0){



            tmp = localtime( &t );
            //strftime(MY_TIME, sizeof(MY_TIME), "%d-%m-%y %I",messagedate);
	      // using strftime to display time
	      sprintf(messagedate, "%02d-%02d-%02d %02d", tmp->tm_mday, tmp->tm_mon+1, tmp->tm_year +1900, tmp->tm_hour);
          send(clientSocket, messagedate, sizeof(messagedate), 0);
	      return(0);


            

        }
        else

        {
         int length=strlen(message)-1;

        if (message[0]!='\r'&&message[0]!='\n')
        {

        printf("\nIP address of the client : %s",ip);
        printf("\nPort number targeted by client's request : %d",client_addr.sin_port);

        printf("\nlength of the message sent was: %d\n",numbytes);


        for (i = 0 ; i < numbytes; i++)
            {
            if (message[i]!='\n')
            message[i] =  toupper(message[i]);
            }

    
        }  // end if statement

            send(clientSocket,message, numbytes , 0);

            if(strcmp(message, "exit server") == 0){
            close(clientSocket);
            printf("[-]Disconnected from server.\n");
            exit(1);
            }

            memset(message,0,numbytes);
        }  // end else statement



        }

		//close connection

		close(clientSocket);

            }


	//clean up 
	close(sockServer);
        WSACleanup();

	return 0;
    }


//gcc Server3.c -o Server3 -lws2_32