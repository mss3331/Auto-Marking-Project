 
//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<ctype.h>
#include<string.h>

#define MY_PORT		8989
#define MAX		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockserver , clientSocket;
    	struct sockaddr_in self;
	char message[MAX];
	int i,j , temp;
	int numbytes=0;
	int a;
   

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	
    if ( (sockserver = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;


    if ( bind(sockserver, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	
	if ( listen(sockserver, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}

        puts("Waiting for incoming connections...");

	
    while (1){

        struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		
		clientSocket = accept(sockserver, (struct sockaddr*)&client_addr, &addrlen);

		char *ip = inet_ntoa(client_addr.sin_addr);

        printf("\nIP address of the client : %s",ip);
        printf("\nPort number targeted by client's request : %d ",client_addr.sin_port);

        while (1){




        memset(message,0,sizeof(message));



        numbytes = recv(clientSocket, message,MAX, 0);


        int length=strlen(message)-1;

       if (message[0]!='\r'&& message[0]!='\n')
            {

        printf("\nlength of the message sent was: %d\n",numbytes);


            for (i = 0 ; i < numbytes; i++)
                {
            if (message[i]!='\n')
            message[i] =  toupper(message[i]);
                }

            


            send(clientSocket, message,numbytes , 0);

           

              memset(message,0,numbytes);

        }

        }

		
		close(clientSocket);


        }

	
	close(sockserver);
        WSACleanup();
	return 0;
    }

// gcc Server2.c -o Server2 -lws2_32
