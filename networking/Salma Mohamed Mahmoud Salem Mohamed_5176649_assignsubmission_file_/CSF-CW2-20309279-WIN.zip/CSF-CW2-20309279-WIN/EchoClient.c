#include <winsock2.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <io.h>
#define MAX 80
#define PORT 8989
#define SA struct sockaddr



int main(int argc,char *argv[])
{
    int sockserver, connsocket, clientSocket;
    struct sockaddr_in servaddr, cli;
    WSADATA wsa;

     printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

    // socket create and varification
    sockserver = socket(AF_INET, SOCK_STREAM, 0);
    if (sockserver == -1) {
        printf("socket creation failed...\n");
        perror("socket");
        exit(errno);
    }
    else
        printf("Socket successfully created..\n");

    memset(&servaddr, 0 , sizeof(servaddr));

    // assign IP, PORT
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
    servaddr.sin_port = htons(PORT);

    // connect the client socket to server socket
    if (connect(sockserver, (SA*)&servaddr, sizeof(servaddr)) != 0) {
        printf("connection with the server failed...\n");
        exit(errno);
    }
    else
    {
        printf("connected to the server..\n");


    char message[MAX];
    int n;
    for (;;)
        {
        memset(message,0, sizeof(message));
        printf("Enter the string : ");

        n = 0 ;

      while ((message[n++] = getchar())!= '\n');



        int length = strlen(message)-1;

        send(sockserver, message, length ,0);

         if(strcmp(message, "exit client") == 0){
            close(clientSocket);
            printf("[-]Disconnected from server.\n");
            exit(1);
        }

        char servreply[256];

        memset(servreply,0,256);

        recv(sockserver, servreply, 256 ,0);

        printf("From Server : %s\n", servreply);

        if ((strncmp(message, "EXIT", 4)) == 0)
            {
            printf("Client Exit...\n");
            break;
            }
        }  // end for loop

    }
    // close the socket
    close(sockserver);

    
    WSACleanup();
    return 0;
}
  //gcc EchoClient.c -o EchoClient -lws2_32
