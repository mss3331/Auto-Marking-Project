#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<ctype.h>
#include<time.h>


#define MY_PORT		user_enter
#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];
    int n=1;
    int result;

    int user_enter;
    printf("Enter port number: Start Server ");
    scanf("%d",&user_enter);


    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");
        int counter=1;
        int i;
        SOCKET newCon;
        SOCKADDR_IN addr;
        

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);
        //newCon=accept(sockfd,(struct sockaddr*)&client_addr,&addrlen);
            /*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
        char *ptr=inet_ntoa(client_addr.sin_addr);
        printf("IP:%s",ptr);
        printf("\nport number: %d",user_enter);
        //time
        int t=1;
        int uppercase = 1;
        time_t k;
		k = time(NULL);
		struct tm tm = *localtime(&k);
        //puts(client_addr);
        //char *ip = inet_ntoa(addr.sin_addr);
        //printf("IP is: %s", ip);
          while (t==1) {
             uppercase = recv(clientfd, buffer, MAXBUF, 0);

             if(strcmp(buffer, "date") == 0){
				printf("\nCurrent Date and time: %d-%d-%d\t%d", tm.tm_mday, tm.tm_mon + 1, tm.tm_year - 100, tm.tm_hour);
                }
				//exit the program
             if(strcmp(buffer, "exit server")==0){
                    printf("\nTerminated");
                    t=0;
                    break;
                }
				//display year
             if (strcmp(buffer, "date1") == 0) {
				printf("\n%d", tm.tm_year + 1900);
			}

			//display hour
			if (strcmp(buffer, "date2") == 0) {
				printf("\n%d\n", tm.tm_hour);
			}

			//display month
			if (strcmp(buffer, "date3") == 0) {
				int mon;
				mon = tm.tm_mon + 1; //1 is added because it starts from 0. 0 invalid month.
				//switch case is based on month that the computer is in.
				switch (mon) {
				// each case corresponds to a month, case1=january, case2=february, etc		
				case 1:
					printf("\n%d-Jan-%d", tm.tm_mon,tm.tm_year - 100);
					break;

				case 2:
					printf("\n%d-Feb-%d", tm.tm_mon, tm.tm_year - 100);
					break;

				case 3:
					printf("\n%d-Mar-%d", tm.tm_mon, tm.tm_year - 100);
					break;

				case 4:
					printf("\n%d-Apr-%d", tm.tm_mon, tm.tm_year - 100);
					break;

				case 5:
					printf("\n%d-May-%d", tm.tm_mon, tm.tm_year - 100);
					break;

				case 6:
					printf("\n%d-Jun-%d", tm.tm_mon, tm.tm_year - 100);
					break;

				case 7:
					printf("\n%d-Jul-%d", tm.tm_mon, tm.tm_year - 100);
					break;

				case 8:
					printf("\n%d-Aug-%d", tm.tm_mon, tm.tm_year - 100);
					break;

				case 9:
					printf("\n%d-Sep-%d", tm.tm_mon, tm.tm_year - 100);
					break;

				case 10:
					printf("\n%d-Oct-%d", tm.tm_mon, tm.tm_year - 100);
					break;

				case 11:
					printf("\n%d-Nov-%d", tm.tm_mon, tm.tm_year - 100);
					break;

				case 12:
					printf("\n%d-Dec-%d\n", tm.tm_mon, tm.tm_year - 100);
					break;
				}
			}
            else{
                    for (i = 0; i <= uppercase - 1; i++) {
                        buffer[i] = toupper(buffer[i]);
                        }
                        printf("\nlength of message is:%d",i);
                }
                send(clientfd, buffer, uppercase, 0);//send capitalized buffer out to be displayed
                memset(buffer, 0, sizeof(buffer)); //clears buffer after it is send to be displayed
            }
          // puts(buffer);  
          // printf("\n%d",i);
                        
		//while(strcmp(buffer, "exit server")!= 0){                
		//send(clientfd, buffer, recv(clientfd, buffer, MAXBUF, 0), 0);
            //result=strcmp(buffer,"exit client");
                //if(result==0){
                  //  n=0;
                   // printf("terminated");
                    //close(clientfd);
                    //return 0;
          //      }

		/*---close connection---*/
        close(clientfd);
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
  
}