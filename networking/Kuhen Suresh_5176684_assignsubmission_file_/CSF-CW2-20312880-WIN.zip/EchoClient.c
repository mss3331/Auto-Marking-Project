//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<ctype.h>

#define MY_PORT		user_enter
#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd;
    struct sockaddr_in server;
    int result;

    int user_enter;
    printf("Enter port number: ");
    scanf("%d",&user_enter);


    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd==INVALID_SOCKET)
	{
		printf("Error code; %d\n", WSAGetLastError());
        return 1;
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	server.sin_family = AF_INET;
	server.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	server.sin_addr.s_addr = inet_addr("127.0.0.1");  

	/*---assign a port number to the socket---*/
    if (connect(sockfd, (struct sockaddr*)&server, sizeof(server)) != 0 )
	{
		printf("\nConnection failed");
		exit(errno);
	}

        puts("Connected");
       int i; 
        char input_by_user[MAXBUF];
        int t=1;
        int len;
	/*---forever... ---*/
	while (t==1)
	{	//input by user
        printf("Enter: ");
        scanf(" %[^\n]s", input_by_user);
        printf("\n");
        len = strcmp(input_by_user, "exit client");//if user enter exit client
        if (len == 0 ){
            printf("\nTerminated");
            t=0;
            close(sockfd);
        }

        if(strlen(input_by_user) > 0) {
            int out = send(sockfd, input_by_user, strlen(input_by_user) + 1, 0);//send to server
                if(out != SOCKET_ERROR) {
                    int receivedBytes = recv(sockfd, input_by_user, MAXBUF, 0);
                    if(receivedBytes > 0) {
                        printf("Server: %s\n", input_by_user);//print out to be displayed
                    }
                }
        }

       // memset(input_by_user, 0, sizeof(input_by_user));
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
    WSACleanup();
  return 0;
}