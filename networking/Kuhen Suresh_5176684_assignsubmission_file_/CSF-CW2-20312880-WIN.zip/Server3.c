#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<ctype.h>
#include<time.h>


#define MY_PORT		user_enter
#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];
    int n=1;
    int result;

    int user_enter;
    printf("Enter port number: Start Server ");
    scanf("%d",&user_enter);


    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");
        int counter=1;
        int i;
        SOCKET newCon;
        SOCKADDR_IN addr;
        

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);
        //newCon=accept(sockfd,(struct sockaddr*)&client_addr,&addrlen);
            /*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
        char *ptr=inet_ntoa(client_addr.sin_addr);
        printf("IP:%s",ptr);
        printf("\nport number: %d",user_enter);
        //time
        int t=1;
        int uppercase = 1;
        time_t k;
		k = time(NULL);
		struct tm tm = *localtime(&k);
        //puts(client_addr);
        //char *ip = inet_ntoa(addr.sin_addr);
        //printf("IP is: %s", ip);
        int j;
          while (t==1) {
             uppercase = recv(clientfd, buffer, MAXBUF, 0);

             if (strcmp(buffer, "date") == 0) {
				printf("\nCurrent Date and time: %d-%d-%d\t%d", tm.tm_mday, tm.tm_mon + 1, tm.tm_year - 100, tm.tm_hour);
                }

             if (strcmp(buffer, "exit server")==0) {
                    printf("\nTerminated");
                    t=0;
                    break;
                }
            else{
                    for (i = 0; i <= uppercase - 1; i++) {
                        buffer[i] = toupper(buffer[i]);
                        //counter++;
                        }
                       // printf("\nlength of message is:%d",i);
                }
                 
                  for(j=0; buffer[j]!='\0' && buffer[j]!='\n'; j++){}

                send(clientfd, buffer, uppercase, 0);//sends capitalized buffer out to be displayed
                printf("\nlength of message is:%d",j);
                memset(buffer, 0, sizeof(buffer));//clears buffer each time it has been sent to be displayed
               
            }
          // puts(buffer);  
          // printf("\n%d",i);
                        
		//while(strcmp(buffer, "exit server")!= 0){                
		//send(clientfd, buffer, recv(clientfd, buffer, MAXBUF, 0), 0);
            //result=strcmp(buffer,"exit client");
                //if(result==0){
                  //  n=0;
                   // printf("terminated");
                    //close(clientfd);
                    //return 0;
          //      }

		/*---close connection---*/
        close(clientfd);
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
  
}