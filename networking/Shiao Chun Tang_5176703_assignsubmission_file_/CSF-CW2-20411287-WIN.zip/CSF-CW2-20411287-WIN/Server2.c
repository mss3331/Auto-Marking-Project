//////////////////////////  Server.c ////////////////

#include <io.h>
#include <stdio.h>
#include <winsock2.h>
#include <string.h>
#define MAXBUF 256

int main(int argc, char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd, clientfd;
    struct sockaddr_in self;
    char buffer[MAXBUF];
    u_short MY_PORT;

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
    {
        printf("Failed. Error Code : %d", WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

    /*---create streaming socket---*/
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror("Socket");
        exit(errno);
    }

    printf("Socket created.\n");

    // The port number entered by the user in the command line will be in string format.
    // Thus, we need to convert it to an unsigned short type. (2 bytes)
    // We can use sscanf to carry out the conversion (note: sscanf is in stdio.h)
    // argv[0] is always the name of the program (ie. Server2), argv[1] is "start" , argv[2] is "server" and lastly, argv[3] is <local port number> eg. 8989
    sscanf(argv[3], "%u", &MY_PORT);

    /*---initialize address/port structure---*/
    self.sin_family = AF_INET;
    // The htons function returns the value in TCP/IP NETWORK byte order ( big-endian )
    self.sin_port = htons(MY_PORT); // Host to Network Short (16-bit)
    self.sin_addr.s_addr = INADDR_ANY;

    /*---assign a port number to the socket---*/
    if (bind(sockfd, (struct sockaddr *)&self, sizeof(self)) != 0)
    {
        perror("socket--bind");
        exit(errno);
    }

    puts("Bind done");

    // Places the socket in a listening state.The socket will begin to listen on the specified local port number for oncoming connection request from the client side.
    if (listen(sockfd, 20) != 0)
    {
        perror("socket--listen");
        exit(errno);
    }

    puts("Waiting for incoming connections...");

    // TASK 2
    // We move the lines of code below out of the while loop so that we can continue to communicate via the same socket returned by accept().
    // Otherwise, a new socket descriptor will be generated for each loop iteration and
    // this will overwrite the previous socket and the server won't be able to accept multiple request from the same client.
    struct sockaddr_in client_addr;
    int addrlen = sizeof(client_addr);
    clientfd = accept(sockfd, (struct sockaddr *)&client_addr, &addrlen);

    // Displaying the socket descriptor
    printf("Socket descriptor:%d\n\n", clientfd);

    // The inet_ntoa function converts an (Ipv4) Internet network address into an ASCII string in Internet standard dotted-decimal format.
    char *ip = inet_ntoa(client_addr.sin_addr);
    // The ntohs function returns the value in HOST byte order.
    u_short client_port = ntohs(client_addr.sin_port);

    // TASK 2
    // Upon establishing a connection with the client, the server will display the following client's details
    printf("Client IP Address : %s\n", ip);
    printf("\nPort number targeted by the client request: %u\n\n", client_port);

    while (1)
    {
        // Receiving request from client
        // If no error occurs, recv returns the number of bytes received and the buffer pointed to by the buf parameter will contain this data received.
        int recv_size = recv(clientfd, buffer, MAXBUF, 0);

        // If the connection has been gracefully closed, the return value of recv() is 0.
        // On the other hand, recv() returns -1 which is [Error: WSAENOTSOCK] whenever the client closes abruptly ie. <CLOSES THE CLIENT.EXE WINDOW not via a proper command>
        // We do not want the server to shutdown if the client decides to close the connection via the command "exit client".
        // Therefore, the if() statement below allows the server to accept new requests from a new client connection.

        if (strcmp(buffer, "exit client") == 0 || recv_size == -1 || recv_size == 0)
        {
            closesocket(clientfd);
            if (recv_size == -1)
                printf("\nClient has terminated the connection abruptly : %d (WSAENOTSOCK).\n", WSAGetLastError());
            else
                printf("\nClient has terminated the connection gracefully.\n");

            puts("Waiting for the next incoming connections...\n");

            // accept() accepts a new connection request from the client and returns a new socket
            struct sockaddr_in client_addr;
            addrlen = sizeof(client_addr);
            clientfd = accept(sockfd, (struct sockaddr *)&client_addr, &addrlen);
            printf("Socket descriptor:%d\n", clientfd);

            ip = inet_ntoa(client_addr.sin_addr);
            client_port = ntohs(client_addr.sin_port);

            printf("\nClient IP Address : %s", ip);
            printf("\nPort number targeted by the client request: %u\n\n", client_port);
        }
        else
        {
            // In C, strings are array of characters terminated by a null character '\0'
            if (recv_size < MAXBUF)
                buffer[recv_size] = '\0';

            // TASK 2
            // Closes the connection and terminate if the client input message is “exit server”
            if (strcmp(buffer, "exit server") == 0)
            {
                puts("Exit server");
                closesocket(sockfd);
                WSACleanup(); // The WSACleanup function terminates use of the Winsock 2 DLL (Ws2_32.dll).
                exit(EXIT_SUCCESS);
            }

            // Converting client message to uppercase
            strupr(buffer);

            // PuTTY returns extra Carriage Return (CR) and Line Feed (LF) upon hitting <Enter> after typing out a message on it's terminal
            // This can be verified by printing out the ASCII value of the message sent by the client.The value 13 and 10 follows after the client's message.
            // From ASCII table, CR and LF are 13 and 10 respectively
            // This causes the statements below to be printed twice for each message sent from the client
            // The if() function below helps us the counter this issue
            // I've tried manipulating some of PuTTY's settings (with Internet guidance) but it doesn't help much

            /***Printing client message in uppercase on server side***/
            if (buffer[0] != '\r' && buffer[1] != '\n')
            {
                printf("\nMessage from client: %s\n", buffer);
                // TASK 2
                // Displaying the length of client message on server side
                printf("Length of client message : %d\n\n", recv_size);
            }

            // Echoes clients request back to client in UPPERCASE
            send(clientfd, buffer, recv_size, 0);
        }
    }

    /*---clean up (should never get here!)---*/
    close(sockfd);
    WSACleanup();
    return 0;
}