//////////////////////////  Server.c ////////////////

#include <io.h>
#include <stdio.h>
#include <winsock2.h>
#include <string.h>
#include <time.h>
#define MAXBUF 256

int main(int argc, char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd, clientfd;
    struct sockaddr_in self;
    char buffer[MAXBUF];
    u_short MY_PORT;

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
    {
        printf("Failed. Error Code : %d", WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

    /*---create streaming socket---*/
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror("Socket");
        exit(errno);
    }

    printf("Socket created.\n");

    // The port number entered by the user in the command line will be in string format.
    // Thus, we need to convert it to an unsigned short type. (2 bytes)
    // We can use sscanf to carry out the conversion (note: sscanf is in stdio.h)
    // argv[0] is always the name of the program (ie. Server4), argv[1] is "start" , argv[2] is "server" and lastly, argv[3] is <local port number> eg. 8989
    sscanf(argv[3], "%u", &MY_PORT);

    /*---initialize address/port structure---*/
    self.sin_family = AF_INET;
    self.sin_port = htons(MY_PORT); // Host to Network Short (16-bit)
    // bind() of INADDR_ANY does NOT "generate a random IP". It binds the socket to all available interfaces.
    self.sin_addr.s_addr = INADDR_ANY;

    /*---assign a port number to the socket---*/
    if (bind(sockfd, (struct sockaddr *)&self, sizeof(self)) != 0)
    {
        perror("socket--bind");
        exit(errno);
    }

    puts("Bind done");

    // Places the socket in a listening state.The socket will begin to listen on the specified local port number for oncoming connection request from the client side.
    if (listen(sockfd, 20) != 0)
    {
        perror("socket--listen");
        closesocket(sockfd);
        WSACleanup();
        exit(EXIT_FAILURE);
    }

    puts("Waiting for incoming connections...");

    struct sockaddr_in client_addr;
    int addrlen = sizeof(client_addr);
    clientfd = accept(sockfd, (struct sockaddr *)&client_addr, &addrlen);

    // Displaying the socket descriptor
    printf("Socket descriptor:%d\n\n", clientfd);

    // The inet_ntoa function converts an (Ipv4) Internet network address into an ASCII string in Internet standard dotted-decimal format.
    char *ip = inet_ntoa(client_addr.sin_addr);
    // The ntohs function returns the value in HOST byte order.
    u_short client_port = ntohs(client_addr.sin_port);

    // Upon establishing a connection with the client, the server will display the following client's details
    printf("\nClient IP Address : %s", ip);
    printf("\nPort number targeted by the client request: %u\n\n", client_port);

    while (1)
    {

        // Receiving request from client
        // If no error occurs, recv returns the number of bytes received and the buffer pointed to by the buf parameter will contain this data received.
        int recv_size = recv(clientfd, buffer, MAXBUF, 0);

        if (strcmp(buffer, "exit client") == 0 || recv_size == -1 || recv_size == 0)
        {
            closesocket(clientfd);
            if (recv_size == -1)
                printf("\nClient has terminated the connection abruptly : %d (WSAENOTSOCK).\n", WSAGetLastError());
            else
                printf("\nClient has terminated the connection gracefully.\n");

            puts("Waiting for the next incoming connections...\n");

            // accept() accpets a new connection request from the client and returns a new socket
            struct sockaddr_in client_addr;
            addrlen = sizeof(client_addr);
            clientfd = accept(sockfd, (struct sockaddr *)&client_addr, &addrlen);
            printf("Socket descriptor:%d\n", clientfd);

            ip = inet_ntoa(client_addr.sin_addr);
            client_port = ntohs(client_addr.sin_port);

            printf("\nClient IP Address : %s", ip);
            printf("\nPort number targeted by the client request: %u\n\n", client_port);
        }
        else
        {
            // In C, strings are array of characters terminated by a null character '\0'
            if (recv_size < MAXBUF)
                buffer[recv_size] = '\0';

            // Closes the connection and terminate if the client input message is “exit server”
            if (strcmp(buffer, "exit server") == 0)
            {
                puts("Exit server");
                closesocket(sockfd);
                WSACleanup(); // The WSACleanup function terminates use of the Winsock 2 DLL (Ws2_32.dll).
                exit(EXIT_SUCCESS);
            }

            // Implementing time functions
            time_t rawtime;
            struct tm *info;
            char time_buffer[80];

            time(&rawtime);
            info = localtime(&rawtime);

            // TASK 5
            // Allows to client to request for date and time in different formats
            if (strcmp(buffer, "date") == 0)
            {
                strftime(time_buffer, 80, "Current Date and Time: %d-%m-%y %H\0\r\n", info);
                int len = strlen(time_buffer);
                printf("Client requested for date in the format of dd-mm-yy hh\n\n");
                send(clientfd, time_buffer, len, 0);
            }
            else if (strcmp(buffer, "date1") == 0)
            {
                strftime(time_buffer, 80, "Current Year: %Y\0\r\n", info);
                int len = strlen(time_buffer);
                printf("Client requested for the year in the format of yyyy\n\n");
                send(clientfd, time_buffer, len, 0);
            }
            else if (strcmp(buffer, "date2") == 0)
            {
                strftime(time_buffer, 80, "Current Hour: %H\0\r\n", info);
                int len = strlen(time_buffer);
                printf("Client requested for hour in the format of hh\n\n");
                send(clientfd, time_buffer, len, 0);
            }
            else if (strcmp(buffer, "date3") == 0)
            {
                strftime(time_buffer, 80, "Current Date: %d-%b-%y\0\r\n", info);
                int len = strlen(time_buffer);
                printf("Client requested for date in the format of dd-Mon-yy\n\n");
                send(clientfd, time_buffer, len, 0);
            }

            else
            {
                // Converting client buffer to uppercase
                strupr(buffer);

                /***Printing client message in uppercase on server side***/
                if (buffer[0] != '\r' && buffer[1] != '\n')
                {
                    printf("Message from client: %s\n", buffer);
                    printf("Length of client message : %d\n\n", recv_size);
                }

                // Echoes clients request back to client in UPPERCASE
                send(clientfd, buffer, recv_size, 0);
            }
        }
    }

    /*---clean up (should never get here!)---*/
    closesocket(sockfd);
    WSACleanup();
    return 0;
}
