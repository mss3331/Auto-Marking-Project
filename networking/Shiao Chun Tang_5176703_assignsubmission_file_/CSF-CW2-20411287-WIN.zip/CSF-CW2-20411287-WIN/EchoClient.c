//////////////////////////  Server.c ////////////////

#include <io.h>
#include <stdio.h>
#include <winsock2.h>
#include <string.h>
#define MAXBUF 256

int main(int argc, char *argv[])
{
    WSADATA wsa;
    SOCKET sock_fd;
    struct sockaddr_in self;
    char in_buffer[MAXBUF];  // Stores message received from the server
    char out_buffer[MAXBUF]; // Stores message that is to be sent back to the server

    // Ipv4 are 32-bit integers in dotted decimal format x.x.x.x where each x can be any value between 0 and 255
    // eg. 127.000.000.100
    // Therefore, we declare an array with the array size of 16 to store an Ipv4 address  (16 instead of 15 because of the null terminator '\0')
    char ip_address[16];

    // A pointer to array ip_address
    const char(*IP_ADDRESS) = ip_address;
    int nRet; // to store return values of winsock functions eg. accept() , connect() and etc.

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
    {
        printf("Failed. Error Code : %d", WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

    /*---create streaming socket---*/
    if ((sock_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror("Socket");
        exit(errno);
    }

    printf("Socket created.\n");

    // Prompts the client to enter local port number as well as the IP address of the destination that it wishes to connect to.
    u_short MY_PORT;
    puts("\nSpecify the destination you want to connect to");
    puts("Enter a local port number:");
    scanf("%u", &MY_PORT);
    puts("\nEnter Host Name (or IP address):");
    scanf("%s", ip_address);

    // Localhost is equivalent to the ip address 127.0.0.1
    // If client inputs "localhost" , we assign the ip address 127.0.0.1
    if (strcmp(ip_address, "localhost") == 0)
    {
        strcpy(ip_address, "127.0.0.1");
    }

    /*---initialize address/port structure---*/
    self.sin_family = AF_INET;
    self.sin_port = htons(MY_PORT); // Host to Network Short (16-bit)
    // The inet_ntoa function converts an (Ipv4) Internet network address into an ASCII string in Internet standard dotted-decimal format.
    self.sin_addr.s_addr = inet_addr(IP_ADDRESS);

    /**The connect function establishes a connection to the specified socket.**/
    // If no error occurs, connect() returns 0. Otherwise, it returns SOCKET_ERROR.
    // In the event an unsuccessful connection occurs,the loop below provides as many attempts as possible to establish a connection for the client.
    do
    {
        nRet = connect(sock_fd, (struct sockaddr *)&self, sizeof(self));
        while (nRet < 0)
        {
            printf("\nFailed to connect socket to the client. Error code: %d\n", WSAGetLastError());
            puts("The server is not listening on the port number you've entered.\nPlease enter another port number:");
            scanf("%u", &MY_PORT);
            puts("\nEnter Host Name (or IP address):");
            scanf("%s", ip_address);
            if (strcmp(ip_address, "localhost") == 0)
            {
                strcpy(ip_address, "127.0.0.1");
            }
            self.sin_family = AF_INET;
            self.sin_port = htons(MY_PORT);
            self.sin_addr.s_addr = inet_addr(IP_ADDRESS);
            nRet = connect(sock_fd, (struct sockaddr *)&self, sizeof(self));
        }
    } while (nRet < 0);

    // Prints the statement below upon successful connection.
    printf("\nSocket successfully connected to the client:\n");

    /**Client is now ready to communicate with the server**/
    printf("Client is now ready to send requests to the server.\n\n");
    while (1)
    {
        /**Client inputs the message.**/
        fgets(out_buffer, (MAXBUF), stdin); /**fgets includes the new line character in the array.
                                               fgets() is a safer version of gets() where you can provide limitation on input size ie. MAXBUF as predefined.**/

        if (out_buffer[0] != '\n' && out_buffer[1] != '\0')
        {
            /**out_buffer[strlen(out_buffer) - 1] = '\0' is to remove the new line (\n) that fgets
               ends the output buffer with and replaces it with a null to terminate the string message.**/
            if ('\n' == out_buffer[strlen(out_buffer) - 1])
            {
                out_buffer[strlen(out_buffer) - 1] = '\0';
            }

            int len = strlen(out_buffer);

            // If the client message is "exit client", then we terminate the client
            if (strcmp(out_buffer, "exit client") == 0)
            {
                closesocket(sock_fd);
                exit(EXIT_SUCCESS);
            }

            // Sending message to the server
            nRet = send(sock_fd, out_buffer, len, 0);

            // Error handling for send()
            if (nRet < 0)
            {
                printf("Failed to send message to server.\n");
                WSACleanup();
                exit(EXIT_FAILURE);
            }
            else
                puts("----Message successfully sent----");

            /*****Receiving message from server*****/
            // in_buffer may store the previous message that the client has received
            // When client sends the next message, server may receive chunks of the previous message together with the current message
            // This causes client to receive the unintended message from the server
            // Hence, before receiving messages from the server, we initialize in_buffer with '0' (null) or in other words, we fill the block of memory of in_buffer with null.
            // This essentially 'clears' the memory of in_buffer before it is ready to store incoming messages from the server.
            // Note: memset is in string.h
            memset(in_buffer, 0, MAXBUF);
            int recv_size = recv(sock_fd, in_buffer, MAXBUF, 0);

            // Error handling for recv()
            // If no error occurs, recv returns the number of bytes received and the buffer pointed to by the buf parameter will contain this data received.
            if (recv_size < 0)
            {
                printf("Failed to receive message from server. Error code: %d\n", WSAGetLastError());
                WSACleanup();
                exit(EXIT_FAILURE);
            }
            else
            {
                puts("Message from server:");
                printf("%s\n\n", in_buffer);
            }
        }
    }

    closesocket(sock_fd);
    WSACleanup();
    return 0;
}
