//////////////////////////  Server.c ////////////////

#include <io.h>
#include <stdio.h>
#include <winsock2.h>
#include <string.h>
#define MAXBUF 256

int main(int argc, char *argv[])
{
	WSADATA wsa;
	SOCKET sockfd, clientfd;
	struct sockaddr_in self;
	char buffer[MAXBUF];
	// Local port number identifier
	u_short MY_PORT;

	printf("\nInitialising Winsock...");
	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
	{
		printf("Failed. Error Code : %d", WSAGetLastError());
		return 1;
	}

	printf("Initialised.\n");

	/*---create streaming socket---*/
	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		perror("Socket");
		exit(errno);
	}

	printf("Socket created.\n");

	// TASK 1
	// The port number entered by the user in the command line will be in string format.
	// Thus, we need to convert it to an unsigned short type. (2 bytes)
	// We can use sscanf to carry out the conversion (note: sscanf is in stdio.h)
	// argv[0] is always the name of the program (ie. Server1), argv[1] is "start" , argv[2] is "server" and lastly, argv[3] is <local port number> eg. 8989
	sscanf(argv[3], "%u", &MY_PORT);

	/*---initialize address/port structure---*/
	self.sin_family = AF_INET;
	// The htons function returns the value in TCP/IP network byte order ( big-endian )
	self.sin_port = htons(MY_PORT); // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;

	/*---assign a port number to the socket---*/
	if (bind(sockfd, (struct sockaddr *)&self, sizeof(self)) != 0)
	{
		perror("socket--bind");
		exit(errno);
	}

	puts("Bind done");

	// Places the socket in a listening state.The socket will begin to listen on the specified local port number for oncoming connection request from the client side.
	if (listen(sockfd, 20) != 0)
	{
		perror("socket--listen");
		exit(errno);
	}

	puts("Waiting for incoming connections...");

	// Receives client's request ONCE and then closes the socket
	while (1)
	{
		struct sockaddr_in client_addr;
		int addrlen = sizeof(client_addr);

		// accept() accepts a connection request from a client and returns a new socket descriptor.
		// The connection is actually made with the socket that is returned by accept().
		// It is the socket that the server will use from now on to communicate with this client.
		clientfd = accept(sockfd, (struct sockaddr *)&client_addr, &addrlen);

		// Receiving request from client
		// If no error occurs, recv returns the number of bytes received and the buffer pointed to by the buf parameter will contain this data received.
		int recv_size = recv(clientfd, buffer, MAXBUF, 0);

		// Closes the connection and terminate if the client input message is “exit server”
		if (strcmp(buffer, "exit server") == 0)
		{
			puts("Exit server");
			closesocket(sockfd);
			WSACleanup(); // The WSACleanup function terminates use of the Winsock 2 DLL (Ws2_32.dll).
			exit(EXIT_SUCCESS);
		}

		// If there's a failure in receiving the request from client.
		if (recv_size < 0)
		{
			printf("Failed to receive request from client. Error code: %d\n", WSAGetLastError());
			closesocket(sockfd);
			WSACleanup();
			exit(EXIT_FAILURE);
		}

		// TASK 1
		// Converting client message to uppercase using strupr()
		strupr(buffer);

		if (buffer[0] != '\r' && buffer[1] != '\n')
		{
			// Displays the client message in uppercase as per instructed.
			printf("Message from client: %s\n", buffer);
		}

		// Echoes clients request back to client in uppercase.
		send(clientfd, buffer, recv_size, 0);

		/*---close connection---*/
		close(clientfd);
		break;
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
	WSACleanup();
	return 0;
}
