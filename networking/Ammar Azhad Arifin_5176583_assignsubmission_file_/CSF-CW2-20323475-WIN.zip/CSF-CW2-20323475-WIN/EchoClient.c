#include<io.h>
#include<stdio.h>
#include<winsock2.h>

#define MY_PORT 	8989
#define MAXBUF 		256

int main(int argc , char *argv[])
{
	 
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    struct sockaddr_in server;
	char message[MAXBUF], server_reply[MAXBUF];
	

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed initialising winsock. Error Code : %d",WSAGetLastError());
        exit(errno);
    }
     
    printf("Initialised.\n");

	
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		printf("Failed creating socket. Error Code : %d",WSAGetLastError());
		exit(errno);
	}
	
    printf("Socket created.\n");

	server.sin_family = AF_INET;
	server.sin_port = htons(MY_PORT);
	server.sin_addr.s_addr = inet_addr("127.0.0.1");

    if (connect(sockfd, (struct sockaddr*)&server, sizeof(server)) < 0 )
	{
		printf("Failed connecting. Error Code : %d",WSAGetLastError());
		exit(errno);
	}

    puts("Connected to server.");

	while (1)
	{	
		printf("\nEnter message: ");
		gets(message);

		if (strcmp(message, "exit client") == 0){
			break;
		}
		
		if((send(sockfd, message, strlen(message), 0)) < 0){
			printf("Failed sending. Error Code : %d",WSAGetLastError());
			exit(errno);
		}

		int n = recv(sockfd, server_reply, MAXBUF-1, 0);
		server_reply[n] = '\0';
		printf("Received message: %s\n", server_reply);
		
	}

	
	close(sockfd);
    WSACleanup();
	return 0;
}