//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<ctype.h>
#include<time.h>

#define MY_PORT		p
#define MAXBUF		256
int p;
int toupper(int buffer);

int main(int argc , char *argv[])
{

    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];

	printf("Enter Port Number:");
	scanf("%d",&p);									//Scan p to set as port number
    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while(1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);
		int n=1;
		int count = 0;
		time_t t;
		t = time(NULL);
		struct tm tm= *localtime(&t);


		/*---accept a connection (creating a data pipe)---*/

		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		char *ptr=inet_ntoa(client_addr.sin_addr);
		printf("%s\n",ptr);								//display IP
		printf("%d\n",p);								//display Port number
		while(n==1){
		int recv_size= recv(clientfd, buffer, MAXBUF, 0);
		if(strcmp(buffer,"date")==0)					//Cmp if is = date
		{
			printf("date:%d-%d-%d %d\r\n",tm.tm_mday, tm.tm_mon+1, tm.tm_year-100, tm.tm_hour);
		}												//Print current date
		else if(strcmp(buffer,"exit server")==0)		//cmp if elements in buffer is
		{												//= exit server if yes end loop and exit.
			n=0;
		}
		else											//Loop for counting length
		count = 0;
		for(int i=0;i<strlen(buffer);i++){
		if(buffer[i]!=' ')
		count++;
		}
		printf("length of char:%d\n",count);			
		for(int j=0;j<strlen(buffer);j++){				//Loop for uppercasing
			buffer[j] = toupper(buffer[j]);
		}
		send(clientfd, buffer, recv_size ,0);
		}
		

		/*---close connection---*/
		close(clientfd);
		exit(1);
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}

