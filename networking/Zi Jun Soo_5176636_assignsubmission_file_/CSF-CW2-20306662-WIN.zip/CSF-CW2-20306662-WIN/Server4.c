//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<ctype.h>
#include<time.h>

#define MY_PORT		p
#define MAXBUF		256
int p;
int toupper(int buffer);

int main(int argc , char *argv[])
{

    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];

	printf("Enter Port Number:");
	scanf("%d",&p);										//Scan p to set as port number
    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while(1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);
		int n=1;
		int count = 0;
		time_t t;
		t = time(NULL);
		struct tm tm= *localtime(&t);


		/*---accept a connection (creating a data pipe)---*/

		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		char *ptr=inet_ntoa(client_addr.sin_addr);
		printf("%s\n",ptr);								//display IP
		printf("%d\n",p);								//display Port number
		while(n==1){
		int recv_size= recv(clientfd, buffer, MAXBUF, 0);
		if(strcmp(buffer,"date")==0)					//Cmp if is = date
		{
			printf("date:%d-%d-%d %d\r\n",tm.tm_mday, tm.tm_mon+1, tm.tm_year-100, tm.tm_hour);
		}												//Print current date
		else if(strcmp(buffer,"date1")==0)
		{				
			printf("year:%d\r\n",tm.tm_year+1900);		//Print Year
		}
		else if(strcmp(buffer,"date2")==0)
		{
			printf("hour:%d\r\n",tm.tm_hour);			//Print Hour
		}
		else if(strcmp(buffer,"date3")==0)				//Print Date but month in char
		{
			int g=tm.tm_mon;
			switch(g){							//switch case to convert month to char
				case 0:
					printf("Date:%d-Jan-%d\r\n",tm.tm_mday, tm.tm_year-100);
				break;
				case 1:
					printf("Date:%d-Feb-%d\r\n",tm.tm_mday, tm.tm_year-100);
				break;
				case 2:
					printf("Date:%d-Mar-%d\r\n",tm.tm_mday, tm.tm_year-100);
				break;
				case 3:
					printf("Date:%d-Apr-%d\r\n",tm.tm_mday, tm.tm_year-100);
				break;
				case 4:
					printf("Date:%d-May-%d\r\n",tm.tm_mday, tm.tm_year-100);
				break;
				case 5:
					printf("Date:%d-Jun-%d\r\n",tm.tm_mday, tm.tm_year-100);
				break;
				case 6:
					printf("Date:%d-Jul-%d\r\n",tm.tm_mday, tm.tm_year-100);
				break;
				case 7:
					printf("Date:%d-Aug-%d\r\n",tm.tm_mday, tm.tm_year-100);
				break;
				case 8:
					printf("Date:%d-Sep-%d\r\n",tm.tm_mday, tm.tm_year-100);
				break;
				case 9:
					printf("Date:%d-Oct-%d\r\n",tm.tm_mday, tm.tm_year-100);
				break;
				case 10:
					printf("Date:%d-Nov-%d\r\n",tm.tm_mday, tm.tm_year-100);
				break;
				case 11:
					printf("Date:%d-Dec-%d\r\n",tm.tm_mday, tm.tm_year-100);
				break;

			}
		}
		else if(strcmp(buffer,"exit server")==0)		//cmp if elements in buffer is
		{
			n=0;										//= exit server if yes end loop and exit.
		}
		else
		count = 0;
		for(int i=0;i<strlen(buffer);i++){				//Loop for counting length
		if(buffer[i]!=' ')
		count++;
		}
		printf("length of char:%d\n",count);
		for(int j=0;j<strlen(buffer);j++){				//Loop for uppercasing
			buffer[j] = toupper(buffer[j]);
		}
		send(clientfd, buffer, recv_size ,0);
		}
		

		/*---close connection---*/
		close(clientfd);
		exit(1);
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}

