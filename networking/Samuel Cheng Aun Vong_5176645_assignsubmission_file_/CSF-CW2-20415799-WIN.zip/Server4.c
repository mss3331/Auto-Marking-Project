//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<time.h>

#define MAXBUF		256


int main(int argc , char *argv[])
{
    /* date */
    time_t currentTime;
    time(&currentTime);

    struct tm *theTime = localtime(&currentTime);


    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");



	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");



	/*---initialize address/port structure---*/
    self.sin_family = AF_INET;
	self.sin_port = htons(atoi(argv[1]));	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}

        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{
	    struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);
		char cleanUp[MAXBUF];

        /*---accept a connection (creating a data pipe)---*/
        clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);

        printf("IP Address: %hhu\n", client_addr.sin_addr.s_addr); //
        printf("Port Number: %u\n", client_addr.sin_port);

            /*---close connection---*/
        while(1){
            char exitServer[] = "exit server";
            int recv_size = 0;
            char cleanUp[MAXBUF];


            recv_size = recv(clientfd, buffer, MAXBUF, 0);

            if (strcmp(buffer, exitServer) == 0){
                printf("Server Exit...\n\n\n");
                break;
            }

            /* check if "date" */
            if (strcmp(buffer, "date") == 0){
                printf("%d-%i-%i %i\n\r", theTime->tm_mday, theTime->tm_mon+1, theTime->tm_year + 1900, theTime->tm_hour);
                char buffertime[] = "The date is displayed in the server window...\n\n";

                send(clientfd, buffertime, strlen(buffertime),0);
                strcpy(buffertime, cleanUp);
            }
            else if(strcmp(buffer, "date1") == 0){
                printf("%i\n\r", theTime->tm_year + 1900);
                char buffertime[] = "The year is displayed in the server window...\n\n";

                send(clientfd, buffertime, strlen(buffertime),0);
                strcpy(buffertime, cleanUp);
            }
            else if(strcmp(buffer, "date2") == 0){
                printf("%i\n\r",theTime->tm_hour);
                char buffertime[] = "The hour is displayed in the server window...\n\n";

                send(clientfd, buffertime, strlen(buffertime),0);
                strcpy(buffertime, cleanUp);
            }
            else if(strcmp(buffer, "date3") == 0){
                char month[2];
                switch(theTime->tm_mon+1){
                    case(1):
                        strcpy(month, "Jan");
                    case(2):
                        strcpy(month, "Feb");
                    case(3):
                       strcpy(month, "Mar");
                    case(4):
                        strcpy(month, "Apr");
                    case(5):
                        strcpy(month, "May");
                    case(6):
                        strcpy(month, "Jun");
                    case(7):
                        strcpy(month, "Jul");
                    case(8):
                        strcpy(month, "Aug");
                    case(9):
                        strcpy(month, "Sep");
                    case(10):
                        strcpy(month, "Oct");
                    case(11):
                        strcpy(month, "Nov");
                    case(12):
                        strcpy(month, "Dec");
                }
                printf("%i-%s-%i\n\r", theTime->tm_mday, month, theTime->tm_year + 1900, theTime->tm_hour);
                char buffertime[] = "The date is displayed in the server window...\n\n";

                send(clientfd, buffertime, strlen(buffertime),0);
                strcpy(buffertime, cleanUp);
            }
            else{
            printf("Length of message: %d\n\n",recv_size);

            send(clientfd, strupr(buffer), recv_size, 0);
            }

            strcpy(buffer, cleanUp);

        }

        close(clientfd);
	}
	/*---clean up (should never get here!)---*/
	close(sockfd);
    WSACleanup();
	return 0;
}

