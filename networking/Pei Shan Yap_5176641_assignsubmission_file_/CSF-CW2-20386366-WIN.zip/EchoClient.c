#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>

#define MAXMES		256

int main(int argc , char *argv[])
{
    //WSAStartup(Initialise Winsock)
    WSADATA wsa;
    SOCKET serverfd;
    struct sockaddr_in server;
	char message[MAXMES];
	char reply[MAXMES];
	int C_PORT=atoi(argv[1]);

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");
	
	//Create streaming socket
    if ( (serverfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");
		
	//Assigning adrress
	server.sin_family = AF_INET;
	server.sin_port = htons(C_PORT); //Big Endean
	server.sin_addr.s_addr = inet_addr("127.0.0.1"); //IP address in binary

	//Connect client to server
	if (connect(serverfd, (struct sockaddr*)&server, sizeof(server)) != 0) {
        printf("Failed to connect with server.\n");
        exit(0);
    }
    else
        printf("Connected to the server.\n");
	
	for(;;){
	memset(message,'\0',sizeof(message));//empty the message
	memset(reply,'\0',sizeof(reply));//empty the reply
	fgets(message,MAXMES,stdin);//read input from user
	send(serverfd, message, strlen(message), 0);//send message input by user to server
	//if user input exit client, break the loop and close the connection
	if(strncmp("exit client", message,11) == 0) {
        printf("Client exit.\n");
		break;}
	recv(serverfd, reply, MAXMES, 0);//read reply from server
	printf("Reply from server:%s\n",reply);//display response by server
	}
	
	//close and clean up
		close(serverfd);
        WSACleanup();
	return 0;
}