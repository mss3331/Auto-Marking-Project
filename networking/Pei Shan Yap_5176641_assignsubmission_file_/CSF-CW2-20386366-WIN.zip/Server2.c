//////////////////////////  Server2.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>

#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    struct sockaddr_in self;
	int MY_PORT=atoi(argv[1]);//make server accept any port number;
	char buffer[MAXBUF];

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);
   
		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		
		//display IP adddress and port number of client 
		getpeername(sockfd, (struct sockaddr*)&client_addr, &addrlen);//get info(IP and port number) of client and store in the structure 
        printf("Client IP address : %s\n", inet_ntoa(client_addr.sin_addr));//convert the IP address into dotted decimal format and print
        printf("Client Port Number: %d\n", ntohs(client_addr.sin_port));//translate port number into host byte order and print 
		
		//infinite loop to handle multiple request
		for(;;){
		memset(buffer,'\0',sizeof(buffer));//empty the buffer
		int message_len=0;//reset the length
		recv(clientfd, buffer, MAXBUF, 0);//read input from client into buffer
		//if client input exit server, break the loop and close the connection
		if(strncmp("exit server", buffer,11) == 0) {
        printf("Server exit.\n");
		break;}
		//if client input exit client, break the loop and wait for next client
		if(strncmp("exit client", buffer,11) == 0) {
        printf("Waiting for next client.\n");
		break;}
		//if the first input is an ENTER then will not count as input
		if(buffer[0]=='\n'||buffer[0]=='\r'){
		continue;}
		//modify client input into uppercase
		for (int i = 0;buffer[i]!='\0'; i++) {
        if(buffer[i] >= 'a' && buffer[i] <= 'z') {
         buffer[i] = buffer[i] -32;
        }
		}
		//print at server side
		printf("Uppercase of client input is: %s\n",buffer);
		 //display length of message at server side
		for(int i = 0;buffer[i]!='\0';i++){
		if(buffer[i]!='\n'&&buffer[i]!='\r')
		   message_len++;
		}
		printf("Length of message from client:%d\n",message_len);
		//send data in buffer(modified message) to client
		send(clientfd, buffer, strlen(buffer), 0);
		}
		/*---close connection---*/
		close(clientfd);
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}

