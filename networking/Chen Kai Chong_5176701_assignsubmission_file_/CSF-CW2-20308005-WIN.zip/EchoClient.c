//////////////////////////  Server.c ////////////////

//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include <ctype.h>

//#define MY_PORT		8989
#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , serverfd;
   	struct sockaddr_in server;
	int MY_PORT,length,i;	//declare variable
	MY_PORT=atoi(argv[1]);  //Accept port number inputted


    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)//initialised winsock
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}
	printf("Socket created.\n");

	/*---initialize server address/port structure---*/
	server.sin_family = AF_INET;
	server.sin_port = htons(MY_PORT);	 
	server.sin_addr.s_addr =inet_addr("127.0.0.1"); 
	 
	// S: Socket
	
	if(connect(sockfd,(struct sockaddr *)&server, sizeof(server))!=0){  //connect socket to server
		printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
	}
	printf("Socket connected\n");
	char message[256];
	char Reply[256];
	char line[4];	
	/*---forever... ---*/
	while (1)
	{	
		struct sockaddr_in server_addr;
		fgets(message,sizeof(message),stdin);   //accept input from user
		if(strncmp(message,"exit client",11)==0){ //check if the input is "exit client"
			memset(message,0,sizeof(message));	  //clear the buffer space for the next client
			memset(Reply,0,sizeof(Reply));			
			break;
		}
		if(send(sockfd,message,strlen(message),0)<0) //send the message to server
		{
			perror("message");
			exit(errno);
		}
		if(recv(sockfd,Reply,256,0)<0) 				//receive the reply from server
		{
 			perror("Reply");
			exit(errno);
		}

		printf("%s\n",Reply);					//Print the server reply on the server window
		memset(message,0,sizeof(message));	
		memset(Reply,0,sizeof(Reply));		//clear the buffer space for the next client

	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
 	WSACleanup();
	return 0;
}

