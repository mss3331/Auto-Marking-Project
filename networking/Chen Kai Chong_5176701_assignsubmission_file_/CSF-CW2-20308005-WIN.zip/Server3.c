//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include <ctype.h>
#include <string.h>
#include <time.h>

//#define MY_PORT		8989
#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
   	struct sockaddr_in self;
   	time_t t = time(NULL);// get the time
	struct tm time = *localtime(&t);      //assign tag to local time structure
	char buffer[MAXBUF];
	
	int MY_PORT,length,i,count=0;
	MY_PORT=atoi(argv[1]);  //Accept port number inputted

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");
	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);// accept client connection request
		printf("Client IP address: %s \n",inet_ntoa(client_addr.sin_addr)); //print the client's IP address
		printf("Client targeted port number: %lu \n",client_addr.sin_port);	//print client's port number
		while(1){															//continue indefinitely 
			length=recv(clientfd, buffer, MAXBUF, 0);  //receive message from client
			if(length<=0) break;                //break if the client disconnect
			if((strcmp(buffer,"\r\n")==0)||(strcmp(buffer,"\n")==0)) goto end;	//Goto End if the input is /r/n
			if(strncmp(buffer,"exit server",11)==0){   //check client message,if it is "exit server" break out of the loop
				memset(buffer, 0, sizeof(buffer)); 		 //Clear the buffer memory before exiting so the next client won't received an existing value
				break;
			}
			if(strncmp(buffer,"date",15)==0){
				sprintf(buffer,"%d-%d-%d %d\r\n",time.tm_mday,time.tm_mon+1,time.tm_year-100,time.tm_hour);//create the time in dd-mm-yy hh format 		
				send(clientfd, buffer, 20, 0);		//Send the date back to client
				goto end;
			}
			for(count=0;buffer[count]!='\0';count++); //Count the length of message receive
			printf("Length of message: %d \n",count); // print the length of message
			for(i=0;buffer[i]!='\0';i++){           //Convert client message to uppercase
				buffer[i]=toupper(buffer[i]);
			}
			for(i=0;buffer[i]!='\0';i++);         	//put carriage return and line feed at the end  
			buffer[i]='\r';
			buffer[i+1]='\n';
			buffer[i+2]='\0';		
			send(clientfd, buffer, length, 0);		//Send the converted message back to client
end:		memset(buffer, 0, sizeof(buffer));        //Clear the buffer memory
			
		}
		/*---close connection---*/
			close(clientfd);   //terminate connection with client
	}
	/*---clean up (should never get here!)---*/
	close(sockfd);
 	WSACleanup();
	return 0;
}

