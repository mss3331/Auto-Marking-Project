#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<ctype.h>

#define MAXBUF 256

int main(int argc , char *argv[])
{
	WSADATA wsa;
	SOCKET s;
	int PORT_NUM;
	
	printf("Enter Port Number:\n");
	scanf("%d", &PORT_NUM);
	
	if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
	
	if ( (s = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
    {
        perror("Socket");
        exit(errno);
    }
	
	struct sockaddr_in svr;
	svr.sin_family = AF_INET;
	svr.sin_port = htons(PORT_NUM);
	svr.sin_addr.s_addr = inet_addr("127.0.0.1");
	
	connect(s, (struct sockaddr *)&svr, sizeof(svr));

	while (1){
	char message[MAXBUF];
	char messageempty[MAXBUF];
	char Server_Reply[MAXBUF];
	char exit_server[]="exit server";
			puts("\nEnter message: ");
			gets(message);
				if(strcmp(message,exit_server)==0)
				{
					break;
				}
				if( send(s, message, strlen(message), 0 )< 0)
				{
					perror("Send failed");
					exit(errno);
				}
				if( recv(s, Server_Reply, MAXBUF, 0) < 0)
				{
					perror("receive failed");
					exit(errno);
				}
			printf("%s", Server_Reply[MAXBUF]);
			strcpy(message, messageempty);
			send(s, message, strlen(message) , 0);
			recv(s, Server_Reply, MAXBUF, 0);
	}
	close(s);
	WSACleanup();
}