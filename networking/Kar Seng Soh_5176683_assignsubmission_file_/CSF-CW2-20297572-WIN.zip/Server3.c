//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<conio.h>
#include<time.h>

#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];
	char bufferempty[MAXBUF];
	int MY_PORT;
	char exit_server[]="exit server";
	char date[]="date";
	int recv_size;

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");
		printf("Enter Port:\n");
		scanf("%d", &MY_PORT);
	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		printf("client connected");
		printf("Port Number is : %d\n",MY_PORT);
		while(1)
		{
		recv_size= recv(clientfd, buffer, MAXBUF, 0);
			if(strcmp(buffer,exit_server)==0){
				break;
			}
			if(strcmp(buffer,date)==0){
				time_t rawtime;
				struct tm *info;
				char bufferempty[MAXBUF];
				char buffertime[MAXBUF];
				time( &rawtime );
				info = localtime( &rawtime );
				strftime(buffertime,80,"%d-%m-%y %H\n", info);
				send(clientfd, buffertime, strlen(buffertime), 0);
				strcpy(buffertime, bufferempty);
				recv_size= recv(clientfd, buffertime, MAXBUF, 0);
				send(clientfd, buffertime, recv_size , 0);
				continue;
			}
			else{
			strupr(buffer);
			send(clientfd, buffer, recv_size , 0);
			printf("Length of the message sent is :'%d'\n", recv_size);
			strcpy(buffer, bufferempty);
			recv_size= recv(clientfd, buffer, MAXBUF, 0);
			send(clientfd, buffer, recv_size , 0);
			}
		}
		/*---close connection---*/
		close(clientfd);
		printf("Client Connection Lost\n");
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}

