//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include <time.h>

void delay(int);

#define MAXBUF	256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];
    int MY_PORT;
    int i;
    int nbytes;
    int j;
    int length;
    char temp[MAXBUF];
    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	printf("Enter a port to bind to\n");
	scanf("%d",&MY_PORT);
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}

        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		
		printf("The client's IP address is: %s\n", inet_ntoa(client_addr.sin_addr));//printing the client's ip address

		printf("The client's port numeber is: %d\n", (int) ntohs(client_addr.sin_port));//printing the client's port number
		

	/*Infinite loop to accept clients request repeatedly until terminated*/
	while(1){		

		nbytes = recv(clientfd, buffer, MAXBUF, 0);//size of the message received
		
		 for (i=0;i<nbytes;i++){
         		buffer[i] = buffer[i] ;
       		 }
		buffer[i] = '\0';//add a null terminator to remove any newline characters

		/*Closes the server if the client enters exit server")*/
		if(strcmp(buffer, "exit server") == 0){
			printf("Closing the server");
			delay(1);
			printf("  3   ");
			delay(1);
			printf("2   ");
			delay(1);
			printf("1   ");
			delay(1);	
			exit(1);
		}

		/*Informs the server that the client has disonnected*/
		if(strcmp(buffer, "exit client") == 0){
			printf("Client Has Disconnected\n");
			break;
		}

		 for (i=0;i<nbytes;i++){
          		 if(buffer[i] >= 'a' && buffer[i] <= 'z') {
         			buffer[i] = buffer[i] -32;//Turning lower case characters into uppercase 
      			}
       		 }
	
		buffer[i] = '\0'; //add a null terminator to remove any newline characters

		//Trying to fix a newline issue
		if(strlen(buffer)>2)
			printf("The length of the string is %d\n",strlen(buffer));
	

		send(clientfd,buffer, nbytes, 0);//sending the letters that is turned to uppercase back to the client	
	}
	/* Closing The Client Socket*/
	close(clientfd);
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}

/*Funtion for the delay*/
void delay(int number_of_seconds){
    // Converting time into milli_seconds
    int milli_seconds = 1000 * number_of_seconds;
  
    // Storing start time
    clock_t start_time = clock();
  
    // looping till required time is not achieved
    while (clock() < start_time + milli_seconds);
}

