#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include <time.h>

void delay(int);

#define MAXBUF	256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    int sock = 0 ;
    struct sockaddr_in serv_addr;
    char *ip = "127.0.0.1";
    char Buffer[MAXBUF] = {'\0'};
    char receive[MAXBUF] = {'\0'};
    int MY_PORT;

    printf("\nInitialising Winsock...\n");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0){

        printf("\n Socket creation error \n");
        return -1;

    }
	printf("Enter the server's port:");
	scanf("%d",&MY_PORT);
	printf("\0");
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(MY_PORT);
	serv_addr.sin_addr.s_addr = inet_addr(ip);
   	
	/*Exit if cannot connect to the server's port*/
    	if(connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr))<0){
		printf("\nConnection Failed \n");
		delay(3);
        	return -1;

	}
	printf("\nConnected To Server\n\n");
	while(1){	
		  fflush(stdin);//clearing the input buffer
		  printf("Please send a message:");
		  gets(Buffer);
	/*Check if the input is exit client*/
	switch(strcmp(Buffer, "exit client") == 0){
		case 0:{
			send(sock , Buffer , sizeof(Buffer) , 0 );
			if(strcmp(Buffer, "exit server") == 0){
				printf("Error, The server is inactive, Closing the socket");
				delay(1);
				printf("  3   ");
				delay(1);
				printf("2   ");
				delay(1);
				printf("1   ");		
				delay(1);		
				exit(1);
				break;
			}
			recv(sock, receive, MAXBUF, 0);
			printf("The server returns:%s\n\n",receive);
				break;
		}
		/*Closes the client if true*/
		case 1:{
			printf("Disconnecting...");
			delay(1);
			printf("5   ");
			delay(1);
			printf("4   ");
			delay(1);
			printf("3   ");
			delay(1);	
			printf("2   ");
			delay(1);
			printf("1   ");
			delay(1);
			send(sock , "exit client" ,24  , 0 );
			exit(1);
			break;
		}
			
	}
}
	close(sock);
        WSACleanup();
	return 0;	

}
void delay(int number_of_seconds){
    // Converting time into milli_seconds
    int milli_seconds = 1000 * number_of_seconds;
  
    // Storing start time
    clock_t start_time = clock();
  
    // looping till required time is not achieved
    while (clock() < start_time + milli_seconds);
}
