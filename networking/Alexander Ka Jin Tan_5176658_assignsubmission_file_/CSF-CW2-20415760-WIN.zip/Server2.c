//////////////////////////  Server2.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>

#define MY_PORT		8989
#define MAXBUF		256


//toUpper without ctype.h
void toUpperString (char* dst, char* src, int n);

int main(int argc , char *argv[])
{
    WSADATA wsa;
    //Initialize these to become INVALID at first.
    SOCKET sockfd = INVALID_SOCKET, clientfd = INVALID_SOCKET;
    	struct sockaddr_in self;
	char buffer[MAXBUF], upbuffer[MAXBUF];

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

    int inport = MY_PORT;
    //Input port number
    if (argc > 1)
        inport = strtol(argv[1],NULL,10);
    
	printf("Port number set as: %d\n", inport);

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(inport);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  


	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
    struct sockaddr_in client_addr;
    int addrlen=sizeof(client_addr);
    IN_ADDR* addr;
	/*---forever... ---*/
	while (1)
	{	
        // the following if statement checks if clientfd exists.
        // if they exist, then a seesion is currently ongoing.

        if (clientfd == INVALID_SOCKET){// if a session doesn't exists (socket is invalid)
            /*---accept a connection (creating a data pipe)---*/
            puts("Waiting for incoming connections...\n");
            clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
            addr = &client_addr.sin_addr; //get addr of client
            if (clientfd != INVALID_SOCKET){
                fprintf(stdout, "New connection from %d.%d.%d.%d port %d\n", addr->S_un.S_un_b.s_b1
                                                                        , addr->S_un.S_un_b.s_b2
                                                                        , addr->S_un.S_un_b.s_b3
                                                                        , addr->S_un.S_un_b.s_b4
                                                                        , client_addr.sin_port);
            } else { //if client disconnects during this for some reasons
                puts("Something wrong happened.");
            }
        }else{// if a session exists
            memset(buffer,0,MAXBUF);//clear buffer

            /*Receive a message*/
            int hasRecv = recv(clientfd, buffer, MAXBUF, 0);//receive a message
            
            fprintf(stdout, "Message received: %s of len %d\n", buffer, hasRecv);

            if (hasRecv > 0){//if success and if connected

                /*message handling*/
                if (strncmp(buffer, "exit server", 12) == 0 && clientfd != INVALID_SOCKET){//if received exit server
					/*server shutdown*/

                    /*graceful shutdown procedure:
                    1. tell server to not send anything to client
                    2. wait until client responds with nothing, which indicates a disconnect
                    3. then close the socket for client
                    4. set clientfd as invalid so that this variable can be resused later.
                    5. then close server and clean up.
                    */

                    if (clientfd != INVALID_SOCKET){
                        shutdown(clientfd,SD_SEND);// call shutdown on sending
                        while(recv(clientfd, buffer, MAXBUF, 0) > 0); //wait until disconnection
                        closesocket(clientfd); //Disconnect
                        clientfd = INVALID_SOCKET; //reset
                    }
					fprintf(stdout, "Server has shutdown\n");
					closesocket(sockfd); //Close server
					WSACleanup(); //clean up
					return 0;
                }
                else //else echo
                {
                    toUpperString(upbuffer, buffer, hasRecv);
                    send(clientfd, upbuffer, hasRecv, 0);
                }

            } else if (hasRecv <= 0){ //no bytes received (thus disconnect/shutdown) or error (SOCKET_ERROR = -1)
                /*shutdown*/
				shutdown(clientfd,SD_SEND);// call shutdown on sending
                closesocket(clientfd); //Disconnect
                clientfd = INVALID_SOCKET; //reset
                fprintf(stdout, "Client %d.%d.%d.%d:%d exited.\n", addr->S_un.S_un_b.s_b1
                                                                , addr->S_un.S_un_b.s_b2
                                                                , addr->S_un.S_un_b.s_b3
                                                                , addr->S_un.S_un_b.s_b4);
            }

        }
        
	}

	/*---clean up (should never get here!)---*/
	closesocket(sockfd);
        WSACleanup();
	return 0;
}

void toUpperString (char* dst, char* src, int n){
    for (int i = 0; i < n; i++){
        if (96 < src[i] && src[i] < 123) //'a' = 96, 'z' = 123
            dst[i] = src[i] - 32; //all alphabets turn uppercase when offset by 32
        else
            dst[i] = src[i];
    }
}
