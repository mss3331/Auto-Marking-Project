#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<winsock2.h>

#define MAX_BUFFER_SIZE (256)
#define DEFAULT_IPV4 ("127.0.0.1")
#define DEFAULT_PORT (8989)

//returns 1 if string has a character, else 0 if completely blank
int checkBlank(char*, int);

int main(int argc, char** argv){
    WSADATA wsadata;
    SOCKET sockfd = INVALID_SOCKET;
        struct sockaddr_in server;
    char *ip4; int port;

    //error handling for unsuccessful startup
    int wsares = WSAStartup(MAKEWORD(2,2), &wsadata);
    if (wsares != 0){
        fprintf(stderr, "Unsuccessful WSAStartup: %d\n", wsares);
        return -1;
    }

    /*get ip address*/
    if (argc > 1)
        ip4 = argv[1];
    else
        ip4 = DEFAULT_IPV4;

    if (argc > 2)
        port = strtol(argv[2],NULL,10);
    else
        port = DEFAULT_PORT;

    memset(&server, 0, sizeof(server)); //clear
    server.sin_family = AF_INET; //ipv4
    server.sin_port = htons(port); //port assignment
    server.sin_addr.S_un.S_addr = inet_addr(ip4);

    /*socket*/
    sockfd = socket(AF_INET,SOCK_STREAM,0);
    if (sockfd == INVALID_SOCKET){
        fprintf(stdout, "Error creating socket\n");
        WSACleanup();
    }

    /*connection*/
    int isConnect = connect(sockfd, (struct sockaddr*)&server, sizeof(server));
    if (isConnect == SOCKET_ERROR) {//failure to connect
        closesocket(sockfd);
        sockfd = INVALID_SOCKET; //reset
        fprintf(stderr, "Failure in connecting\n");
        WSACleanup();
        return -1;
    }
    
    fprintf(stdout, "Connection to server %s:%d successful!\n",ip4, port);
    puts("Write anythng down and the server will respond ;)\r\n");

    char *buffer = (char*) calloc(MAX_BUFFER_SIZE, sizeof(char));
    char *serverResponse = (char*) calloc(MAX_BUFFER_SIZE, sizeof(char));
    int msglen = 0, hassend = 0, hasrecv = 0;
    /*Successful! Send and receive*/
    while (1){ //So long as it is successful.
        fgets(buffer, MAX_BUFFER_SIZE, stdin); //read from standard input
        msglen = strlen(buffer);
        buffer[msglen - 1] = '\0'; //remove trailing \n

        if (checkBlank(buffer, msglen) != 0){ // if not blank
            if (strncmp(buffer, "exit client", msglen) == 0){ //if the line was exit client
                fprintf(stdout,"Client has exited\n");

                // exit
                closesocket(sockfd);
                WSACleanup();
                return 0;
            }

            // attempt send
            hassend = send(sockfd, buffer, msglen, 0);
            if (hassend == SOCKET_ERROR){ // abruptly exit if error
                fprintf(stdout, "Server error\n");

                //exit
                closesocket(sockfd);
                WSACleanup();
                return -1;
            }

            // attempt to hear from sevrer.
            memset(serverResponse, 0, MAX_BUFFER_SIZE);
            hasrecv = recv(sockfd, serverResponse, MAX_BUFFER_SIZE, 0);
            if (hasrecv > 0){
                fprintf(stdout,"Server repsonse: %s\n", serverResponse);
            }
            else {
                if (hasrecv == 0){
                    fprintf(stdout, "Server has disconnected\n");
                }else if (hasrecv == SOCKET_ERROR){
                    fprintf(stdout, "Server error\n");
                }

                //exit if disconnected or error.
                closesocket(sockfd);
                WSACleanup();
                return -1;
            }
        }
    }
    //fianlly, if nothing happened then just exit as usual.
    closesocket(sockfd);
    WSACleanup();
}

int checkBlank( char* str, int n){
    for (int i = 0; i < n; i++){
        switch (str[i]){
            case '\n':
            break;
            case '\r':
            break;
            case ' ':
            break;
            case '\t':
            break;
            default: //if there is a character
            return 1;
        }
    }
    return 0;
}