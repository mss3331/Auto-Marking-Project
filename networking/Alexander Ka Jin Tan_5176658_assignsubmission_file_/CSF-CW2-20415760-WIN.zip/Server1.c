//////////////////////////  Server1.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>

#define MY_PORT		8989
#define MAXBUF		256


//toUpper without ctype.h
void toUpperString (char* dst, char* src, int n);

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF], upbuffer[MAXBUF];

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

    int inport = MY_PORT;
    //Input port number
    if (argc > 1)
        inport = strtol(argv[1],NULL,10);
    
	printf("Port number set as: %d\n", inport);

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(inport);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  


	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

        /*---accept a connection (creating a data pipe)---*/
        clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
        
        //receive a message
		int hasRecv = recv(clientfd, buffer, MAXBUF, 0);

        //if success
        if (hasRecv != SOCKET_ERROR){
            if (strncmp(buffer,"exit server",12) == 0){
                //if exit server

                /*graceful shutdown procedure:
                1. tell server to not send anything to client
                2. wait until client responds with nothing, which indicates a disconnect
                3. then close the socket for client
                4. set clientfd as invalid so that this variable can be resused later.
                5. then close server and clean up.*/

                if (clientfd != INVALID_SOCKET){
                    shutdown(clientfd,SD_SEND);// call shutdown on sending
                    while(recv(clientfd, buffer, MAXBUF, 0) > 0); //wait until disconnection
                    closesocket(clientfd); //Disconnect
                    clientfd = INVALID_SOCKET;
                }
				fprintf(stdout, "Server has shutdown\n");
				closesocket(sockfd); //Close server
				WSACleanup(); //clean up
				return 1;
            }
            else //send
            {
                toUpperString(upbuffer, buffer, hasRecv); //capitalize string
                send(clientfd, upbuffer, hasRecv, 0);
            }
        }
        /*---close connection---*/
        close(clientfd);
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}

void toUpperString (char* dst, char* src, int n){
    for (int i = 0; i < n; i++){
        if (96 < src[i] && src[i] < 123) //'a' = 96, 'z' = 123
            dst[i] = src[i] - 32; //all alphabets turn uppercase when offset by 32
        else
            dst[i] = src[i];
    }
}
