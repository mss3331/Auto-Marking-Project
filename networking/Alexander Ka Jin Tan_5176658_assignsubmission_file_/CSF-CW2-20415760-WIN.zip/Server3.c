//////////////////////////  Server3.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<time.h>

#define MY_PORT		8989
#define MAXBUF		256


//toUpper without ctype.h
void toUpperString (char* dst, char* src, int n);
int getCommand (char* buf);
//format date, format is an integer that selects a date format. Returns string size
int formatdate (char* strptr, struct tm* date, const int format);
//specificaly converts one digit numbers to two digit. Nothing else.
void twoDigit(char* buf, int num);

int main(int argc , char *argv[])
{
    WSADATA wsa;
    //Initialize these to become INVALID at first.
    SOCKET sockfd = INVALID_SOCKET, clientfd = INVALID_SOCKET;
    	struct sockaddr_in self;
	char inbuffer[MAXBUF], outbuffer[MAXBUF]; int command = 0; time_t epoch; struct tm *date;

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

    int inport = MY_PORT;
    //Input port number
    if (argc > 1)
        inport = strtol(argv[1],NULL,10);
    
	printf("Port number set as: %d\n", inport);

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(inport);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  


	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
    struct sockaddr_in client_addr;
    int addrlen=sizeof(client_addr);
    IN_ADDR* addr;
	/*---forever... ---*/
	while (1)
	{	
        if (clientfd == INVALID_SOCKET){// if a session doesn't exists (socket is invalid)
            /*---accept a connection (creating a data pipe)---*/
            puts("Waiting for incoming connections...\n");
            clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
            addr = &client_addr.sin_addr;
            if (clientfd != INVALID_SOCKET){
                fprintf(stdout, "New connection from %d.%d.%d.%d port %d\n", addr->S_un.S_un_b.s_b1
                                                                        , addr->S_un.S_un_b.s_b2
                                                                        , addr->S_un.S_un_b.s_b3
                                                                        , addr->S_un.S_un_b.s_b4
                                                                        , client_addr.sin_port);
            } else {
                puts("Something wrong happened.");
            }
        }
        else{// if a session exists
            memset(inbuffer,0,MAXBUF);//clear inbuffer

            /*Receive a message*/
            int hasRecv = recv(clientfd, inbuffer, MAXBUF, 0);//receive a message
            
            fprintf(stdout, "Message received: %s of len %d\n", inbuffer, hasRecv-1);

            if (hasRecv > 0){//if success and if connected

                /*message/command handling*/
                command = getCommand(inbuffer);

                switch (command){ //switch through all the command options
                    /*
                    -2: exit server
                    -1: nothing, reserved for toupper (default case)
                     0: get date
                    */
                   
                    case -2://if received exit server
                        /*server shutdown*/

                        /*graceful shutdown procedure:
                        1. tell server to not send anything to client
                        2. wait until client responds with nothing, which indicates a disconnect
                        3. then close the socket for client
                        4. set clientfd as invalid so that this variable can be resused later.
                        5. then close server and clean up.
                        */

                        if (clientfd != INVALID_SOCKET){
                            shutdown(clientfd,SD_SEND);// call shutdown on sending
                            while(recv(clientfd, inbuffer, MAXBUF, 0) > 0); //wait until disconnection
                            closesocket(clientfd); //Disconnect
                            clientfd = INVALID_SOCKET; //reset
                        }
                        fprintf(stdout, "Server has shutdown\n");
                        closesocket(sockfd); //Close server
                        WSACleanup(); //clean up
                        return 0;

                    case 0: //date
                        time(&epoch);
                        date = localtime(&epoch);
                        fprintf(stdout, "Client requested date\n");
                        int size = formatdate(outbuffer,date,1);
                        send(clientfd, outbuffer, MAXBUF, 0);
                        break;
                    
                    default: //everything else
                        toUpperString(outbuffer, inbuffer, hasRecv);
                        send(clientfd, outbuffer, hasRecv, 0);
                }
            } else if (hasRecv <= 0){ //no bytes received (thus disconnect/shutdown) or error (SOCKET_ERROR = -1)
                /*shutdown*/
                closesocket(clientfd); //Disconnect (Can be abrupt or graceful whether exit server is called)
                clientfd = INVALID_SOCKET; //reset
                fprintf(stdout, "Client %d.%d.%d.%d:%d exited.\n", addr->S_un.S_un_b.s_b1
                                                                , addr->S_un.S_un_b.s_b2
                                                                , addr->S_un.S_un_b.s_b3
                                                                , addr->S_un.S_un_b.s_b4);
            }

        }
        
	}

	/*---clean up (should never get here!)---*/
	closesocket(sockfd);
        WSACleanup();
	return 0;
}

void toUpperString(char* dst, char* src, int n){
    printf("len: %d\n", n);
    for (int i = 0; i < n; i++){
        if (96 < src[i] && src[i] < 123) //'a' = 96, 'z' = 123
            dst[i] = src[i] - 32; //all alphabets turn uppercase when offset by 32
        else
            dst[i] = src[i];
    }
}

int getCommand (char* buf){
    char* tok = strtok(buf, " "); //tokenize the inbuffer, getting each stage of the command
    //switch must use integral type :(
    if (strncmp(tok,"date", 5) == 0){
        if (strtok(NULL, " ") == NULL) //check no arguments.
            return 0; //0 represents a date command
    } else if (strncmp(tok, "exit", 4) == 0) {
        tok = strtok(NULL, " ");
        if (tok != NULL)
            if (strncmp(tok, "server", 6) == 0) return -2; //-2 means exit
    }
    return -1; //no command, do toupper
}

int formatdate (char* strptr, struct tm* date, const int format){
    char dd[3];
    twoDigit(dd, date->tm_mday);

    char mm[3];
    twoDigit(mm, date->tm_mon);

    char yy[3];
    twoDigit(yy, date->tm_year % 100);

    char hh[3];
    twoDigit(hh, date->tm_hour);

    switch(format){
        case 1: // dd-mm-yy hh 
            sprintf(strptr, "%.2s-%.2s-%.2s %.2s\r\n", dd, mm, yy, hh);
            return 14;
        default:
            strncpy(strptr, "Invalid.\r\n", 11);
            return 11;
    }
}

void twoDigit(char* buf, int num){
    if (num < 10){ 
        sprintf(buf, "0%d", num);
    }else if (num < 100 && num >= 10){
        sprintf(buf, "%d", num);
    }else{
        return; //do nothing. This is a small function specifically made to convert one digit to two digit.
        // If it's bigger than 100, then don't use it
    }
}