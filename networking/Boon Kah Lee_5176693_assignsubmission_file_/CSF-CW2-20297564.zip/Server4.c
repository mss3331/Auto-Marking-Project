//////////////////////////  Server4.c ////////////////
/*-----User Guideline-----*/
/*compile the Server4.c with this string [ gcc Server4.c -o Server4 -lws2_32 ] */
/* After that,type this code eg:start Server4.exe 8989 */

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<ctype.h>
#include<string.h>
#include<time.h>

#define MY_PORT		MY_PORT
#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
   	struct sockaddr_in self;
	char buffer[MAXBUF],buf[MAXBUF];
    int MY_PORT,i,message;
    char *p;
    time_t t;
    t=time(NULL);
    struct tm date = *localtime(&t);
    struct tm *ptm = localtime(&t); 

    
    if (argc==1)
    {    
        printf ("Port number is not entered.Please type it again\n");    //Addition work in case the user foregt to enter the Port number
        printf ("Enter port number: ");                                  //prompt for port number
        scanf  ("%d",&MY_PORT);                                          //get the port number from the user 
    }
        
    else if (argc>=2)                //condition that the user input the correct way
    {


        for(int i=1; i<argc;i++)
        {   
            
            long converter = strtol(argv[i], &p, 10);    //same funtion with the function atoi() that convert the string to long  
            
            if(converter=='\0')                          //Check the convertor if got any error of space 
            {
                printf("error in port number");
            }
            else
            {
                MY_PORT=converter;
            }
            
        }
        printf("Sever Port number: %d\n",MY_PORT);    //prompt the Server's port number to remind the user
    }
           

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}

        puts("Waiting for incoming connections...");
    

	/*---forever... ---*/
	while (1)
	{	
        struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
        char *clientip = inet_ntoa(client_addr.sin_addr);                    //declare a pointer to store the ip address
        if (clientfd< 0)
	    {
		printf("Server connected failed...\n");                              //prompt to user when failed to connect
	    }
	    else{
	    printf("Server connected successfully...\n");                       //prompt to user when connected successfully 
        getsockname(sockfd, (struct sockaddr *)&client_addr, &addrlen);     //obtain the accurate port number
        printf("Client's port number: %d\n",ntohs(client_addr.sin_port));   //prompt client's port number 
		printf("Client's Ip address: %s\n", clientip);                      //prompt the Ip address of the putty 
        }

        while(1)
        {
            
            for(int i=0 ; i< MAXBUF -1; i++)
            {
                buffer[i]=0;  //initialize the buffer to 0,actually it has the same function like memset()
            }   
            message =recv(clientfd,buffer,MAXBUF,0);

            if(strcmp(buffer,"exit server") == 0) //when the Client insert the word of "exit server",the server will close
                {
                    printf("Client exits the server..."); //prompt the message of the client exit
                    /*---close connection---*/
                    close(clientfd);
                    break;
                }

            if (strcmp(buffer,"date") == 0)  //condtion when user insert"date"
            {
                sprintf(buffer,"%d-%d-%d %d\r\n",date.tm_mday,date.tm_mon+1,date.tm_year+1900-2000,date.tm_hour);
                send(clientfd,buffer, message+7 ,0);                                //+7 increase the length of the message by 7
                printf("Current date and time in (dd-mm-yy hh)format:%s\n",buffer); //print the cilent message
                
            }
            else if(strcmp(buffer,"date1") == 0) //condtion when user insert"date1"
            {
                sprintf(buffer,"%d",date.tm_year+1900);
                send(clientfd,buffer,message ,0);
                printf("Current year:%s\n",buffer); //print the cilent message
            }

            else if(strcmp(buffer,"date2") == 0) //condtion when user insert"date2"
            {
                sprintf(buffer,"%d",date.tm_hour);
                send(clientfd,buffer,message-3,0);      //-3 decrease the length of the message by 3
                printf("Current hour:%s\n",buffer); //print the cilent message
            }

            else if(strcmp(buffer,"date3") == 0) //condtion when user insert"date3"
            {   
              strftime (buf, MAXBUF, "%d-%b-%Y", ptm);
              strcpy(buffer,buf);                   //copy the string of buf to buffer
              send(clientfd,buffer, message+10 ,0); //+10 increase the length of the message by 10
              printf("Curret date in(dd-Mon-yy) format:%s\n",buffer); //print the cilent message
                
            }
            
            else
            {
                for (int i =0;i <message;i++)
                {
                    buffer[i] = toupper(buffer[i]); //convert the Client message to uppercase
                } 
                send(clientfd, buffer ,message ,0); //send the message back to the putty with uppercase
                if(buffer[0] != 13)                 //prevent the junk value of carriage return as its Ascii code is 13
                {
                    printf("length of message: %d\n",message);                  //print out the length of messsage
                    printf("Cilent message in uppercase:%s\n", strupr(buffer)); //print out the client message in uppercase format
                }
            }
	    }

        close(clientfd);
        break;
    }
		

	/*---clean up (should never get here!)---*/
    close(sockfd);
    WSACleanup();
	return 0;
}