//////////////////////////  Server3.c ////////////////
/*-----User Guideline-----*/
/*compile the Server3.c with this string [ gcc Server3.c -o Server3 -lws2_32 ] */
/* After that,type this code eg:start Server3.exe 8989 */

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<ctype.h>
#include<string.h>
#include<time.h>

#define MY_PORT		MY_PORT
#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
   	struct sockaddr_in self;
	char buffer[MAXBUF];
    int MY_PORT,i,message;
    char *p;
    time_t t;
    t=time(NULL);
    struct tm lc = *localtime(&t);  
    
    if (argc==1)
    {    
        printf ("Port number is not entered.Please type it again\n");    //Addition work in case the user foregt to enter the Port number
        printf ("Enter port number: ");                                  //prompt for port number
        scanf  ("%d",&MY_PORT);                                          //get the port number from the user     
    }
        
    else if (argc>=2)
    {


        for(int i=1; i<argc;i++)          //condition that the user input the correct way
        {   
            
            long converter = strtol(argv[i], &p, 10);       //same funtion with the function atoi() that convert the string to long
            
            if(converter=='\0')                            //Check the convertor if got any error of space 
            {
                printf("error in port number");
            }
            else
            {
                MY_PORT=converter;
            }
            
        }
            printf("Sever Port number: %d\n",MY_PORT);    //prompt the Server's port number to remind the user
    }
           
    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}

        puts("Waiting for incoming connections...");
    

	/*---forever... ---*/
	while (1)
	{	
        struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
        char *clientip = inet_ntoa(client_addr.sin_addr);                   //declare a pointer to store the ip address
        if (clientfd< 0)
	    {
		printf("Server connected failed...\n");                             //prompt to user when failed to connect
	    }
	    else{
	    printf("Server connected successfully...\n");                       //prompt to user when connected successfully 
        getsockname(sockfd, (struct sockaddr *)&client_addr, &addrlen);     //obtain the accurate port number
		printf("Client's port number: %d\n",ntohs(client_addr.sin_port));   //prompt client's port number
		printf("Client's Ip address: %s\n", clientip);                      //prompt the Ip address of the putty 
        }

        while(1)
        {
            
            for(int i=0 ; i< MAXBUF -1; i++)
            {
                buffer[i]=0;   //initialize the buffer to 0,actually it has the same function like memset()
            }   
            message =recv(clientfd,buffer,MAXBUF,0);

            if(strcmp(buffer,"exit server") == 0)  //when the Client insert the word of "exit server",the server will close
                {
                    printf("Client exited the server..."); //prompt the message of the client exit
                    /*---close connection---*/
                    close(clientfd);
                    break;
                }

            if (strcmp(buffer,"date") == 0)
            {
                sprintf(buffer,"%d-%d-%d %d",lc.tm_mday,lc.tm_mon+1,lc.tm_year+1900-2000,lc.tm_hour); //sprintf is to ensure it is a string and print
                send(clientfd,buffer, message+7 ,0);         //+7 increase the length of the message by 7
                printf("Current date and time:%s\n",buffer); //print the time
                
            }
            

            else
            {
                buffer[message] ='\0';
                for (int i =0;i <message;i++)
                {

                    buffer[i] = toupper(buffer[i]); //convert the Client message to uppercase

                } 
                    
                send(clientfd, buffer ,message ,0); //send the message back to the putty with uppercase
                if(buffer[0] != 13)                 //prevent the junk value of carriage return as its Ascii code is 13
                    {
                        printf("length of message: %d\n",message);                  //print out the length of messsage
                        printf("Cilent message in uppercase:%s\n", strupr(buffer)); //print out the client message in uppercase format
                    }

            }

	    }
        
        close(clientfd);
        break;
    }
		

	/*---clean up (should never get here!)---*/
    close(sockfd);
    WSACleanup();
	return 0;
}