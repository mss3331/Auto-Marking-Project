//////////////////////////  EchoClient.c ////////////////
/*-----User Guideline-----*/
/*Before use the EchoClient,try to compile a Server.c first such as Server1,Server2,Server3 or Server4 */
//Eg : gcc Server2.c -o Server2 -lws2_32 then start using start Server2 (port number)
//Then you can now compile the EchoClient.c with [gcc EchoClient.c -o EchoClient -lws2_32]
//after that you can start the EchoClient with start EchoClient (port number) eg:start EchoClient 8989
//make sure the server port number is same as the EchoClient port number

#include<io.h>
#include<stdio.h>
#include<winsock2.h>

#define SIZE 1024                //declare a size

int main(int argc , char *argv[])
{
	
	WSADATA wsa;
    int sockfd =0,message=0,MY_PORT,i;
	struct sockaddr_in server;
    char clientmsg[1000], reply[2000],*p;

	if (argc==1)
    {    
        printf ("Port number is not entered.Please type it again\n");    //Addition work in case the user foregt to enter the Port number
        printf ("Enter port number: ");                                  //prompt for port number
        scanf  ("%d",&MY_PORT);                                          //get the port number from the user 
    }
        
    else if (argc>=2)                //condition that the user input the correct way
    {


        for(int i=1; i<argc;i++)
        {   
            
            long converter = strtol(argv[i], &p, 10);    //same funtion with the function atoi() that convert the string to long  
            
            if(converter=='\0')                          //Check the convertor if got any error of space 
            {
                printf("error in port number");
            }
            else
            {
                MY_PORT=converter;
            }
            
        }
        printf("Client requested Port number: %d\n",MY_PORT);    //prompt the Server's port number to remind the user
    }

	printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

	printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}
	printf("Socket created.\n");

	/*---initialize address/port structure---*/
	server.sin_family = AF_INET;
	server.sin_port = htons(MY_PORT);						// Host to Network Short (16-bit)
	server.sin_addr.s_addr = inet_addr("127.0.0.1"); 		//IP adddress -> binary(Ip address to binary)
	
	

	/*---Connect to remote server----*/
	if (connect(sockfd , (struct sockaddr *)&server , sizeof(server)) < 0)
	{
		perror("Error!Failed to connect with the server...");
		return 1;
	}

	puts("Connected to the server\n");

	/*---Communicate with server----*/

	while(1)
	{
		printf("Client Message: ");		//prompt for the Client to enter message
		fgets(clientmsg,SIZE,stdin);    //get the Client message.Reason of fgets is because it can get the space but the scanf cannot read it

		if(clientmsg[0] == '\n') //Compare the cilent message with the ENTER which similar to the ascii code 13,which mean that ENTER= \n = 13.Addition thing.
			{
				printf("\nEmpty message received!Please reenter the message!\n");
				printf("Client Message: ");
				fgets(clientmsg,SIZE,stdin);
       		}
			
		//When Client side enter the exit client and press the Enter the Echo Client will terminate
		if (strcmp(clientmsg,"exit client\n") == 0)
			{
				printf("Client exited...");  //Prompt Client exited then stop the program
				break;
			}

		//Send the message to the server side
		if( send(sockfd , clientmsg , strlen(clientmsg) , 0) < 0)
			{
				puts("Send failed");
				return 1;
			}

			message=recv(sockfd, reply, SIZE,0);
			if( message > 0 )
			{
				reply[message] = 0;               					//use to reduce the junk value when send back to the Echo Client
				printf("Message from the server: %s\n",reply);		//print out the reply message to the Echo Client based on the Server format 
			}

	}

		 if( recv(sockfd, reply, 2000,0) < 0)                      //terminate the Client Side
			{
				puts("received failed!");
				
			} 

    close(sockfd);
    return 0;    
        
}
		
		


