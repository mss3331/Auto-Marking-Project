//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include <string.h>
#include <time.h>
#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    struct sockaddr_in self;
	char buffer[MAXBUF];
    int MY_PORT;

    //input start Server1 8989 in command prompt
    printf("- Networking 1> start server "); //input 8989 again in Server1.exe to initiate program
    scanf("%d", &MY_PORT);

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET)
	{
		printf("Could not create socket: %d",WSAGetLastError());
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) == SOCKET_ERROR )
	{
		printf("Bind failed: %d", WSAGetLastError());
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}

        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
        recv(clientfd, buffer, MAXBUF, 0);//receive input

        printf("%s", buffer);
        strupr(buffer); //convert to uppercase
        printf("\n%s", buffer);
        send(clientfd, buffer, sizeof(buffer), 0);

		/*---close connection---*/
		close(clientfd);
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}

