//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include <string.h>
#include <time.h>
#define MY_PORT		8989 //Input 8989 into server port number to connect.
#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    char buffer[MAXBUF];
    SOCKET sockfd;
    struct sockaddr_in server;
    char message[256], server_reply[256];

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	server.sin_family = AF_INET;
	server.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	server.sin_addr.s_addr = inet_addr("127.0.0.1");

	/*---assign a port number to the socket---*/
	int connection= connect(sockfd, (struct sockaddr*)&server, sizeof(server));
    if ( connection != 0 )
	{
		perror("socket--connect");
		exit(errno);
	}
        puts("Connected to server.");

	/*---forever... ---*/
	while (1)
	{
        printf("Enter message: "); //input client message
	    gets(message);

        if(strcmp(message, "exit client") == 0) //exit command
        {
            close(sockfd);
            exit(1);
        }

	    if(send(sockfd, message, strlen(message), 0)<0)//error while sending
        {
            printf("Message failed to send.\n");
            return 1;
        }

        if(recv(sockfd, server_reply, 256, 0)<0)//error while receiving
        {
            printf("Error receiving server message.\n");
        }
        else
        {
            printf("Server response: %s\n", server_reply); //reply from server
        }
		/*---close connection---*/
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
    WSACleanup();
	return 0;
}

