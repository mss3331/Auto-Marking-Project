//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include <string.h>
#include <time.h>
#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    struct sockaddr_in self;
	char buffer[MAXBUF];
    int MY_PORT, length;
    char address[18];
    time_t t;
    time(&t);

    //input start Server4 8989 in command prompt
    printf("- Networking 1> start server ");//input 8989 again in Server4.exe to initiate program
	scanf("%d", &MY_PORT);

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET)
	{
		printf("Could not create socket: %d",WSAGetLastError());
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/

	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) == SOCKET_ERROR )
	{
		printf("Bind failed: %d", WSAGetLastError());
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}

        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd,(struct sockaddr*)&client_addr, &addrlen);
        struct tm *outtime= localtime(&t);
        printf("IP Address: %s\n", inet_ntoa(client_addr.sin_addr));//print address
        printf("Port Number: %d\n", MY_PORT);//print port number

        while(1)
        {
            //Wait for address and port number to load before entering inputs to prevent error.
            memset(buffer, 0, sizeof(buffer));//reset to prevent carry error
            recv(clientfd, buffer, MAXBUF, 0);//receive input

            if(strcmp(buffer, "exit server")== 0) //exit command
            {
                close(sockfd);
                exit(1);
            }
            else if(strcmp(buffer,"date")==0)
            {
                strftime(buffer, MAXBUF, "%d-%m-%y %H\r\n", outtime);//print day, month, year, hour in 2 digits
                send(clientfd, buffer, sizeof(buffer), 0);
                continue;
            }
            else if(strcmp(buffer, "date1")==0)
            {
                strftime(buffer, MAXBUF, "%Y\r\n", outtime);//print year in 4 digits
                send(clientfd, buffer, sizeof(buffer), 0);
                continue;
            }
            else if(strcmp(buffer, "date2")==0)
            {
                strftime(buffer, MAXBUF, "%H\r\n", outtime);//print hour in 24 hour format
                send(clientfd, buffer, sizeof(buffer), 0);
                continue;
            }
            else if(strcmp(buffer, "date3")==0)
            {
                strftime(buffer, MAXBUF, "%d-%b-%y\r\n", outtime);//print day, abbreviated month name and year
                send(clientfd, buffer, sizeof(buffer), 0);
                continue;
            }
            else
            {
                strupr(buffer);//convert to uppercase
                printf("%s", buffer);
                length = strlen(buffer);//find length of input
                if(buffer[0] != '\r')//prevent carry error
                {
                    printf("\nLength of message: %d\n", length);
                }
                send(clientfd, buffer, sizeof(buffer), 0);
            }
        }
		/*---close connection---*/
        close(clientfd);
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}

