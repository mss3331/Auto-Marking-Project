#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<windows.h>
#define MAXBUF		256

int main()
{
    WSADATA wsa;
    SOCKET sockfd , serverfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];
    char serverReply[MAXBUF];
    int portno;

    puts("Enter port number: "); // asks client to enter port number
    scanf("%d", &portno); // stores the port number
    getchar(); // used to store \n character

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

    self.sin_family = AF_INET;
	self.sin_port = htons(portno);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = inet_addr("127.0.0.1");

    if (connect(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0) { // connect to socket
        printf("Connection with the server failed...\n");
        exit(0);
    }
    else
        printf("Connected to the server..\n");


    while (1)
	{	
        memset(buffer, 0, sizeof(buffer)); // reset buffer
		memset(serverReply, 0, sizeof(serverReply)); // reset server reply buffer

        puts("\nEnter message: ");
        gets(buffer); // input string into buffer

        if(strcmp(buffer, "exit client")==0) // if the input string is "exit client", 
        {
            break; // break out of the while loop and exit program
        }

		send(sockfd, buffer, sizeof(buffer), 0); // send the buffer to the server

        recv(sockfd, serverReply, MAXBUF, 0); // receive reply from the server and store it in a new buffer

        puts("Server's reply: ");
        printf("%s", serverReply); // print the new buffer

        memset(buffer, 0, sizeof(buffer)); // reset buffer
		memset(serverReply, 0, sizeof(serverReply)); // reset server reply buffer
	}

    close(sockfd);
        WSACleanup();
	return 0;

}
