//////////////////////////  Server2.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<windows.h>

#define MY_PORT		8989
#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];

	int portno=0; // variable to store new port number
	int x=0; // to store the return value of recv function

	portno=atoi(argv[3]); // the third argument passed to the main function will be stored as the port no.
	
    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(portno);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		memset(buffer, 0, MAXBUF);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		
		printf("\nThe port number is: %d", portno); // displays the port number
		printf("\nThe IP address is: %s\n", inet_ntoa(client_addr.sin_addr)); // displays the IP address

		while(1)
		{
			memset(buffer, 0, MAXBUF); // clear string

			x=recv(clientfd, buffer, MAXBUF, 0); // receive a string from the client

			if(x>0)
			{
				if(strcmp(buffer,"exit server")==0) // if client's message is "exit server", then terminate
				{
					break;
				}
							
				if (buffer[0]!='\r') // print the message details only if the first character is not a carriage return
				{
					printf("\nThe client's message is: %s", strupr(buffer)); // print the message in uppercase
					printf("\nThe length of the message is: %d\n", strlen(buffer)); // displays the length of the message
				}
					
				send(clientfd, strupr(buffer), x, 0); 
				// using strupr to convert the message sent to the client to uppercase
			}
			else
			break;	

			memset(buffer, 0, MAXBUF); // clear string
		}

		/*---close connection---*/
		close(clientfd);
		return 0;
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}