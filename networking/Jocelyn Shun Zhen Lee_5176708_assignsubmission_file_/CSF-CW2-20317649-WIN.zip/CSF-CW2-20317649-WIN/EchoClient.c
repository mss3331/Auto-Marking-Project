//////////////////////////  EchoClient.c ////////////////

#include <windows.h>
#include <winsock2.h>
#include <stdio.h>

#define BUFSIZE 256


int main(int argc, char *argv[]) {


    WSADATA wsaData;
    SOCKET ConnectSocket = INVALID_SOCKET;
    struct addrinfo *result = NULL,
            *ptr = NULL,
            hints;
    char sendbuf[BUFSIZE];
    char recvbuf[BUFSIZE];

    int recv_len,send_len;

    // Validate the parameters
    if (argc != 3) {
        printf("usage: %s server-addr server-port\n", argv[0]);
        return 1;
    }

    char * host_addr = argv[1];
    char* port = argv[2];

    // Initialize Winsock

    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        printf("WSAStartup failed with error: %d\n", errno);
        return 1;
    }

    ZeroMemory(&hints, sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_protocol = IPPROTO_TCP;

    // Resolve the server address and port
    if (getaddrinfo(host_addr, port, &hints, &result) != 0) {
        printf("getaddrinfo failed with error: %d\n", errno);
        WSACleanup();
        return 1;
    }

    // Attempt to connect to an address until one succeeds
    for (ptr = result; ptr != NULL; ptr = ptr->ai_next) {

        // Create a SOCKET for connecting to server
        ConnectSocket = socket(ptr->ai_family, ptr->ai_socktype,
                               ptr->ai_protocol);
        if (ConnectSocket == INVALID_SOCKET) {
            printf("socket failed with error: %ld\n", WSAGetLastError());
            WSACleanup();
            return 1;
        }

        // Connect to server.
        if (connect(ConnectSocket, ptr->ai_addr, (int) ptr->ai_addrlen) == SOCKET_ERROR) {
            closesocket(ConnectSocket);
            ConnectSocket = INVALID_SOCKET;
            continue;
        }
        break;
    }

    freeaddrinfo(result);

    if (ConnectSocket == INVALID_SOCKET) {
        printf("Unable to connect to server!\n");
        WSACleanup();
        return 1;
    }

    // send and recv;

    while(1){
        memset(sendbuf,0,BUFSIZE);
        memset(recvbuf,0,BUFSIZE);
        send_len = 0;
        recv_len = 0;

        printf("#> ");
        scanf("%s",sendbuf);

        if(strcmp(sendbuf,"exit client")==0)
            break;

        send_len = send(ConnectSocket,sendbuf, strlen(sendbuf),0);
        if(send_len < 1){
            printf("error in sending buffer...\n");
            break;
        }
        printf("sent: %s with length: %d\n",sendbuf,send_len);
        recv_len = recv(ConnectSocket,recvbuf,BUFSIZE,0);
        printf("received: %s with length: %d\n",recvbuf,send_len);
        if(recv_len < 1){
            printf("error in receiving buffer...\n");
            break;
        }

    }

    printf("\n exiting client...");

    // cleanup
    closesocket(ConnectSocket);
    WSACleanup();

    return 0;


}
