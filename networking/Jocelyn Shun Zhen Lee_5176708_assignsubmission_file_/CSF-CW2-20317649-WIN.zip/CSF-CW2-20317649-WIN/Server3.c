//////////////////////////  Server3.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include <time.h>

#define MY_PORT        8989
#define MAXBUF        256


typedef enum {
    false,
    true
} bool;


typedef struct {
    bool serverShouldAcceptClients; // flag for main loop for accepting connection
    int portNumber; // as name suggests , initServerData will provide this, either from defaults or params

    // these three will be initialized on socketCreationMethod , initServerSocket
    WSADATA wsa;
    SOCKET sockfd, clientfd;
    struct sockaddr_in self;


} ServerData;

inline void initServer(int argc, char *argv[]);

inline void cleanUp();

inline void mainRoutine();

ServerData *sv;

int main(int argc, char *argv[]) {


    initServer(argc, argv);
    mainRoutine();
    /*---clean up (should never get here!)---*/
    // unless intended
    cleanUp();
    return 0;
}


/*----init-----*/
bool initServerSocket() {

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2, 2), &sv->wsa) != 0) {
        printf("Failed. Error Code : %d", WSAGetLastError());
        return false;
    }

    printf("Initialised.\n");

    /*---create streaming socket---*/
    if ((sv->sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("Socket");
        exit(errno);
    }

    printf("Socket created.\n");

    /*---initialize address/port structure---*/
    /* bzero(&self, sizeof(self));*/
    sv->self.sin_family = AF_INET;
    sv->self.sin_port = htons(sv->portNumber);      // Host to Network Short (16-bit)
    sv->self.sin_addr.s_addr = INADDR_ANY;

    printf("server port: %d\n", sv->portNumber);

    /*---assign a port number to the socket---*/
    if (bind(sv->sockfd, (struct sockaddr *) &sv->self, sizeof(sv->self)) != 0) {
        perror("socket--bind");
        exit(errno);
    }

    puts("Bind done");

    /*---make it a "listening socket"---*/
    if (listen(sv->sockfd, 20) != 0) {
        perror("socket--listen");
        exit(errno);
    }

    puts("Waiting for incoming connections...");
    return true;
}

bool initServerData(int argc, char *argv[]) {

    if (argc > 1) {
        sv->portNumber = atoi(argv[1]);
    } else {
        sv->portNumber = MY_PORT;
    }
    sv->serverShouldAcceptClients = true;
    return true;
}

void initServer(int argc, char *argv[]) {
    sv = malloc(sizeof(ServerData));
    if (sv == NULL) {
        perror("Could Not allocate initial Data!");
        exit(errno);
    }
    bool initResult = true;
    initResult &= initServerData(argc, argv);
    initResult &= initServerSocket();
    if (!initResult) {
        perror("\nInitialization failed");
        exit(errno);
    }
}

/*----clean-up---*/
void cleanUp() {
    printf("\ntriggered cleanup");
    close(sv->sockfd);
    WSACleanup();
    free(sv);
}


/*---main-routine----*/
inline void handleClient(SOCKET clientfd, SOCKADDR_IN addrlen);

void mainRoutine() {
    while (sv->serverShouldAcceptClients) {


        SOCKADDR_IN addr;
        int addrlen = sizeof(SOCKADDR_IN);
        SOCKET clientfd = accept(sv->sockfd, (struct sockaddr *) &addr, &addrlen);

        handleClient(clientfd, addr);

    }
}


/*------playing with client here------*/

inline void sendDate(SOCKET clientfd);

void handleClient(SOCKET clientfd, SOCKADDR_IN addrlen) {
    //print some data about client:

    printf("--------------------------------\n\nnew connection is received: address: %s port: %d\n",
           inet_ntoa(addrlen.sin_addr), addrlen.sin_port);
    char buffer[BUFSIZ];

    const char *magic_exit = "exit server";

    RECV:
    {
        for (int i = 0; i < BUFSIZ; ++i) {
            buffer[i] = '\0';
        }
        int recv_len = recv(clientfd, buffer, BUFSIZ, 0);

        if (recv_len < 1) {
            printf("\ncouldn't recv anything!");
            goto CLOSE;
        }
        printf("received new message, length: %d msg: %s \n", recv_len, buffer);


        if (strstr(buffer, magic_exit) != NULL) // when exit recved
        {
            printf("requested exist\n");
            goto CLOSE;
        }

        if (strcmp(buffer,"date") == 0){
            sendDate(clientfd);
            goto RECV;
        }


            // legacy of server1
            for (int i = 0; i < recv_len; ++i) {
                buffer[i] = toupper(buffer[i]);
            }

        int send_len = send(clientfd, buffer, recv_len, 0);
        goto RECV;
    }


    CLOSE:
    close(clientfd);

}


void sendDate(SOCKET clientfd){
    // “dd-mm-yy hh
    time_t t = time(NULL);
    struct tm tm = *localtime(&t);
    char str[BUFSIZ];
    // asked and got help from stackoverflow for this, obliviously
    sprintf(str, "%d-%02d-%02d %02d", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);
    send(clientfd, str, strlen(str), 0);
}
