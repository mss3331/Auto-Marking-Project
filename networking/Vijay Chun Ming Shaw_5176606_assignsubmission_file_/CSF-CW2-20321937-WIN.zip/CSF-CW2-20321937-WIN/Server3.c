//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<ctype.h>
#include<string.h>
#include<time.h>

#define MAXBUF		256

int main(int argc , char *argv[])
{
	int a, i;
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(atoi(argv[1]));	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		printf("IP address: %s\n", inet_ntoa(client_addr.sin_addr));
		printf("Port number: %d\n", (int) ntohs(client_addr.sin_port));
		
		a = 1;
		while (a!=0){
			a = recv(clientfd, buffer, MAXBUF, 0);
			int msgLen;
			if(strcmp(buffer, "exit server")==0){ // check if command exit server is called
				goto exitServer;
			}
			else if(strcmp(buffer, "dd-mm-yyyy hh                                                   .")==0){
				time_t t = time(NULL);
				struct tm time = *localtime(&t);
				sprintf(buffer, "%02d-%02d-%02d %02d", time.tm_mday, time.tm_mon + 1, time.tm_year + 1900, time.tm_hour);
				send(clientfd, buffer, a, 0);
			}
			else{
				for (i=0; i<a; i++){
					buffer[i]=toupper(buffer[i]); // modify client message to be uppercase
				}
				send(clientfd, buffer, a, 0); // echo back to client
				msgLen = strlen(buffer);
				printf("Length of message: %d\n", msgLen);
			}
		}
		
		//send(clientfd, buffer, recv(clientfd, buffer, MAXBUF, 0), 0);

		/*---close connection---*/
		close(clientfd);
	}

	/*---clean up (should never get here!)---*/
exitServer:
	close(sockfd);
        WSACleanup();
	return 0;
}
