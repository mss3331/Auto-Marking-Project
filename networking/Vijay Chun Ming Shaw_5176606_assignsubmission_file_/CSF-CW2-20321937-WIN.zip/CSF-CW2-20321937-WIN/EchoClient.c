#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<ctype.h>
#include<string.h>

#define MAXBUF 256
#define localhost "127.0.0.1"

int main(int argc, char *argv[]){
	
	/*---initialise WinSock---*/
	WSADATA wsa;
	int err;
	printf("\nInitialising Winsock...");
	err = WSAStartup(MAKEWORD(2,2), &wsa);
	if(err != 0){
		printf("Failed. Error Code : %d",WSAGetLastError());
		return 1;
	}
	printf("Initialised.\n");
	
	/*---create Socket---*/
	int s;
	s = socket(AF_INET, SOCK_STREAM, 0);
	if (s == INVALID_SOCKET) {
		printf("Error code: %d\n", WSAGetLastError());
		return 1;
	}
	printf("Socket created.\n");
	
	/*---Assigning Addresses---*/
	struct sockaddr_in server;
	server.sin_family = AF_INET;
	server.sin_port = htons(atoi(argv[1]));
	server.sin_addr.s_addr = inet_addr(localhost);
	
	/*---connect---*/
	printf("Connecting to server...\n");
	if (connect(s, (struct sockaddr *)&server, sizeof(server)) != 0) {
        printf("Connection with server failed.\n");
        exit(0);
    }
    else
        printf("Connected to server successfully\n");
	
	while (1){
		/*---send---*/
		char message[MAXBUF] = "";
		int n = 0;
		int len = 0, maxlen = MAXBUF;
		char Server_Reply[MAXBUF];;
		char* pServer_Reply = Server_Reply;
		gets(message);
		if(strcmp(message, "exit client")==0){
			printf("Exiting client...");
			goto exitClient;
		}
		else if(strcmp(message, "date")==0){
			strcpy(message, "dd-mm-yyyy hh                                                   .");
			send(s, message, strlen(message), 0); // send
			/*---receive---*/
			recv(s, Server_Reply, MAXBUF, 0);
			printf("%s\n", Server_Reply);	
		}
		else{
			if( send(s, message, strlen(message), 0)<0)
			{
				printf("Send failed.");
			}
			else
			{
				/*---receive---*/
				n = recv(s, Server_Reply, MAXBUF, 0);
				pServer_Reply += n;
				maxlen -= n;
				len += n;
				Server_Reply[len] = '\0';
				printf("%s\n", Server_Reply);
			}
		}
	}
	
	/*---close & clean up---*/
exitClient:
	close(s);
		WSACleanup();
	return 0;
}