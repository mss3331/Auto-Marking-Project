//////////////////////////  EchoClient.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>

#define MAXREPLY 256
#define MAXBUF 256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd;
    struct sockaddr_in server;
	char buffer[MAXBUF];
	char Server_Reply[MAXREPLY];
	int MY_PORT;
	
	MY_PORT = atoi(argv[1]);
	printf("-Networking 1>start client %d\n", MY_PORT);//insert port_num
	//initialize WinSock
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        return 0;
    }
     
	//create streaming socket
	sockfd=socket(AF_INET, SOCK_STREAM, 0);
    if ( sockfd == INVALID_SOCKET )
	{
		printf("Error code: %d\n", WSAGetLastError());
		return 0;
	}

	//need IP address and Port number of the server
	server.sin_family = AF_INET;
	server.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	server.sin_addr.s_addr = inet_addr("127.0.0.1");  
	
	//have an active connection by calling connect()	
	connect(sockfd,(struct sockaddr *)&server, sizeof(server));
    printf("Connect done.You can start now.\n\n");//to let me know I have connected successfully with the server.
	/*---forever... ---*/
	while(1)
	{
		for(;;)
		{	
			memset(buffer,'\0',sizeof(buffer));//initialize buffer to Null
			memset(Server_Reply,'\0',sizeof(Server_Reply));//initialize Server_Reply to Null
			fgets(buffer,MAXBUF,stdin);//get buffer
			buffer[strlen(buffer)-1]='\0';//make the last char of the buffer to become NULL and neglect it
						
			if((strncmp("exit client",buffer,11))==0)//detect exit client and terminate
			{
				break;
			}
			send(sockfd,buffer,MAXBUF, 0);//send buffer to server
			recv(sockfd, Server_Reply, MAXREPLY, 0);//receive reply from server
			puts(Server_Reply);//print reply from server
		}
		/*---close connection---*/
		close(sockfd);
		break;//break the while loop
	}
	/*---clean up (should never get here!)---*/
	WSACleanup();
	return 0;
}			
		
	


