//////////////////////////  Server2.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>

#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];
	int MY_PORT;
	
	MY_PORT = atoi(argv[1]);//scan port num in server
	printf("-Networking 1>start server %d\n", MY_PORT);//insert port_num
    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  
	
	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while(1)
	{
		struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);
		
		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		printf("IP address of client: %s\n",inet_ntoa(client_addr.sin_addr));//printf IP address of client
		printf("Port number: %d\n",client_addr.sin_port);//print Port Number
		
		for(;;)
		{	
			int len=0;
			char *buffer1;
			char *buffer2;
			buffer2=buffer;
			memset(buffer,'\0',sizeof(buffer));//make the buffer equals to NULL everytime
			recv(clientfd, buffer, MAXBUF, 0);
			
			if((strncmp("exit server",buffer,11))==0)//detect exit server
			{
				printf("exited server");
				break;
			}
			else
			{
				if(buffer[0]=='\r'||buffer[0]=='\n')//neglect space and newline from buffer to continue with others
					continue;
				for(;*buffer2!='\0';buffer2++)//count string length
				{
					if(*buffer2!='\r'&&*buffer2!='\n')
						len++;
				}
	
				buffer1=strupr(buffer);//make the string uppercase
				printf("Uppercase: %s\n", buffer1);
				printf("Length of message: %d\n",len);
			}
			send(clientfd, buffer,strlen(buffer), 0);
		}
			
		/*---close connection---*/
			close(clientfd);
	}
	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}			
		
	


