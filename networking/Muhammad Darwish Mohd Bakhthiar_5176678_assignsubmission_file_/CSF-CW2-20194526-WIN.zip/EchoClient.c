//MUHAMMAD DARWISH 20194526
//EchoClient.c

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<ctype.h>       //added for charcter manipulation functions
#include<string.h>      //added for string manipulation functions

#define MY_PORT		8989
#define MAXBUF		256

int main(){
    /*---create socket for client---*/
    WSADATA wsa;
    SOCKET client;

    /*---initializing variables---*/
    int err;
    char cli_in[MAXBUF], serv_out[MAXBUF];

    /*---checks if wsastartup works---*/
    err= WSAStartup(MAKEWORD(2,2), &wsa);
    if(err!=0)      //wsastartup not working, notifies client
    {
        printf("Error occurred : wsastartup unsuccessful");
        return 0;
    }

    /*---checks if socket created---*/
    client= socket(AF_INET,SOCK_STREAM,0);
    if(client==INVALID_SOCKET)      //socket not created, notifies client
    {
        printf("Error code: %d\n",WSAGetLastError());
        return 0;
    }

    /*---port,ip,protocol definition*/
    struct sockaddr_in server;
    server.sin_family = AF_INET;
    server.sin_port = htons(MY_PORT);
    server.sin_addr.s_addr = inet_addr("127.0.0.1");

    /*---creates connection with server---*/
    connect(client,(struct sockaddr*)&server,sizeof(server));

    while(1)
    {
        /*---clear buffer---*/
        for(int i=0;i<MAXBUF;i++)
        {
            cli_in[i]='\0';
            serv_out[i]='\0';
        }

        /*---blank input sent to server---*/
        while(strlen(cli_in)==0)
        {
            gets(cli_in);
        }

        /*---terminate client if instructed---*/
        if(strcmp(cli_in,"exit client")==0)
        {
            printf("exiting client\n");
            close(client);
            return 0;
        }

        /*---check if connection to server still online---*/
        if(send(client,cli_in,strlen(cli_in),0)<0)  //check if client input sent
        {
            printf("Error: input not sent\n");
        }

        if(recv(client,serv_out,MAXBUF,0)<0)        //check if client input recieved
        {
            printf("Error: input not received\n");
        }
        else
        {
            /*---display server output if no errors---*/
            printf("%s",serv_out);
        }
    }
    close(client);
    WSACleanup();
}
