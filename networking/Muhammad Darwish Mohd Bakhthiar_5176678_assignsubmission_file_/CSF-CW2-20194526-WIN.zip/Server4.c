//MUHAMMAD DARWISH 20194526
//Server2.c

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<ctype.h>       //added for charcter manipulation functions
#include<string.h>      //added for string manipulation functions
#include<stdlib.h>      //added for other useful functions

//remove definition of MY_PORT so it can be inputted by user
#define MAXBUF		256

int main(int argc , char *argv[])
{
    /*---initializing and defining variables---*/
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    struct sockaddr_in self;
    char buffer[MAXBUF];
    int MY_PORT = atoi(argv);

    /*---initialising winsock---*/
    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
        printf("Initialised.\n");

    /*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
    {
        perror("Socket");
        exit(errno);
    }
    printf("Socket created.\n");

    /*---initialize address/port structure---*/

        /*---take port number inputted by user---*/
        recv(clientfd,MY_PORT,sizeof(int),0);
        //bzero(&self, sizeof(self));
        self.sin_family = AF_INET;
        self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
        self.sin_addr.s_addr = INADDR_ANY;

        /*---assign a port number to the socket---*/
        if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
        {
            perror("socket--bind");
            exit(errno);
        }
        puts("Bind done");

        /*---make it a "listening socket"---*/
        if ( listen(sockfd, 20) != 0 )
        {
            perror("socket--listen");
            exit(errno);
        }
        puts("Waiting for incoming connections...");

    /*---forever... ---*/
    while (1)
    {
        /*---accept connection/create data pipe)---*/
        clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);

        /*---display ip address and port number---*/
        printf("\n\nIP address: %s\nPort number of server: %d \nPort number of client: %d\n",inet_ntoa(client_addr.sin_addr),ntohs(self.sin_port),ntohs(client_addr.sin_port));

        while (1)
        {	
            struct sockaddr_in client_addr;
            int addrlen=sizeof(client_addr);

            /*---accept a connection (creating a data pipe)---*/
            clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);

            /*---clear buffer once new connection is made---*/
            for(int i=0;i<MAXBUF;)
            {
                buffer[i]='\0';
                i++;
            }

            /*---receive input and store string from buffer---*/
            recv(clientfd, buffer, MAXBUF, 0);

            /*---converts string to all uppercase---*/
            for (int i = 0; buffer[i]!='\0'; i++)
            {
                if(buffer[i] >= 'a' && buffer[i] <= 'z')
                {
                    buffer[i] = buffer[i] -32;
                }
            }

            /*---checks if connection still online---*/
            if(buffer[0] != '\n' && strlen(buffer)!=0) //oconnection is still online
            {
                /*---display buffer length---*/
                printf("\nLength of the message: %d",strlen(buffer));

                /*---creates blank space after buffer---*/
                strcat(buffer,"\n\n\r");

                /*---returns changed buffer to client---*/
                send(clientfd, buffer, strlen(buffer), 0);
            }
            else if(strlen(buffer)==0) //connection is not online
            {
                /*---terminate socket connection---*/
                printf("\nSocket terminating...");
                close(clientfd);
                break;
            }

            /*---date command function---*/
            time_t t = time(NULL);
            struct tm  *time_info;
            time_info = localtime(&t); //determine current time
            if(strcmp(buffer,"DATE")==0)        /*---send to client in dd-mm-yy hh---*/
            {
                strftime(buffer, sizeof(buffer), "%d-%m-%y %H\n\n\r", time_info); //%d = dd, %m = mm, %y = yy, %H = hh
                send(clientfd, buffer, strlen(buffer), 0);
            }
            else if(strcmp(buffer,"DATE1")==0)  /*---send to client in yyyy---*/
            {
                strftime(buffer, sizeof(buffer), "%Y\n\n\r", time_info);    //%Y = yyyy
                send(clientfd, buffer, strlen(buffer), 0);
            }
            else if(strcmp(buffer,"DATE2")==0)  /*---send to client in hh---*/
            {
                strftime(buffer, sizeof(buffer), "%H\n\n\r", time_info);    //%H = hh
                send(clientfd, buffer, strlen(buffer), 0);
            }
            else if(strcmp(buffer,"DATE3")==0)  /*---send to client in dd-mon-yy---*/
            {
                strftime(buffer, sizeof(buffer), "%d-%b-%y %H\n\n\r", time_info); //%d = dd, %m = mm, %y = yy
                send(clientfd, buffer, strlen(buffer), 0);
            }
        }
    }

    /*---clean up (should never get here!)---*/
    close(sockfd);
    WSACleanup();

    /*---exit command function---*/
    recv(clientfd, buffer, MAXBUF, 0);
        /*---converts all to uppercase---*/
        for (int i = 0; buffer[i]!='\0'; i++)
        {
            if(buffer[i] >= 'a' && buffer[i] <= 'z')
            {
                buffer[i] = buffer[i] -32;
            }
        }
        
        /*---terminate server if exit server(any capitalisation) is typed---*/
        if(strcmp(buffer,"EXIT SERVER"==0)
        {
            close(clientfd);
            return 0;
        }
    
return 0;
}

