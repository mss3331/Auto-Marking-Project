#include<io.h>
#include<stdio.h>
#include<string.h>
#include<winsock2.h>

#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    struct sockaddr_in self;
	char buffer[MAXBUF];
	int newport;

	printf("Please enter preferred port number : ");
	scanf("%d", &newport);

    // TCP uses port 0 - 65535  
	if(newport > 65535 || newport < 1) 
	{
        printf("Error. Please enter valid port number.");
        exit(0);
	} 
	

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

    printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(newport);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

    puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}

    puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{	
        struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);
		int Input;

		/*---accept a connection (creating a data pipe)---*/
		if((clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen)) > 0)
		{

            printf("Your IP Address: %s \n", inet_ntoa(client_addr.sin_addr));
			//converts the Internet host address in, given in network byte order, to a string in IPv4 dotted-decimal notation
            
			printf("Your Port Number: %d \n", ntohs(self.sin_port));
			//converts a 16-bit value from network-byte order to host-byte order

		} // end if

		while(1)
		{
            memset(buffer, 0, MAXBUF);
			
            Input = recv(clientfd, buffer, MAXBUF, 0);
			// recv returns the length of the message written 
		    //to the buffer pointed to by the buffer argument
                
		    if(strcmp(buffer, "exit server") == 0)
			{
                break;
				// exit if client enters "exit server"
            }
            
			if(Input > 0)
			{
                if(buffer[0] != 13) // if buffer[0] is not carriage return 
				{
                    printf("Length of input : %d\n", strlen(buffer));

                } // end inner if
                
				send(clientfd, strupr(buffer), Input, 0); // send uppsercase string back 
            } // end outer if
            else
			{
                break;
            } // end else
		
	    } // end inner while

		/*---close connection---*/
		close(clientfd);
		
	} // end outer while

	/*---clean up (should never get here!)---*/
	close(sockfd);
    WSACleanup();
	return 0;

} // end main