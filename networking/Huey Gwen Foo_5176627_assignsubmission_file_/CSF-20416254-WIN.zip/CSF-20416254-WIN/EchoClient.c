#include<io.h>
#include<stdio.h>
#include<string.h>
#include<winsock2.h>

#define MAXBUF		256
#define SIZE 10

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    struct sockaddr_in server;
	char command[MAXBUF],serverreply[MAXBUF];
	char newport[SIZE];

	printf("Please enter preferred port number : ");
	gets(newport);
	
	int latestport = atoi (newport);

    // TCP uses port 0 - 65535  
	if(latestport > 65535 || latestport < 1) 
	{
        printf("Error. Please enter valid port number.");
        exit(0);
	} 
	

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

    printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	server.sin_family = AF_INET;
	server.sin_port = htons(latestport);
	server.sin_addr.s_addr = inet_addr("127.0.0.1");

	/*---connect socket to server---*/
    if (connect(sockfd, (struct sockaddr*)&server, sizeof(server)) < 0 )
	{
		printf("Failed to connect. Error Code : %d",WSAGetLastError());
		exit(errno);
	}

    puts("Connected to server.");

	/*---infinite send and receive tunnel... ---*/
	while (1)
	{	
		//prompt user for command
		printf("\nEnter command: ");
		gets(command);

		//if command is "exit client", terminate
		if (strcmp(command, "exit client") == 0)
		{
		break;
		}
		
		//send command to respective servers 
        if((send(sockfd, command, strlen(command), 0)) < 0)
		{
			printf("Failed to send command. Error Code : %d",WSAGetLastError());
			exit(errno);
		}

		//receive reply
		int Input = recv(sockfd, serverreply, MAXBUF, 0);

		serverreply[Input] = '\0';

		printf("Reply : %s\n", serverreply);
		
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
    WSACleanup();
	return 0;
}