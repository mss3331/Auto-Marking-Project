#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>

#define MNB         256

int main(int argc , char*argv[])
{
    int HOME_PORT; //initialise part variable

    printf("Enter the Port Number:") //insert the port number
    scanf("%d",&HOME_PORT); //scan port number

    WSADATA wsa;
    SOCKET sockfd , clientfd;
        struct sockaddr_in self;
        char buff[MNB];


    printf("\nInitialising Winsock...");
    if (WSAStratup(MAKEWORD(2,2),&wsa)!=0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

    if ((sockfd=socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror("Socket");
        exit(errno);
    }

    printf("Socket created.\n");

    self.sin_family = AF_INET;
    self.sin_port = htons(HOME_PORT);
    self.sin_addr.s_addr = INADDR_ANY;

    if (bind (sockfd, (struct sockaddr*)&self, sizeof(self)) !=0)
    {
        perror("socket--bind");
        exit(errno);
    }

    while(1)
    {
        struct sockadd_in client_addr;
        int addrlen=sizeof(client_addr);

        clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);

        int p = recv(clientfd, buff, MNB, 0);

        buff[p] = '\0';

        strupr(buff);

        send(clientfd, buff, strlen(buff), 0); //change the strings to capital letter


        close(clientfd);
    }

    close(sockfd);
    WSACleanup();
    
    return 0;
}