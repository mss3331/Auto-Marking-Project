#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<time.h>
#include<string.h>

#define MAXBUF     	256

int main(int argc , char *argv[])
{
	int cmp;
    int HOME_PORT; //initialise port variable
	char exit_serv[]="exit server";
	char terminate[]="Server terminated successfully....";
    
	printf("Enter the Port Number:"); //prompt port number
    scanf("%d", &HOME_PORT); //scan port number
	
WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}
        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(HOME_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}
        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        puts("Waiting for incoming connections...");
		puts(" ");
	
	while (1)
	{	
		struct sockaddr_in client_addr;	
		int addrlen=sizeof(client_addr);
		int p;

		if((clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen)) > 0)
		{
			
			printf("Client IP Address: %s\n", inet_ntoa(client_addr.sin_addr));
			
			printf("Client Port Number: %d\n", ntohs(self.sin_port));
		}

		
		while ((p = recv(clientfd, buffer, MAXBUF-1, 0)) > 0)
		{	
			cmp=strcmp(buffer,exit_serv);
			
			buffer[p] = '\0';	

			
			if (strcmp(buffer, "date\0") == 0)
			{							
				time_t rawtime;
   				time(&rawtime);
   				tzset();

   				
				char time_str[255];
				struct tm *time_info = localtime(&rawtime);
				strftime(time_str, 255, "%d-%m-%y %H", time_info);

				printf("Date in 'dd-mm-yy hh' format: %s\n", time_str);
				send(clientfd, time_str, strlen(time_str), 0);
				
				continue;
			}
			else if (strcmp(buffer, "date1\0") == 0)
			{							
				time_t rawtime;
   				time(&rawtime);
   				tzset();

   				
				char time_str[255];
				struct tm *time_info = localtime(&rawtime);
				strftime(time_str, 255, "%Y", time_info);

				printf("Date in 'yyyy' format: %s\n", time_str);
				send(clientfd, time_str, strlen(time_str), 0);
				
				continue;
			}
			else if (strcmp(buffer, "date2\0") == 0)
			{							
				time_t rawtime;
   				time(&rawtime);
   				tzset();

   				
				char time_str[255];
				struct tm *time_info = localtime(&rawtime);
				strftime(time_str, 255, "%H", time_info);

				printf("Date in 'hh' format: %s\n", time_str);
				send(clientfd, time_str, strlen(time_str), 0);
				
				continue;
			}
			else if (strcmp(buffer, "date3\0") == 0)
			{							
				time_t rawtime;
   				time(&rawtime);
   				tzset();

   				
				char time_str[255];
				struct tm *time_info = localtime(&rawtime);
				strftime(time_str, 255, "%d-%b-%y", time_info);

				printf("Date in 'dd-Mon-yy' format: %s\n", time_str);
				send(clientfd, time_str, strlen(time_str), 0);
				
				continue;
			}
			
			if (buffer[0] != 13)
			{
			
				printf("Message length: %d\n", p);
			}
			
			if (cmp==0)
			{
				send(clientfd, terminate, strlen(terminate), 0);
				return 0;
				break;
				
			} 
		
			send(clientfd, strupr(buffer), n, 0); //changes the string to upper case
		}

		
		if (shutdown(clientfd, 2) == 0)
		{
			close(clientfd);
			printf("\nClient disconnected\n");
		} 
		else 
		{
			printf("\nFail to close connection.\n");
		}

	}

	
	close(sockfd);
    WSACleanup();
	return 0;
}

