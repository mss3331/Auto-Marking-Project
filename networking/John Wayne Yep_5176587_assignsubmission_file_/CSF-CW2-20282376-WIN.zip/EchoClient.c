//////////////////////////  EchoClient.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<time.h>

#define MY_PORT		8989
#define MAXBUF		256

int main(int argc , char *argv[])
{
	WSADATA wsa;
	int err;
	err=WSAStartup(MAKEWORD(2,2),&wsa);
	if (err!=0) return;

	char *a = argv[1]; //pointer to argument[1] (port number)
  	int num = atoi(a); //converts argument[1] from string to integer 

	
	//----Create socket-----//
	SOCKET s;
	s=socket(AF_INET,SOCK_STREAM,0);           
	if (s==INVALID_SOCKET){
		printf("Error code: %d\n",WSAGetLastError());
		return;
	}
	else
	{
		printf("socket created");
	}

	struct sockaddr_in server;

	server.sin_family=AF_INET;
	server.sin_port=htons(num);
	server.sin_addr.s_addr=inet_addr("127.0.0.1");

	
	connect(s,(struct sockaddr *)&server,sizeof(server)); //connect to server

	while(1){
		
		char message[256]=""; //reset buffer at the start of every loop

		printf("\nYou: ");
		gets(message);

		if (strncmp("exit client",message,11)==0){             //clsoe(s) if "exit client" is entered
			close(s);
			break;         //break from while(1)
		}
		
		
		if(send(s,message,strlen(message),0)<0){            //send data to server
			perror("Send:");
			exit(errno);
		}

		char Server_Reply[256]="";		//reset buffer at the start of every loop

		if (recv(s,Server_Reply,256,0)<0)              //receive data from server
		{
			printf("Receive failed");
		}
		else
		{
			printf("\nServer: %s\n",Server_Reply);
		}

		

		
	}	
	
	close(s);
	WSACleanup();
	return 0;
	
}