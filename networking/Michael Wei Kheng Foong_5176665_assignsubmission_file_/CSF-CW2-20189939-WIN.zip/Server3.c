//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<sys/socket.h>
#include<time.h>

#define MY_PORT		8989
#define MAXBUF		256

int main(int argc , char *argv[])

{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
	int op= TRUE;
	int  addrlen, new_socket, client_socket[30], max_client =30, activity, i, valread, sd;
	int max_sd;
	int s;
	int 
    struct sockaddr_in self;
	char buffer[MAXBUF];
	char recvBuf
	int recvbuflen ;
	int SenderAddrSize = sizeof( SenderAddr);
	int iResult;
	
	fd_set readfds;
	
	for (i=0; i< max_clients; i++)
	{
		client_socket[i]=0;
	}

    printf("\nInitialising Winsock... ");
	iResult = WSAStartup(MAKEWORD(2,2), &wsaData);
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}
	
        printf("Socket created.\n");
		
	//create receiver socket
	RecvSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_UDP);
	if (RecvSocket == INVALID_SOCKET){
		wprintf(L"socket failed with error %d\n", WSAGetLastError());
		return 1;
	}
		

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  
	//Bind receiving 
	RecvAdder.sin_family= AF_INET
	RecvAdder.sin_port = htons(MY_PORT);
	RecvAdder.sin_addr.s_addr =htonl(INADDR_ANY);
	
	iResult = bind(RecvSocket, (SOCKADDR *)&RecvAddr, sizeof(RecvAddr));
	if(iResult !=0){
	wprint(L"bind failed with error %d\n", WSAGetLastError());
	return 1
	
	
	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		
		//get the connections' IP address and Port number
		addrlen= sizeof(client_addr);
		getpeername(s, (struct sockaddr*)&client_addr, &addrlen);
		
		//send client msg in uppercase
		send(clientfd, buffer, recv(clientfd, buffer, MAXBUF, 0), toupper(buffer));
		
    if (iResult == SOCKET_ERROR) {
        printf("send failed: %d\n", WSAGetLastError());
        closesocket(ConnectSocket);
        WSACleanup();
        return 1;
    }

    printf("Bytes Sent: %ld\n", iResult);

    // shutdown the connection since no more data will be sent
    iResult = shutdown(ConnectSocket, SD_SEND);
    if (iResult == SOCKET_ERROR) {
        printf("shutdown failed: %d\n", WSAGetLastError());
        closesocket(ConnectSocket);
        WSACleanup();
        return 1;
    }

    // Receive until the peer closes the connection
    do {

        iResult = recv(ConnectSocket, recvbuf, recvbuflen, 0);
        if ( iResult > 0 )
            printf("Bytes received: %d\n", iResult);
		//Closes connection and terminate if input is exit server
			scanf("%d\n", &iResult);
			while(&iResult == "exit server"){
				printf("Connection closed\n")
				}
			//date and time from ascii
			while(&iResult == "date"){
				time_t current_time;
				struct tm*local_time;
				current_time=time(NULL);
				local_time= localtime(&current_time);
				printf("The time is: %s", asctime(local_time));
				}
        else if ( iResult == 0 )
            printf("Connection closed\n");
        else
            printf("recv failed: %d\n", WSAGetLastError());
	
		}while( iResult >0);
		
		
		
		

	
		/*---close connection---*/
		close(clientfd);
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}
