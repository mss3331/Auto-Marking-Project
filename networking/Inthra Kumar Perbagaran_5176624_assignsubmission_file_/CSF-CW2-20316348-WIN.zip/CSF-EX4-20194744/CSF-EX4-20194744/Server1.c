
#include<io.h>
#include<stdio.h>
#include<winsock2.h>

#define MY_PORT		8989
#define MNB			256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
		char buffer[MNB];

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);
	self.sin_addr.s_addr = INADDR_ANY;

	
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");


	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		
		int n = recv(clientfd, buffer, MNB, 0);
		
		buffer[n] = '\0';

		
		strupr(strrev(buffer));	

		send(clientfd, buffer, strlen(buffer), 0);

		
		close(clientfd);
	}

	
	close(sockfd);
        WSACleanup();
	return 0;
}

