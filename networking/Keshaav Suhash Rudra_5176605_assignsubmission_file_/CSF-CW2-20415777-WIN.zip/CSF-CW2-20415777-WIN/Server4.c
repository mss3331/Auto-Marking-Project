//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<time.h>

#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET s , client;
    struct sockaddr_in server;
	char buffer[MAXBUF]="";

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (s = socket(AF_INET, SOCK_STREAM, 0)) < 0 )// socket descriptor
	{
		perror("Socket");
		exit(errno);
	}

    printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	int port;
	port=atoi(argv[3]);
	server.sin_family = AF_INET;//Internet protocol
	server.sin_port = htons(port);//port number
	server.sin_addr.s_addr = INADDR_ANY;

	/*---assign a port number to the socket---*/
    if ( bind(s, (struct sockaddr*)&server, sizeof(server)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(s, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}

    puts("Waiting for incoming connections...");

	/*---forever... ---*/
	int displaynumber=1;// displayed message number on server side
	char exit[MAXBUF]= "exit server";
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);
		/*---accept a connection (creating a data pipe)---*/

		client= accept(s, (struct sockaddr*)&client_addr, &addrlen);
        if(client >0)
		{
			printf("IP address: %s\n",inet_ntoa(client_addr.sin_addr));//IP address
			printf("Port number: %d\n",htons(client_addr.sin_port));//Port number
		}
		while(1)
		{
			memset(buffer,'\0', MAXBUF);//reset buffer
			int bufferlen = recv(client, buffer, MAXBUF, 0); //length of buffer
			if(bufferlen > 0)//does server receive more than 1 char?
			{
			    if(strcmp(buffer,exit)!=0){
			        //if user does not enter exit
                    if(buffer[0]!= '\r')
                    {
                        if(strcmp(buffer,"date")!=0 && strcmp(buffer,"date1")!=0 && strcmp(buffer,"date2")!=0 && strcmp(buffer,"date3")!=0){
                            printf("Length of Message %d : %d\n",displaynumber,bufferlen);
                            displaynumber++;
                            strupr(buffer);// capitalize the client response
                        }
                        else if(strcmp(buffer,"date")==0){// if date is entered
                            time_t ntime = time(NULL);
                            struct tm *Ttime = localtime(&ntime);//time
                            strftime(buffer, sizeof(buffer), "%d-%m-%y %H\r\n", Ttime);//date and (time in 24h format) copied to buffer
                            send(client,buffer, strlen(buffer), 0);
                            continue;
                        }
                        else if(strcmp(buffer,"date1")==0){// if date is entered
                            time_t ntime = time(NULL);
                            struct tm *Ttime = localtime(&ntime);//time
                            strftime(buffer, sizeof(buffer), "%Y\r\n", Ttime);//full year copied to buffer
                            send(client,buffer, strlen(buffer), 0);
                            continue;
                        }
                        else if(strcmp(buffer,"date2")==0){// if date is entered
                            time_t ntime = time(NULL);
                            struct tm *Ttime = localtime(&ntime);//time
                            strftime(buffer, sizeof(buffer), "%H\r\n", Ttime);//hour copied to buffer
                            send(client,buffer, strlen(buffer), 0);
                            continue;
                        }
                        else if(strcmp(buffer,"date3")==0){// if date is entered
                            time_t ntime = time(NULL);
                            struct tm *Ttime = localtime(&ntime);//time
                            strftime(buffer, sizeof(buffer), "%d-%b-%y\r\n", Ttime);//day number of the month, day and year copied to buffer
                            send(client,buffer, strlen(buffer), 0);// send data to client
                            continue;
                        }
                    }
                    send(client, buffer, bufferlen, 0);//send capitalized buffer
                }
                else
                    break;
			}
		}

		close(client);
        return 0;
        /*---close connection---*/
	}
	/*---clean up (should never get here!)---*/
	close(s);
        WSACleanup();
	return 0;
}






