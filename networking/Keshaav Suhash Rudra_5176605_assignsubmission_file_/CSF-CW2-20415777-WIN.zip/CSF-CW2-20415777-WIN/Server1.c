//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>

#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET s , client;
    struct sockaddr_in server;
	char buffer[MAXBUF]="";

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (s = socket(AF_INET, SOCK_STREAM, 0)) < 0 )// socket descriptor
	{
		perror("Socket");
		exit(errno);
	}

    printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	int port;
	port=atoi(argv[3]);
	server.sin_family = AF_INET;//Internet protocol
	server.sin_port = htons(port);//port number
	server.sin_addr.s_addr = INADDR_ANY;

	/*---assign a port number to the socket---*/
    if ( bind(s, (struct sockaddr*)&server, sizeof(server)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(s, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}

    puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);
		/*---accept a connection (creating a data pipe)---*/
		client = accept(s, (struct sockaddr*)&client_addr, &addrlen);

		recv(client, buffer, MAXBUF, 0);// receiving from the client
        strupr(buffer);// capitalize received data from the client
        send(client, buffer, MAXBUF, 0);//sends the changed data back to client
		close(client);
	}

	/*---clean up (should never get here!)---*/
	close(s);
        WSACleanup();
	return 0;
}
