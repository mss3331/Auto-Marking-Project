#include<io.h>
#include<stdio.h>
#include<winsock2.h>

#define MAXBUF		256
#define MY_PORT		8989

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET s , client;
    struct sockaddr_in server;
	char buffer[MAXBUF]="";

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (s = socket(AF_INET, SOCK_STREAM, 0)) < 0 )// socket descriptor
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	server.sin_family = AF_INET;
	server.sin_port = htons(MY_PORT);
	server.sin_addr.s_addr = INADDR_ANY;
    char response[MAXBUF]="";//server response
    char exit[MAXBUF]= "exit client";
    connect(s, (struct sockaddr*)&server, sizeof(server));//connect server

	while(1){
		memset(buffer, 0, sizeof(buffer));//reset buffer
		memset(response, 0, sizeof(response));//reset response from server

	    printf("Enter input : ");
		gets(buffer);//client reads from console
		if(strcmp(buffer,exit)==0){
            close(s);// client will terminate if "exit client" is read
            WSACleanup();
		}

        int sent=send(s, buffer , strlen(buffer) , 0);
		if( sent < 0)
		{
			printf("error sending\n");
			return 1;//error
		}
		else{
            puts("sent");
		}

        if (strlen(buffer)!=0){
            if( recv(s , response , MAXBUF , 0) < 0)
            {
                printf("error receiving");
                break;
            }
            else
                printf("Response: \"%s\"\n", response);// server response
        }

	}
    close(client);
	/*---clean up (should never get here!)---*/
	close(s);
        WSACleanup();
	return 0;
}
