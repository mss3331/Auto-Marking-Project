//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>

#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd;
    struct sockaddr_in servaddr;
	char buffer[MAXBUF];

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	
	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons(atoi(argv[1]));	  // Get target server from console
	servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");  

	/*---assign a port number to the socket---*/
    if ( connect(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) != 0 )
	{
		perror("socket--connect");
		exit(errno);
	}

        puts("Connect done");

	/*---forever... ---*/
	while (1)
	{
		
		//Clear out the previous data in buffer.
		memset(buffer,'\0',MAXBUF);
		
		//Get the input and store into buffer.
		gets(buffer);
		
		//Check weather exit client is input.
		if(strcmp(buffer,"exit client")==0)
			break;
		
		//Send buffer to server.
		send(sockfd, buffer, strlen(buffer), 0);
		
		//Recive data from server.
		recv(sockfd, buffer, MAXBUF, 0);
		
		//Print the data.
		printf("%s\n",buffer);
	}
	
	
	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}

