/////////////////////////Server2.c//////////////
#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<windows.h>

#include<string.h>

#define MY_PORT     8989
#define MAXBUF		256


int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];

    /---create a 16-bit short to store port from 4th argument---/
    int portnum=0;
    portnum=atoi(argv[3]);

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/---create streaming socket---/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/---initialize address/port structure---/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	/---change from predefined port number to argument port number---/
	self.sin_port = htons(num);	  
	self.sin_addr.s_addr = INADDR_ANY;  

	/---assign a port number to the socket---/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/---make it a "listening socket"---/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	/---forever... ---/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/---accept a connection (creating a data pipe)---/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		
		/---Outputs port number"---/
        printf("The number on port is: %d\n",port_no);     
         /---Outputs ip"---/                           
        printf("i.p address is: %s\n",inet_ntoa(client_addr.sin_addr));     
		int recv_size;
        
        while(1)
        {
            /---clear buffer---/
            memset(buffer,0,MAXBUF);                                    
            recv_size=recv(clientfd, buffer, MAXBUF, 0);                
            if(recv_size > 0)
            {
                /---checks for termination condition---/
                if(strcmp(buffer,"exit server")!=0) 
                {
                    if(buffer[0] != '\r')  
                    {
                        printf("Client message: %s \n, Message length: %d \n",strupr(buffer),strlen(buffer)); 
                    }
                /---send message to client---/
                send(clientfd, strupr(buffer),recv_size, 0); 
                /---clear buffer for next message---/
                memset(buffer,0,MAXBUF);                   
                }
                else
                    break;
            }
            else
                break;  
        }

		/---close connection---/
		close(clientfd);
        return 0;
	}

	/---clean up (should never get here!)---/
	close(sockfd);
        WSACleanup();
	return 0;
}