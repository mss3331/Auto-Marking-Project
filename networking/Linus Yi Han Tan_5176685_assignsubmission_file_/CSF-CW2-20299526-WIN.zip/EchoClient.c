//////////////////////////  EchoClient.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#define MAXBUF		256
#define SERVER "127.0.0.1" //define localhost

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd;
    int MY_PORT;
    	struct sockaddr_in self;
	char buffer[MAXBUF];
	char message[MAXBUF];

    printf("- Networking 1>start server "); //get port number
	scanf("%d",&MY_PORT);
    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

    /*---create socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

    /*---initialize address/port structure---*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = inet_addr(SERVER);

	if (connect(sockfd, (struct sockaddr*)&self , sizeof(self)) != 0) { //connect to server
		perror("Server");
		exit(errno);
	}

	puts("Connected");

	/*---connect to server---*/
	while(1){
            gets(message);

                if (strncmp("exit client", message, 12) == 0) { //exit client command
                    break;
                    }

                if (strlen(message)>0){ //if there is message
                    int send_message =send(sockfd, message, strlen(message)+1 ,0); //strlen(message)+1 for '\0'

                        memset(buffer,'\0', MAXBUF); //reset buffer
                        int receive =recv(sockfd, buffer, MAXBUF, 0);

                            puts(buffer);

                            send(sockfd, message, strlen(message) , 0); //reset receive and send
                            recv(sockfd, buffer, MAXBUF, 0);
                }
	}

	shutdown(sockfd, SD_BOTH); //shutdown the client

    /*---clean up (should never get here!)---*/
    close(sockfd);
        WSACleanup();
	return 0;
}

