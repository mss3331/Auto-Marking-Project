//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<ctype.h>
#include<string.h>
#include<time.h>
#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
		time_t rawtime;
		struct tm *info;
	char buffer[MAXBUF];
	char buffer2[MAXBUF];
	int MY_PORT = atoi(argv[1]);/*to get port number*/
	int store;
	char c[]="DATE";
	char b[]="EXIT SERVER";
	char e[]="DATE1";
	char f[]="DATE2";
	char g[]="DATE3";
	
    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	puts("start server");
	scanf("%d",&MY_PORT);
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  
	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		char *client_ip = inet_ntoa(client_addr.sin_addr);
		int clientPort = (int) ntohs(self.sin_port); //get port number
		printf("Port is: %d\n", clientPort);
		printf("IP Address is : %s\n",client_ip);
		
		while(1)
		{
		store=recv(clientfd, buffer, MAXBUF, 0);
		send(clientfd, buffer, store, 0);
		puts("Message is : ");
		printf("%s\n",strupr(buffer));
		
		printf(" Length of message is : %d\n",store);
		if(strcmp(buffer,b)==0)/*when exit server is input*/
			{
				break;
			}
		if(strcmp(buffer,c)==0)/*when date is input*/
		{
			time(&rawtime);
			info=localtime(&rawtime);
			strftime(buffer,256,"%d-%m-%y %H",info);
			send(clientfd, buffer, strlen(buffer), 0);
		}
		if(strcmp(buffer,e)==0)/*when date1 is input*/
		{
			time(&rawtime);
			info=localtime(&rawtime);
			strftime(buffer,256,"%Y",info);
			send(clientfd, buffer, strlen(buffer), 0);
		}
		if(strcmp(buffer,f)==0)/*when date2 is input*/
		{
			time(&rawtime);
			info=localtime(&rawtime);
			strftime(buffer,256,"%H",info); 
			send(clientfd, buffer, strlen(buffer), 0);
		}
		if(strcmp(buffer,g)==0)/*when date3 is input*/
		{
			time(&rawtime);
			info=localtime(&rawtime);
			strftime(buffer,256,"%d-%b-%y",info);
			send(clientfd, buffer, strlen(buffer), 0);
		}
		memset(buffer,0,strlen(buffer));/* reset buffer for next input*/
		/* to avoid a 2nd loop from happening when sending back to recv*/
		store=recv(clientfd, buffer, MAXBUF, 0);
		send(clientfd, buffer, store, 0);
		}
		memset(buffer,0,strlen(buffer));/* reset buffer for new connection*/
		/*---close connection---*/
		close(clientfd);
		puts("Client Exited\n");

	}


	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}

