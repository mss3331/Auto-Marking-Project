//////////////////////////  Server4.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include <time.h>

#define MY_PORT		8989
#define MAXBUF		256


int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	
	int portno;
	
	if (argc > 1) {
        portno = atoi(argv[1]);
    } else {
        portno = MY_PORT; 
    }
    if (portno > 0) 
        self.sin_port = htons((u_short)portno);
    else {
        fprintf(stderr,"bad port number %s\n",argv[1]);
        exit(1);
    }
	
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);	
		getsockname(clientfd, (struct sockaddr *) &client_addr, &addrlen);	
		printf("IP address: %s\n", inet_ntoa(client_addr.sin_addr));	
		printf("Port number: %d\n", ntohs(client_addr.sin_port));	
		
		while(1)
		{
			memset(buffer, '\0', sizeof(buffer));			
			recv(clientfd, buffer, MAXBUF, 0);								
			if(strcmp(buffer,"exit server")==0)								
			{															
				close(clientfd);
				break;
			}
			else if(strcmp(buffer,"date")==0)				//date = “dd-mm-yy hh” 
			{												//add carriage return and line feed
				time_t t = time(NULL);
				struct tm tm = *localtime(&t);				
				char date[100];					
				sprintf(date,"%02d-%02d-%02d %02d", tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900-2000, tm.tm_hour); 
				send(clientfd, date, 11, 0);
	
				continue;
			}
			else if(strcmp(buffer,"date1")==0)				//date1 = “yyyy”
			{
				time_t t = time(NULL);
				struct tm tm = *localtime(&t);				
				char date[100];									
				sprintf(date,"%d ",tm.tm_year + 1900);
				send(clientfd, date, 5, 0);
	
				continue;
			}
			else if(strcmp(buffer,"date2")==0)				//date2 = “hh”
			{
				time_t t = time(NULL);
				struct tm tm = *localtime(&t);				
				char date[100];										
				sprintf(date,"%02d   ",tm.tm_hour);
				send(clientfd, date, 5, 0);
	
				continue;
			}
			else if(strcmp(buffer,"date3")==0) 				//date3 = “dd-Mon-yy”
			{
				time_t t = time(NULL);
				struct tm tm = *localtime(&t);				
				char date[100], month[10];					
				int m = tm.tm_mon + 1;
				switch(m)									//switch for month in strings
				{
					case 1:
						sprintf(month,"Jan");
						break;
					case 2:
						sprintf(month,"Feb");
						break;
					case 3:
						sprintf(month,"Mar");
						break;
					case 4:
						sprintf(month,"Apr");
						break;
					case 5:
						sprintf(month,"May");
						break;
					case 6:
						sprintf(month,"Jun");
						break;
					case 7:
						sprintf(month,"Jul");
						break;
					case 8:
						sprintf(month,"Aug");
						break;
					case 9:
						sprintf(month,"Sep");
						break;
					case 10:
						sprintf(month,"Oct");
						break;
					case 11:
						sprintf(month,"Nov");
						break;
					case 12:
						sprintf(month,"Dec");
						break;
				}
				sprintf(date,"%02d-%s-%02d", tm.tm_mday, month, tm.tm_year + 1900 - 2000);
				send(clientfd, date, 9, 0);
	
				continue;
			}
			send(clientfd, strupr(buffer), MAXBUF , 0);					
			printf("String length: %d\n", strlen(buffer));							
		}
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}