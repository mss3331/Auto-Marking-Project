//////////////////////////  EchoClient.c ////////////////

#include <stdlib.h>
#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>

#define MY_PORT		8989
#define MAXBUF		256

int main(int argc , char *argv[]){

	WSADATA wsa;
    int err;
	err = WSAStartup(MAKEWORD(2,2),&wsa);
	if(err!=0)
		exit(1);
	
	SOCKET clientSocket;
	int ret;
    struct sockaddr_in serverAddr;
    char buffer[MAXBUF];

    clientSocket = socket(AF_INET, SOCK_STREAM, 0);
    if(clientSocket < 0){
        printf("Error in connection.\n");
        exit(1);
    }
    printf("Client Socket is created.\n");

    memset(&serverAddr, '\0', sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
	 
	int portno; 										//declare variable portno
	if (argc > 1) {										//if port num is specified in command line
        portno = atoi(argv[1]);							//convert the port num to binary
    } else {											//otherwise
        portno = MY_PORT;								//port num is the default MY_PORT 8989
    }
    if (portno > 0)										//if port num entered is legal value
        serverAddr.sin_port = htons((u_short)portno);	//convert port num to network byte order
    else {                          					//otherwise
        fprintf(stderr,"bad port number %s\n",argv[1]);	//print error message and exit
        exit(1);
    }
	
     serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");

    ret = connect(clientSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr));
    if(ret < 0){
         printf("Error in connection.\n");
         exit(1);
     }
     printf("Connected to Server.\n");

     while(1){
		memset(buffer, '\0', sizeof(buffer));
        printf("Client: ");
		scanf("%[^\n]%*c", &buffer);
        send(clientSocket, buffer, strlen(buffer), 0);

        if(strcmp(buffer, "exit client") == 0){			//compare buffer with terminate string
            close(clientSocket);						//if equal to terminate string, close connection
            printf("Disconnected from server.\n");
            exit(1);
        }
		
        if(recv(clientSocket, buffer, MAXBUF, 0) < 0){	//if there is error receiving data from server
            printf("Error in receiving data.\n");
			exit(1);
        }else{											//otherwise
            printf("Server: %s\n", buffer);				//print server's replies
        }
    }
	WSACleanup();
    return 0;
}