//////////////////////////  Server2.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>

#define MY_PORT		8989
#define MAXBUF		256


int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	
	int portno;
	
	if (argc > 1) {
        portno = atoi(argv[1]);
    } else {
        portno = MY_PORT; 
    }
    if (portno > 0) 
        self.sin_port = htons((u_short)portno);
    else {
        fprintf(stderr,"bad port number %s\n",argv[1]);
        exit(1);
    }
	
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);	
		getsockname(clientfd, (struct sockaddr *) &client_addr, &addrlen);	//returns current address where socket is bounded by
		printf("IP address: %s\n", inet_ntoa(client_addr.sin_addr));		//convert address to string
		printf("Port number: %d\n", ntohs(client_addr.sin_port));			//convert network byte order to host byte order
		
		while(1)
		{
			memset(buffer, '\0', sizeof(buffer));							//reset the buffer
			recv(clientfd, buffer, MAXBUF, 0);								//get the size of buffer
			if(strcmp(buffer,"exit server")==0)								//compare buffer with terminate string
			{																//if equal to terminate string
				close(clientfd);											//close connection 
				break;
			}
			send(clientfd, strupr(buffer), MAXBUF , 0);						//convert to uppercase
			printf("String length: %d\n", strlen(buffer));					//print the length of buffer
		}
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}