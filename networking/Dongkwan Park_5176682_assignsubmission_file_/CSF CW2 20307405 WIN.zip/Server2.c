//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<stdlib.h>
#include<winsock2.h>
#include<string.h>
#define MAXBUF 256

int main(int argc, char* argv[])
{
   WSADATA wsa;
   SOCKET sockfd, clientfd;
   struct sockaddr_in self;
   char buffer[MAXBUF];
   char exitserver[100]= "exit server";    //store a string in an array which also a constant pointer(used for strcmp)

   printf("\nInitialising Winsock...");
   if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
   {
      printf("Failed. Error Code : %d", WSAGetLastError());
      return 1;
   }

   printf("Initialised.\n");

   /*---create streaming socket---*/
   if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
   {
      perror("Socket");
      exit(errno);
   }

   printf("Socket created.\n");

   /*---initialize address/port structure---*/
   /* bzero(&self, sizeof(self));*/
   self.sin_family = AF_INET;
   self.sin_port = htons(atoi(argv[1]));     // Host to Network Short (16-bit)
   self.sin_addr.s_addr = INADDR_ANY;

   /*---assign a port number to the socket---*/
   if (bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0)
   {
      perror("socket--bind");
      exit(errno);
   }

   puts("Bind done");

   /*---make it a "listening socket"---*/
   if (listen(sockfd, 20) != 0)
   {
      perror("socket--listen");
      exit(errno);
   }


   puts("Waiting for incoming connections...");


   /*---forever... ---*/
   while (1)
   {
      struct sockaddr_in client_addr;
      int addrlen = sizeof(client_addr);
      char str[100]="ip address:";
        char str2[10];

      clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);

      int recieve = recv(clientfd, buffer, MAXBUF, 0);

      if((strcmp(buffer,exitserver))==0){              //exit when client type exit server
        close(sockfd);
        break;
      }


      for (int i = 0; buffer[i] != '\0'; i++) {       //changing message to uppercase

         if ((buffer[i] >= 'a') && (buffer[i] <= 'z')) {
            buffer[i] = buffer[i]-32;              //any alphabets they have difference of 32 in ascii between small letter and capital letter EX) a is 97 in ascii and A is 65.
         }

      }


      itoa(ntohs(client_addr.sin_port),str2,10);
      strcat(str,inet_ntoa(client_addr.sin_addr));
      strcat(str,"Port:");
      strcat(str,str2);
      printf("%s\n",str);


      int msg_length = send(clientfd, buffer, recieve, 0);
      printf("length of message: %d\n",recieve);            // receive is included in 'length' parameter which specify the message into bytes and character takes 1 byte so we just leave it as it is.



      /*---close connection---*/
      close(clientfd);
   }


   /*---clean up (should never get here!)---*/
   close(sockfd);
       WSACleanup();
   return 0;
}
