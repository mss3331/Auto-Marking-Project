#include <winsock2.h>
#include <string.h>
#include <stdio.h>
#include<io.h>

 
#define MAXBUF		1024
int main(int argc, char **argv)

{

     WSADATA    wsaData;
     SOCKET     SendingSocket;
     SOCKADDR_IN  ServerAddr, ThisSenderInfo;



     unsigned int Port = 7171;
     int  RetCode;
     char sendbuf[MAXBUF]={};
     char str1[]="exit client";
     int BytesSent, nlen;
     int i=0;

 


     WSAStartup(MAKEWORD(2,2), &wsaData);

     printf("Client: Winsock DLL status is %s.\n", wsaData.szSystemStatus);



     SendingSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
     if(SendingSocket == INVALID_SOCKET)

     {

          printf("Client: socket() failed! Error code: %ld\n", WSAGetLastError());
          WSACleanup();
          return -1;

     }

     else

          printf("Client: socket() is OK!\n"); 

     ServerAddr.sin_family = AF_INET;
     ServerAddr.sin_port = htons(Port);
     ServerAddr.sin_addr.s_addr = inet_addr("127.0.0.1");

 

     RetCode = connect(SendingSocket, (SOCKADDR *) &ServerAddr, sizeof(ServerAddr));

     if(RetCode != 0)

     {

          printf("Client: connect() failed! Error code: %ld\n", WSAGetLastError());
          closesocket(SendingSocket);
          WSACleanup();
          return -1;

     }

     else

     {
          printf("Client: connect() is OK, got connected...\n");
          printf("Client: Ready for sending and/or receiving data...\n");
     }

        

while (1)
{
    
    printf("Enter a command or a string: ");   
    fgets(sendbuf,MAXBUF,stdin);
    send(SendingSocket,sendbuf,(strlen(sendbuf)), 0);

    if (strncmp("exit client",sendbuf,11)==0)
    {
        exit(EXIT_SUCCESS);
        
    }
    
    if(strcmp(str1,sendbuf)!=0)
    {
    recv(SendingSocket,sendbuf,(strlen(sendbuf)), 0);
    }

    printf("Message from server: ");
    printf("%s \n",sendbuf);


}

 

     getsockname(SendingSocket, (SOCKADDR *)&ServerAddr, (int *)sizeof(ServerAddr));

     printf("Client: Receiver IP(s) used: %s\n", inet_ntoa(ServerAddr.sin_addr));

     printf("Client: Receiver port used: %d\n", htons(ServerAddr.sin_port));

 


     BytesSent = send(SendingSocket, sendbuf, strlen(sendbuf), 0);

 

     if(BytesSent == SOCKET_ERROR)

          printf("Client: send() error %ld.\n", WSAGetLastError());

     else

     {

          printf("Client: send() is OK - bytes sent: %ld\n", BytesSent);

          memset(&ThisSenderInfo, 0, sizeof(ThisSenderInfo));

          nlen = sizeof(ThisSenderInfo);

 

          getsockname(SendingSocket, (SOCKADDR *)&ThisSenderInfo, &nlen);

     }

 

     if( shutdown(SendingSocket, SD_SEND) != 0)

          printf("Client: Well, there is something wrong with the shutdown(). The error code: %ld\n", WSAGetLastError());

     else

          printf("Client: shutdown() looks OK...\n");

     // When you are finished sending and receiving data on socket SendingSocket,

     // you should close the socket using the closesocket API. We will

     // describe socket closure later in the chapter.

     if(closesocket(SendingSocket) != 0)

          printf("Client: Cannot close \"SendingSocket\" socket. Error code: %ld\n", WSAGetLastError());

     else

          printf("Client: Closing \"SendingSocket\" socket...\n");

 

     // When your application is finished handling the connection, call WSACleanup.

     if(WSACleanup() != 0)

          printf("Client: WSACleanup() failed!...\n");

     else

          printf("Client: WSACleanup() is OK...\n");

     return 0;

}

 