#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include <string.h>
#include <ctype.h>

#define MAXBUF		256

int main(int argc, char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd;
    struct sockaddr_in self;
    char buffer[MAXBUF];

    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
    {
        perror("Socket");
        exit(errno);
    }
    printf("Socket created.\n");

    self.sin_family = AF_INET;
	self.sin_port = htons(atoi(argv[1]));	  // this is the port number the client targets, it should be the same as the server's port number. 
                                              // for instance when we type 'start Server3 8989' in the terminal to start the server, then we should type 'start EchoClient 8989' 
                                              // in the terminal to start the EchoClient for it to connect to the same port number as the server.
	self.sin_addr.s_addr = inet_addr("127.0.0.1");  //localhost

    if (connect(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
        puts("Failed to connect to server");
		exit(errno);
	}

    while (1)
	{	
        printf("Enter message to send: "); 
        fgets(buffer, 256, stdin); // take in input
        if (strncmp(buffer, "exit client", 11) == 0 && strlen(buffer) == 12){ // check if buffer is exactly "exit client"
            break; // if yes, end the loop
        }
        // if not exit client, send message to server
        send(sockfd, buffer, strlen(buffer)-1, 0); // minus 1 because fgets reads newline too
		int recv_size = recv(sockfd, buffer, MAXBUF, 0); // receive message from server as well as the message length
        char * newBuffer = malloc(recv_size+1); // set up string to display the incoming buffer based on size of message
        strncpy(newBuffer, buffer, recv_size);
        newBuffer[recv_size] = '\0';
        printf("%s", newBuffer); // print message from server
    }
	
	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;	


}