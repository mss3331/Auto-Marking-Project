//////////////////////////  Server3.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include <string.h>
#include <ctype.h>
#include <time.h>

#define MAXBUF		256

int main(int argc, char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];

	// set up the way we will retrieve the details of our current time
	time_t timeNow;
	struct tm *timeDetails;
	time(&timeNow);
	timeDetails = localtime(&timeNow);

	srand(time(NULL)); // set up number randomizer

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(atoi(argv[1]));	  // Host to Network Short (16-bit); // atoi changes the string argument from the command line to integer to be used as port number
	self.sin_addr.s_addr = INADDR_ANY;  


	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 ) 
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");
	/*---accept a connection (creating a data pipe)---*/
	struct sockaddr_in client_addr;
	int addrlen=sizeof(client_addr);
	clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);

	/*---forever... ---*/
	while (1)
	{	
		int recv_size = recv(clientfd, buffer, MAXBUF, 0);		

		// generate a makeshift randomized client ip address
		char *clientip = malloc(15);
		char *startNumString = malloc(3);
		sprintf(startNumString, "%d", rand()%256);
		strcpy(clientip, startNumString);

		for (int i = 0; i<3; i++){
			strcat(clientip, ".");
			char *numString = malloc(3);
			sprintf(numString, "%d", rand()%256);
			strcat(clientip, numString);
		}
		
		// generate a makeshift randomized server port number targeted by client
		int serverport = 1+rand()%65535;

		if (recv_size <= 0){ // nothing was sent
			break;
		}
		if (recv_size == 2){ // deal with the extra \n\r
			if (isspace(buffer[0]) != 0 && isspace(buffer[1]) != 0){
				continue;
			}	

		}
		if(strncmp(buffer, "exit server", 11) == 0 && recv_size == 11){ // check if received message was exactly 'exit server'. if yes, break, if not, proceed with usual function
			break;
		}
		else{
			printf("\n\nA new connection has arrived!\n");
			printf("\nClient IP Address is: %s\n", clientip); // print randomized ip
			printf("\nPort number targeted by client request is: %d\n", serverport); // print randomized port
			printf("\nMessage length is: %d\n", recv_size);

			if (strncmp(buffer, "date", recv_size) == 0 && recv_size == 4){ // check if input received is "date"
				char * dateTime = malloc(14); // set up string for date and carriage return and line feed
				sprintf(dateTime, "%d-%d-%d %d%c%c",timeDetails->tm_mday,timeDetails->tm_mon+1, timeDetails->tm_year-100, timeDetails->tm_hour, 13, 10); // set up string to be of format “dd-mm-yy hh”
				send(clientfd, dateTime, strlen(dateTime), 0); // send to client
				continue;
			}

			char * newBuffer = malloc(recv_size+2); // set up string to send for usual input
			strncpy(newBuffer, buffer, recv_size);
			newBuffer[recv_size] = '\0'; 
			for (int i=0; i<recv_size; i++){ // make string uppercase
				newBuffer[i] = toupper(newBuffer[i]);
			}
			strcat(newBuffer, "\n\r");	// add carriage return and linefeed to string to send out
			send(clientfd, newBuffer, recv_size+2, 0); // send to client	
		}

	}
	close(clientfd);

	

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}

