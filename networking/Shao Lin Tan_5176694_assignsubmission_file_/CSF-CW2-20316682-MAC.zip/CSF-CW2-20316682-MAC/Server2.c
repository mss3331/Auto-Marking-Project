#include <stdio.h>
#include <netdb.h>
#include <netinet/in.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <ctype.h>
#define MAX 80
#define SA struct sockaddr

void func(int sockfd);

// Driver function
int main()
{
    int sockfd, connfd,port;
    unsigned int * len;
    struct sockaddr_in servaddr, cli;
    
    // socket create and verification
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1) {
        printf("socket creation failed...\n");
        exit(0);
    }
    else
        printf("Socket successfully created..\n");
    bzero(&servaddr, sizeof(servaddr));

    //input port number
    printf("Networking 1>start server ");
    scanf("%d",&port);
    
    fflush(stdin);
    
    // assign IP, PORT
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(port);

    // Binding newly created socket to given IP and verification
    if ((bind(sockfd, (SA*)&servaddr, sizeof(servaddr))) != 0) {
        printf("socket bind failed...\n");
        exit(0);
    }
    else
        printf("Socket successfully binded..\n");

    // Now server is ready to listen and verification
    if ((listen(sockfd, 2)) != 0) {
        printf("Listen failed...\n");
        exit(0);
    }
    else
        printf("Server listening..\n");
        
    unsigned int a = (sizeof(cli));
    len = &a;

    // Accept the data packet from client and verification
    while((connfd = accept(sockfd, (SA*)&cli, len))){
        
        if (connfd < 0) {
            printf("server accept failed...\n");
            exit(0);
        }
        
        printf("server accept the client...\n");
        //get IP and port number and print
        socklen_t clientsz = sizeof(cli);
        printf("IP: %s\n", inet_ntoa(cli.sin_addr));
        getsockname(sockfd, (struct sockaddr *) &cli, &clientsz);
        printf("Port: %u\n", ntohs(cli.sin_port));
        
        // Function for chatting between client and server
        func(connfd);
    }
    // After chatting close the socket
    close(sockfd);
}

// Function designed for chat between client and server.
void func(int sockfd)
{
    char buff[MAX];
    char buff2[MAX];
    int n;
    // infinite loop for chat
    for (;;) {
        bzero(buff, MAX);

        // read the message from client and copy it in buffer
        read(sockfd, buff, sizeof(buff));
        
        for (int i=0; buff[i]!=0; i++) {
            buff2[i]=buff[i]; //store original message
            buff[i]=toupper(buff[i]); //convert message to uppercase
        }
        // print buffer which contains the client contents
        printf("From client: %s", buff);
        printf("length:%lu\n",strlen(buff)-1);
        //if msg contains "client exited" then server exit and chat ended
        if (strncmp("Client exited",buff2, 13) == 0) {
            break;
        }
        //if msg contains "exit server" then server terminate and chat ended
        if (strncmp("exit server",buff2, 11) == 0) {
            printf("Server Exit...\n");
            write(sockfd, "Server terminated\n", sizeof(buff));
            exit(0);
        }
        
        printf("\tTo Client:");
        bzero(buff, MAX);
        n = 0;
        // copy server message in the buffer
        while ((buff[n++] = getchar()) != '\n')
            ;

        // and send that buffer to client
        write(sockfd, buff, sizeof(buff));
        
    }
}
