#include<stdio.h>
#include<winsock2.h>
#include<io.h>
#include<string.h>
#include<windows.h>
#include<time.h>

#define MY_PORT		8989
#define MAXBUF		256


int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];
	int charAmount, i, myPort;
	
	for (i=0; i<argc; i++){
		myPort=atoi(argv[i]); // Converts string from argv[i] to integers
		if (myPort*1!=0){ // When input is an integer, break
			break;
		}
	}

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(myPort);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	struct tm *ptr;
	time_t t;

	t=time(NULL);
	ptr = localtime(&t);

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);

		printf("\nIP address of the client: %s\n", inet_ntoa(client_addr.sin_addr));
        printf("Port number targeted by the client's request: %d\n\n", myPort);
		
        while (1){
			
            memset(buffer, 0 , MAXBUF);
            int recv_size= recv(clientfd, buffer, MAXBUF, 0);
            if ( strcmp(buffer, "exit server")==0 ){ // If buffer is equal to "exit server"
				break; // Break out of while loop aand terminate
			}
			else if ( strcmp(buffer, "date")==0 ){ // If buffer is equal to "date"
				strftime(buffer, 100, "%d-%m-%y %H\r\n", ptr); // Store the date in format, "dd-mm-yy hh" into buffer
				send(clientfd, buffer, sizeof(buffer) , 0); // Send the date to client
				continue; // Continue the loop, continue accepting messages from client
			}
            else if ( recv_size>0 ){
		        strupr(buffer); // makes all the letters into upper case
				puts(buffer); // Prints out tthe all caps message in the server
                if (buffer[0]!='\r'){
                    charAmount=strlen(buffer); // gets message length 
                    printf("The length of the message is: %d\n\n", charAmount);
                }
                send(clientfd, buffer, recv_size , 0); // Sends the all caps message to client
            }
            else{
                break;
            }
        }

		/*---close connection---*/
		close(clientfd);
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}

// cd "C:\Users\Qayyum Indra Putera\OneDrive\Desktop\UNM\Computer Science\Year 1\Computer Fundementals\Lab Computer Fundementals\Coursework 2"
// gcc Server3.c -o Server3 -lws2_32