//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<ctype.h>
#include<windows.h>
#include<time.h>


#define MAXBUF		256

// Define a structure for each client
struct client {
	int index;
	SOCKET clientfd;
	char ip[20];
	int port;
};

// An array of client (max 20)
struct client Client[20];

int MY_PORT;

// This function will be used for multithread purpose (not necessary for this coursework but good practice)
int networking(struct client* ClientDetail);

// Helper function - to convert the string into uppercase
char* strupr(char* buffer);

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    struct sockaddr_in self;

	// This reads the port number from using using the Command Line Argument and concert the string to integer
	if (argc == 2)
	{
		MY_PORT = atoi(argv[1]);
	}
	else {
		printf("Usage: ./Server3.exe [port]\n");
		return 1;
	}

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

		int clientCount = 0;

	/*---forever... ---*/
	while (1) 
	{
		struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);

		// Create a client object in the array
		Client[clientCount].index = clientCount;
		Client[clientCount].clientfd = clientfd;
		strcpy(Client[clientCount].ip, inet_ntoa(client_addr.sin_addr));
		Client[clientCount].port = client_addr.sin_port;

		// Multithread starts
		DWORD ThreadId;
		HANDLE ThreadHandle;

		ThreadHandle = CreateThread(NULL, /* default security attributes */ 0, /* default stack size */
			networking, /* thread function */ &Client[clientCount], /* parameter to thread function */ 0, /* default creation    flags */ &ThreadId);
		/* returns the thread identifier */

		// Move to the next client
		clientCount++;
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}


int networking(struct client* ClientDetail) 
{
	// The buffer (data container) for the communication, necessary
	char buffer[MAXBUF];

	// Initialize some variables for the ease of access
	struct client* clientDetail = ClientDetail;
	int index = clientDetail->index;
	SOCKET clientSocket = clientDetail->clientfd;
	char *	clientIP = clientDetail->ip;
	int clientPort = clientDetail->port;

	printf("\nClient %d Connected.\nIP: %s\nClient Port: %d\nServer Port: %d\n\n", index + 1, clientIP, clientPort, MY_PORT);

	while (1)
	{
		// Recieve the message sent from the client
		int length = recv(clientSocket, buffer, MAXBUF, 0);\
		// Add a null terminator to make the message a complete string. This is useful for comparison
		buffer[length] = '\0';

		if (length <= 0) {
			return 0;
		}

		/*---close connection---*/
		if (strcmp(buffer, "exit server") == 0) {
			close(clientSocket);
			return 0;
		}

		// Check for commands keywoard
		if (strcmp(buffer, "date") == 0) {
			// Use the time and localtime function in the time.h library
			time_t t = time(NULL);
			struct tm tm = *localtime(&t);
			sprintf(buffer, "%02d-%02d-%02d %02d", tm.tm_mday, tm.tm_mon + 1, (tm.tm_year + 1900) - 2000, tm.tm_hour);
			send(clientSocket, strupr(buffer), strlen(buffer), 0);
			continue;
		}

		// This is to avoid junk values
		if (buffer[0] == 13 && buffer[1] == 10) {
			send(clientSocket, strupr(buffer), length, 0);
			continue;
		}

		// Send the uppercased message to the client
		if (send(clientSocket, strupr(buffer), length, 0)) {
			printf("%s\n", strupr(buffer));
			printf("Length of message: %d\n\n", length);
		}
	}
}

// Helpfer function
char* strupr(char* buffer) {
	for (int i = 0; i < strlen(buffer); i++) {
		buffer[i] = toupper(buffer[i]);
	}
	return buffer;
}