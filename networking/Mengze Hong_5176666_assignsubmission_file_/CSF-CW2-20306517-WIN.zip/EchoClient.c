/******************* CLIENT CODE *****************/

#include <stdio.h>
#include <winsock2.h>
#include <io.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>

int main(int argc, char*argv[]) 
{
    // Read the port number from user
    int MY_PORT;

    if (argc == 2) 
    {
        MY_PORT = atoi(argv[1]);
    }
    else {
        printf("Usage: ./EchoClient.exe [port]\n");
        return 1;
    }

    WSADATA wsa;
    int err;
    err = WSAStartup(MAKEWORD(2, 2), &wsa);
    if (err != 0) 
    {
        return 1;
    }

    SOCKET s;
    s = socket(AF_INET, SOCK_STREAM, 0);
    if (s == INVALID_SOCKET) 
    {
        printf("Error code : % d\n", WSAGetLastError());
        return 1;
    }

    // Information for the server
    struct sockaddr_in server;
    server.sin_family = AF_INET;
    server.sin_port = htons(MY_PORT); // Big Endean
    server.sin_addr.s_addr = inet_addr("127.0.0.1"); //IP

    // Similar to server code but without the bind and listen process
    connect(s, (struct sockaddr*)&server, sizeof(server));
    char message[256];

    while(1) 
    {
        printf("\n");
        printf("Enter a message: ");
        gets(message);

        if (strcmp(message, "exit client") == 0) {
            printf("Exit Client\n");
            break;
        }

        if (send(s, message, strlen(message), 0) < 0) {
            printf("Error\n");
        }

        char Server_Reply[256];

        int len = recv(s, Server_Reply, 256, 0);

        if (len < 0) {
            printf("Server terminated\n");
            return 0;
        }

        // Add a null terminator to the message string
        Server_Reply[len] = '\0';
        
        printf("\nReply: %s\n", Server_Reply);
    }

    close(s);
    WSACleanup();

    return 0;
}