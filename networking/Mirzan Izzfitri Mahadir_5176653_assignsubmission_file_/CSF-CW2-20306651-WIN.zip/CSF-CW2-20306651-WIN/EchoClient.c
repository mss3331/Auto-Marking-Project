////////////////EchoClient.c///////////////

#include<io.h>
#include<stdio.h>
#include<string.h>
#include<winsock2.h>
#define MYPORT 		8989
#define MAXBUF		256
#define MAXREP		256
int main(int argc , char *argv[])
{
	char buffer[MAXBUF];
	char reply[MAXREP];
	WSADATA wsa;
	SOCKET sockfd, clientd;
		struct sockaddr_in client;
	
	 printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");
		
	if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket cannot be created");
		exit(errno);
	}

        printf("Socket created.\n");
		
	client.sin_family = AF_INET;
	client.sin_port = htons( 8989 );	  // Host to Network Short (16-bit)
	client.sin_addr.s_addr = inet_addr("127.0.0.1");
	
	if ( connect(sockfd, (struct sockaddr*)&client, sizeof(client)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");
		
	while (1)
	{	memset(&reply, 0, sizeof(buffer) );
        printf("Enter message : ");
        scanf("%s" , buffer);

        //Send some data
        if( send(sockfd , buffer , strlen(buffer) , 0) == 0)
        {
            puts("Send failed");
            return 1;
        }

        //Receive a reply from the server
        if( recv(sockfd , buffer , 2000 , 0) == 0)
        {
            puts("recv failed");
            break;
        }	

        puts("Server reply :");
        puts(buffer);
	}
	
	close(sockfd);
	return 0;
}