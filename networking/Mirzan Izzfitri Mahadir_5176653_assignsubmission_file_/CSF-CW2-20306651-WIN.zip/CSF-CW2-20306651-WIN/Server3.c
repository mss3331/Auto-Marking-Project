//////////////////////////  Server3.c ////////////////

#include<io.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<winsock2.h>
#include <time.h>

#define MAXBUF		256

int main(int argc , char *argv[])
{

	int upper;
	int MYPORT;
	
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];
	
	printf("Networking 1 ->start server "); // display the message to get port number
	scanf("%d", &MYPORT); // scan the port number 
	
    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MYPORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = inet_addr("127.0.0.1"); //IP Address

	
	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");
	

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
       
        puts("Waiting for incoming connections...");
		
	printf("The address is %s\n", inet_ntoa(self.sin_addr)); //Print IP Address	
	printf("The port number is: %d\n", MYPORT); //Print Port Number 	

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);
		int hour, day, month, year;
		time_t date;
		time(&date);
		
		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		
		
		send(clientfd, strupr(buffer), recv(clientfd, buffer, MAXBUF, 0), 0); //strupr is use so that the message send back be uppercase
		
		if (strncmp(buffer, "exitserver",10)== 0){
			close(clientfd);
			break;
		}
		
		if (strncmp("date", buffer, 4)== 0){
			gets(ctime(&date));
			
			struct tm *local = localtime(&date);
			
			hour = local->tm_hour;
			day = local->tm_mday;
			month = local->tm_mon + 1;
			year = local->tm_year =1990;
			
		}
		printf("%02d-%02d-%02d %d\n", day, month, year, hour);
		
		printf("The message length is %d \n", strlen(buffer));
		

		/*---close connection---*/
		close(clientfd);
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}

