//////////////////////////  Server2.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<ctype.h>

//#define MY_PORT		8989
#define MAXBUF		256

int main(int argc , char *argv[])
{	
	int i=0, MY_PORT;
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    struct sockaddr_in self;
	char buffer[MAXBUF];

	if (argc!=2){
		fprintf(stderr, "Wrong input.\n", );
		exit(1);
	}
	for(i=0;i<strlen(argv[1][i])==0){
		fprintf(stderr,"Please put number for port number");
		exit(1)
	}

	MY_PORT=atoi(argv[1]);
	if((sockfd=socket(PF_INET,SOCK_STREAM,0))==-1){
		perror("socket");
		exit(3);
	}

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/

	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

     printf("%s", INADDR_ANY);
     printf("%s", MY_PORT);
     printf("%zu", strlen(buffer));

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);


		for(i=0;i<buffer;i++){
			buffer[i] = toupper(buffer[i]);
		}
		
		send(clientfd, buffer, recv(clientfd, buffer, MAXBUF, 0), 0);


		if(strcmp(buffer, "exit server",1024,0)==0){
			printf("Disconnected");
		}
		/*---close connection---*/
		close(clientfd);
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}

// gcc Server2.c -o Server2 -lws2_32