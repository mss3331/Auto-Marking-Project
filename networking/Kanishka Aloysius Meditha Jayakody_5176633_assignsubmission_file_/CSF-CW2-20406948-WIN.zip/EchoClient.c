#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<ctype.h>
#include<string.h>

#define MY_PORT		8989
#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in server;
	char buffer[MAXBUF];
	char Server_Reply[MAXBUF];// buffer for server to reply 
    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");
	if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 ) // if scoket cretion then returns socket descriptor else error
		{
			perror("Socket");
			exit(errno);
		}

			printf("Socket created.\n");

		/*---initialize address/port structure---*/
		/* bzero(&self, sizeof(self));*/
		server.sin_family = AF_INET; // addressng family
		server.sin_port = htons(8989); // port number
		server.sin_addr.s_addr = inet_addr("127.0.0.1"); // address of the server	
		connect(sockfd, (struct sockaddr*)&server, sizeof(server));//connect to the server
			puts("Connected");	
	while(1){
		memset(buffer, 0, sizeof(buffer));//reset buffer
		memset(Server_Reply, 0, sizeof(Server_Reply));//reset server reply buffer
	    printf("Enter message : ");
		gets(buffer);//client response
		//test for if "exit client" is entered
		if(strcmp(buffer, "exit client")==0){
	    close(sockfd);// if client types EXIT then close client connection
	    WSACleanup();
		}
		//Send data
		if( send(sockfd , buffer , strlen(buffer) , 0) < 0)
		{
			puts("Send failed");
			return 1;
		}
		
		//Receive a reply from the server
		if (strlen(buffer)!=0){
		if( recv(sockfd , Server_Reply , MAXBUF , 0) < 0)
		{
			puts("recv failed");
			break;
		}
		printf("server reply  : ");
		puts(Server_Reply);//server reply
		}
		else{
			printf("server reply  : \n");
		}
	}
			close(clientfd);
	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}