//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<time.h>

#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    struct sockaddr_in self;
	char buffer[MAXBUF]="";
	char exitprog[MAXBUF]= "exit server";
    char date[MAXBUF];// bascially a buffer for date
	int port;

	port=atoi(argv[3]);	

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(port);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");
		int MessageNumber=1;// intialsiing the message number
	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);
		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		printf("IP: %s\n",inet_ntoa(client_addr.sin_addr));//print IP address
		printf("Port: %d\n",port);// print Port number
		
		while(1)
		{
			memset(buffer,'\0', MAXBUF);//reset buffer
			int bufferlen = recv(clientfd, buffer, MAXBUF, 0); //length of buffer
			if(bufferlen > 0)//checks if what the server received contains atleast 1 character 
			{
				if(strcmp(buffer,exitprog)!=0) //case to avoid user pressing enter key
				{
                    if (strcmp(buffer,"date")==0){// checks if client types date so it will show date
				    time_t Current_time = time(NULL);
				    struct tm *tm = localtime(&Current_time);//time
				    strftime(buffer, sizeof(buffer), "%d-%m-%y %H\r\n", tm);
				    send(clientfd,buffer, strlen(buffer), 0);// send date to the client
                    continue;
                    }
                    if (strcmp(buffer,"date1")==0){// checks if client types date so it will show date
				    time_t Current_time = time(NULL);
				    struct tm *tm = localtime(&Current_time);//time
				    strftime(buffer, sizeof(buffer), "%Y\r\n", tm);
				    send(clientfd,buffer, strlen(buffer), 0);// send date to the client
                    continue;
                    }
                    if (strcmp(buffer,"date2")==0){// checks if client types date so it will show date
				    time_t Current_time = time(NULL);
				    struct tm *tm = localtime(&Current_time);//time
				    strftime(buffer, sizeof(buffer), "%H\r\n", tm);
				    send(clientfd,buffer, strlen(buffer), 0);// send date to the client
                    continue;
                    }
                    if (strcmp(buffer,"date3")==0){// checks if client types date so it will show date
				    time_t Current_time = time(NULL);
				    struct tm *tm = localtime(&Current_time);//time
				    strftime(buffer, sizeof(buffer), "%d-%b-%y\r\n", tm);
				    send(clientfd,buffer, strlen(buffer), 0);// send date to the client
                    continue;
                    }
                    if(buffer[0]!= '\r'){
					    printf("The length of Message %d : %d\n",MessageNumber,bufferlen);
                        printf("Your message output %s\n",strupr(buffer));
						MessageNumber++;
					}
				strupr(buffer);// capitalise the client response
				send(clientfd, buffer, bufferlen, 0);//send updated buffer
				}
				else{
					break;
				}
			}
			else{
				break;
			}
		}
		
		/*---close connection---*/
		close(clientfd);//close client connection	
		return 0;
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}

