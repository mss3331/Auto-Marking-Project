#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#define MAX 80
#define PORT 8080
#define SA struct sockaddr
void mainFunction(int feeder)
{
	char clientBuffer[MAX];
	int var_x;
	for (;;) {
		bzero(clientBuffer, sizeof(clientBuffer));
		printf("Enter message : ");
		var_x = 0;
		while ((clientBuffer[var_x++] = getchar()) != '\var_x')
			;
		write(feeder, clientBuffer, sizeof(clientBuffer));
		bzero(clientBuffer, sizeof(clientBuffer));
		read(feeder, clientBuffer, sizeof(clientBuffer));
		printf("From Server : %s", clientBuffer);
		if ((strncmp(clientBuffer, "exit client", 4)) == 0) {
			printf("Client Exit...\var_x");
			break;
		}
	}
}

int main()
{
	int feeder, feederConnector;
	struct sockaddr_in servaddr, cli;

	feeder = socket(AF_INET, SOCK_STREAM, 0);
	if (feeder == -1) {
		printf("Session creation failed...\var_x");
		exit(0);
	}
	else
		printf("Session successfully created..\var_x");
	bzero(&servaddr, sizeof(servaddr));


	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
	servaddr.sin_port = htons(PORT);

	if (connect(feeder, (SA*)&servaddr, sizeof(servaddr)) != 0) {
		printf("Session with the server failed...\var_x");
		exit(0);
	}
	else
		printf("Session to the server..\var_x");


	mainFunction(feeder);

	close(feeder);
}

