//////////////////////////  Server4.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<time.h>


#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];
	int port_num;
	
	char* x = argv[1];	//first command line argument
	port_num = atoi(x);	//converts string into integer
	

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(port_num);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");
		

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);
		

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		
		printf("IP Address is: %s\n", inet_ntoa(client_addr.sin_addr));
		printf("Port number is %d\n", (int)ntohs(client_addr.sin_port));

		while(1){
		int recv_size = recv(clientfd, buffer, MAXBUF, 0);
		
		
		if(strcmp(buffer, "exit server") == 0)
			break;
		
		
		if(strcmp(buffer, "date") == 0)
		{
			time_t rawtime;
			struct tm *info;
			char buffer[99];
			
			time(&rawtime);
			
			info = localtime(&rawtime);
		
			strftime(buffer, 99, "%d-%m-%y %H\r\n", info);
			send(clientfd, buffer, strlen(buffer), 0);
			
			memset(buffer, '\0', strlen(buffer));	//terminate the content of the buffer 
			recv_size = recv(clientfd, buffer, MAXBUF, 0);
			send(clientfd, buffer, recv_size, 0);
			continue;
		}
		
		if(strcmp(buffer, "date1") == 0)
		{
			time_t rawtime;
			struct tm *info;
			char buffer[99];
				
			time(&rawtime);
			
			info = localtime(&rawtime);
		
			strftime(buffer, 99, "%Y\r\n", info);
			send(clientfd, buffer, strlen(buffer), 0);
			
			memset(buffer, '\0', strlen(buffer));	//terminate the content of the buffer 
			recv_size = recv(clientfd, buffer, MAXBUF, 0);
			send(clientfd, buffer, recv_size, 0);
			continue;
		}
		
		if(strcmp(buffer, "date2") == 0)
		{
			time_t rawtime;
			struct tm *info;
			char buffer[99];
			
			time(&rawtime);
			
			info = localtime(&rawtime);
		
			strftime(buffer, 99, "%H\r\n", info);
			send(clientfd, buffer, strlen(buffer), 0);
			
			memset(buffer, '\0', strlen(buffer));	//terminate the content of the buffer 
			recv_size = recv(clientfd, buffer, MAXBUF, 0);
			send(clientfd, buffer, recv_size, 0);
			continue;
		}
		
		if(strcmp(buffer, "date3") == 0)
		{
			time_t rawtime;
			struct tm *info;
			char buffer[99];
			
			time(&rawtime);
				
			info = localtime(&rawtime);
		
			strftime(buffer, 99, "%d-%b-%y\r\n", info);
			send(clientfd, buffer, strlen(buffer), 0);
			
			memset(buffer, '\0', strlen(buffer));	//terminate the content of the buffer 
			recv_size = recv(clientfd, buffer, MAXBUF, 0);
			send(clientfd, buffer, recv_size, 0);
			continue;
		}
		
		
		
		strupr(buffer);		//uses strupr function to make the content of the buffer uppercase
		
		send(clientfd, buffer, recv_size, 0);
		
		printf("%s\n", buffer);
		
		
		printf("String length is %d\n", recv_size);	//recv_size or recv()function returns length of message sent in bytes
		
		memset(buffer, '\0', strlen(buffer));	//terminate the content of the buffer 
		recv_size = recv(clientfd, buffer, MAXBUF, 0);
		send(clientfd, buffer, recv_size, 0);
		}
		

		/*---close connection---*/
		close(clientfd);
		printf("Client terminated, goodbye!\n");
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}