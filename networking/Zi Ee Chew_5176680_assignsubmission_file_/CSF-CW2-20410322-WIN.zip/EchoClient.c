//////////////////////////  EchoClient.c ////////////////
#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<time.h>

#define MAXBUF		256

int main(int argc, char* argv[]){

  WSADATA wsa;
  SOCKET sock;
  struct sockaddr_in SockAddr;
  int port_num;
  
  char* x = argv[1];	//first command line argument
	port_num = atoi(x);	//converts string into integer
  
  printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
  
  /*---create streaming socket---*/
    if ( (sock = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}
	
	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	SockAddr.sin_family = AF_INET;
	SockAddr.sin_port = htons(port_num);
	SockAddr.sin_addr.s_addr = inet_addr("127.0.0.1");  
	
	/*---establish an active connection---*/
	connect(sock, (struct sockaddr *)&SockAddr, sizeof(SockAddr));	//sock : Socket
	
	while(1){
	/*---initiate transmission of a message---*/
	char message[MAXBUF];
	char Server_Reply[MAXBUF];
	puts("\nEnter message: ");
	gets(message);
	
	if(strcmp(message, "exit client") == 0){ 	
		break;		//break out of while loop and close the socket when exit client is read
	}
	
	
	if(send(sock, message, strlen(message), 0) < 0){
		perror("send-failed");
		exit(errno);
	}
	
	/*---receiving back---*/
	
	if(recv(sock, Server_Reply, MAXBUF, 0) < 0){
		perror("receive-failed");
		exit(errno);
	}
	else{
		printf("\nServer: %s\n", Server_Reply);
	}
	
	
	memset(message, ' ', strlen(message));	//clear the buffer for the next loop
	if(send(sock, message, strlen(message), 0) < 0){
		perror("send-failed");
		exit(errno);
	}
	
	if(recv(sock, Server_Reply, MAXBUF, 0) < 0){
		perror("receive-failed");
		exit(errno);
	}
	
	
	
	}
	
	/*---close and clean up---*/
	close(sock);
	printf("Client terminated");
	
	WSACleanup();
	
  

  return 0;

}