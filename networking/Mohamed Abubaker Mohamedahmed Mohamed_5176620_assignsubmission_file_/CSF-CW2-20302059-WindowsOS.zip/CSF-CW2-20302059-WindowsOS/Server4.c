#include <io.h>
#include <stdio.h>
#include <winsock2.h>
#include <ctype.h>
#include <string.h>
#include <time.h>
#include <windows.h>

#define MY_PORT 8989
#define MAX 256
#define Size 12
int main(int argc, char *argv[])
{
    WSADATA wsa;
    SOCKET sockserver, clientSocket;
    struct sockaddr_in self;
    char message[MAX];
    int i, j, temp;
    int nomOfBytes, a;
    struct timeStruct *inforamtion;
    char currTime[Size];
    time_t rawtime;
    int counter = 0;
    int tm_year;

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
    {
        printf("Failed. Error Code : %d", WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

    if ((sockserver = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror("Socket");
        exit(errno);
    }

    printf("Socket created.\n");

    self.sin_family = AF_INET;
    self.sin_port = htons(MY_PORT); // Host to Network Short (16-bit)
    self.sin_addr.s_addr = INADDR_ANY;

    if (bind(sockserver, (struct sockaddr *)&self, sizeof(self)) != 0)
    {
        perror("socket--bind");
        exit(errno);
    }
    puts("Bind done");
    if (listen(sockserver, 20) != 0)
    {
        perror("socket--listen");
        exit(errno);
    }
    puts("Waiting for incoming connections...");
    while (1)
    {
        struct sockaddr_in client_addr;
        int addrlen = sizeof(client_addr);
        clientSocket = accept(sockserver, (struct sockaddr *)&client_addr, &addrlen);
        char *ip = inet_ntoa(client_addr.sin_addr);
        while (1)
        {
            time_t t;
            char *p;
            int lengtrh;
            struct timeStruct *inforamtion;
            memset(message, 0, sizeof(message));
            nomOfBytes = recv(clientSocket, message, MAX, 0);
            counter = 0;
            if (strncmp(message, "TIME", 4) == 0)
            {
                time(&rawtime);
                inforamtion = localtime(&rawtime);
                if (strcmp(message, "DATE") == 0)
                    inforamtion = strftime(currTime, sizeof(currTime), "%d-%m-%y %I", rawtime);
                else if (strcmp(message, "DATE 1") == 0)
                {
                    inforamtion = strftime(currTime, sizeof(currTime), "%y", rawtime);
                }
                else if (strcmp(message, "DATE 2") == 0)
                {
                    inforamtion->timeStructYear + 1900;
                }
                else if (strcmp(message, "DATE 3") == 0)
                {
                    inforamtion = strftime(currTime, sizeof(currTime), "%d-%b-%y", rawtime);
                }
                else
                {
                    counter++;
                }
                if (counter == 0)
                {
                    p = asctime(inforamtion);
                    lengtrh = strlen(p);
                    send(clientSocket, p, lengtrh, 0);
                    if (strcmp(message, "exit server") == 0)
                    {
                        close(clientSocket);
                        printf("You got disconnected from server.\n");
                        exit(1);
                    }
                }
                else
                    send(clientSocket, "ERROR", 5, 0);
            }
            else
            {
                int length = strlen(message) - 1;
                if (message[0] != '\r' && message[0] != '\n')
                {
                    printf("\nIP address of the client : %s", ip);
                    printf("\nPort number: %d ", client_addr.sin_port);
                    printf("\nlength of the message was: %d\n", nomOfBytes);
                    for (i = 0; i < nomOfBytes; i++)
                    {
                        if (message[i] != '\n')
                            message[i] = toupper(message[i]);
                    }
                }
                send(clientSocket, message, nomOfBytes, 0);
            }
            memset(message, 0, nomOfBytes);
        }

        close(clientSocket);
    }
    close(sockserver);
    WSACleanup();

    return 0;
}
