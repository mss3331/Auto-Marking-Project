//////////////////////////  Server.c ////////////////

#include <io.h>
#include <stdio.h>
#include <winsock2.h>
#include <ctype.h>
#include <string.h>

#define MAX 256

int main(int argc, char *argv[])
{
	WSADATA wsa;
	SOCKET sockServer, clientSocket; //socket for the client and the server
	struct sockaddr_in self;
	char message[MAX];
	int i, j, temp;
	int numbytes;

	printf("\nInitialising Winsock...");
	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
	{
		printf("Failed. Error Code : %d", WSAGetLastError());
		return 1;
	}

	printf("Initialised.\n");

	//create streaming socket
	if ((sockServer = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		perror("Socket");
		exit(errno);
	}

	printf("Socket created.\n");

	//initialize address/port structure'
	int MY_PORT = atoi(argv[3]);
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT); // Host to Network Short
	self.sin_addr.s_addr = INADDR_ANY;

	// task 1 assign a port number to the socket
	if (bind(sockServer, (struct sockaddr *)&self, sizeof(self)) != 0)
	{
		perror("socket--bind");
		exit(errno);
	}

	puts("Bind done"); //to bind between the server and the port

	//make it a "listening socket"
	if (listen(sockServer, 20) != 0)
	{
		perror("socket--listen");
		exit(errno);
	}

	puts("Waiting for incoming connections...");

	while (1)
	{
		struct sockaddr_in client_addr;		 //to get client address IP
		int addrlen = sizeof(client_addr); //to get the IP length

		//accept a connection
		clientSocket = accept(sockServer, (struct sockaddr *)&client_addr, &addrlen); // this is for the client socket to accesspt the connection with the server socket
		memset(message, 0, sizeof(message));																					//copy and upercase the message sent from the client
		numbytes = recv(clientSocket, message, MAX, 0);																//to know the number of byets sent by the client
		int length = strlen(message) - 1;
		for (i = 0; i < numbytes; i++)
		{
			if (message[i] != '\n')
				message[i] = toupper(message[i]); //uppercase the message
		}
		send(clientSocket, message, numbytes, 0);
		if (strcmp(message, "exit server") == 0)
		{
			close(clientSocket);
			printf("You got disconnected from server.\n");
			exit(1);
		}
		//close connection
		close(clientSocket);
	}

	//clean up
	close(sockServer);
	WSACleanup();
	return 0;
}
