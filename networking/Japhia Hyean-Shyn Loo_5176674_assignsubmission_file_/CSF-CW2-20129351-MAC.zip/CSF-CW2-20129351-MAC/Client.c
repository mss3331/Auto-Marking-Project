#include <stdio.h>
#include <netdb.h>
#include <netinet/in.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#define MAX 80
#define SA struct sockaddr

void func(int sockfd)
{
	char buff[MAX], server[MAX];
	int n;

	// infinite loop for receiving feedback from server
	for (;;) {
		bzero(buff, sizeof(buff));
		bzero(server, MAX);
		printf("Enter the string : ");

		n = 0;
		while ((buff[n++] = getchar()) != '\n')
			;
		write(sockfd, buff, sizeof(buff));

		if ((strcmp(buff, "exit server\n")) == 0) {
			printf("Client Exit...\n");
			break;
		}
		
		read(sockfd, server, sizeof(server));
		printf("From Server : %s", server);
		
	}
}

int main()
{
	int sockfd, connfd;
	struct sockaddr_in servaddr, cli;
    int PORT;
    char newline;

    printf("Enter port number : ");
    scanf("%d", &PORT);
    newline = getchar();

    while ((PORT < 1000) || (PORT > 10000))
    {
        printf("Invalid port number entered...\n");
        printf("Enter another port number : ");
        scanf("%d", &PORT);
        newline = getchar();
    }
 
	// socket create and varification
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd == -1) {
		printf("socket creation failed...\n");
		exit(0);
	}
	else
		printf("Socket successfully created..\n");
	bzero(&servaddr, sizeof(servaddr));

	// assign IP, PORT
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
	servaddr.sin_port = htons(PORT);

	// connect the client socket to server socket
	if (connect(sockfd, (SA*)&servaddr, sizeof(servaddr)) != 0) {
		printf("connection with the server failed...\n");
		exit(0);
	}
	else
		printf("connected to the server..\n");

	// function for chat
	func(sockfd);

	// close the socket
	close(sockfd);
    
}
