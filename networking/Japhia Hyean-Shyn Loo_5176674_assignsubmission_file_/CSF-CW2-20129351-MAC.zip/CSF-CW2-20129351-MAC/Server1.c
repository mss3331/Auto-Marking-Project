#include <stdio.h>
#include <netdb.h>
#include <netinet/in.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <ctype.h>
#define MAX 80
#define SA struct sockaddr

// Function designed for client and server interaction.
void func(int sockfd)
{
	char buff[MAX], client[MAX];

	// infinite loop for chat
	for (;;) 
    {
		bzero(buff, MAX);
		bzero(client, MAX);

		// read the message from client and copy it in buffer
		read(sockfd, buff, sizeof(buff));

		// if msg contains "exit server" then server exit.
		if ((strcmp("exit server\n", buff) == 0) || (strcmp("exit client\n", buff) == 0))
        {
			printf("Server Exit...\n");
			break;
		}


		// changing client message to uppercase.
		int i = 0;

		while (buff[i])
		{
			client[i] = buff[i];
			i++;
		}

		for (int i = 0; buff[i]!='\n' ; i++)
		{
      		if(buff[i] >= 'a' && buff[i] <= 'z')
			{
        		client[i] = client[i] - 32;
      		}
		}

		//returning ammended message back to client.
		write(sockfd, client, sizeof(client));

	}
}

// Driver function
int main()
{
	int sockfd, connfd;
    unsigned int * len;
	struct sockaddr_in servaddr, cli;
    int PORT;

	// Asking for port number
    printf("Enter port number : ");
    scanf("%d", &PORT);

	// Checking if port number within valid range.
    while ((PORT < 1000) || (PORT > 10000))
    {
        printf("Invalid port number entered...\n");
        printf("Enter another port number : ");
        scanf("%d", &PORT);
    }

	// socket create and verification
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd == -1)
    {
		printf("socket creation failed...\n");
		exit(0);
	}
	else
		printf("Socket successfully created..\n");
	bzero(&servaddr, sizeof(servaddr));

	// assign IP, PORT
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port = htons(PORT);

	// Binding newly created socket to given IP and verification
	if ((bind(sockfd, (SA*)&servaddr, sizeof(servaddr))) != 0) {
		printf("socket bind failed...\n");
		exit(0);
	}
	else
		printf("Socket successfully binded..\n");

	// Now server is ready to listen and verification
	if ((listen(sockfd, 5)) != 0)
    {
		printf("Listen failed...\n");
		exit(0);
	}
	else
		printf("Server listening..\n");
	unsigned int a = (sizeof(cli));
    len = &a;

	// Accept the data packet from client and verification
	connfd = accept(sockfd, (SA*)&cli, len);
	if (connfd < 0)
    {
		printf("server accept failed...\n");
		exit(0);
	}
	else
		printf("server accept the client...\n");

	// Function for client and server interaction.
	func(connfd);

	// After chatting close the socket
	close(sockfd);

	len = NULL;
}
