//////////////////////////  Server.c ////////////////
#include <io.h>
#include <stdio.h>
#include <winsock2.h>
#include <ctype.h>
#include <string.h>
#include <time.h>

#define MAXBUF		256


int main(int argc , char *argv[])
{
    int MY_PORT;
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];


    time_t currentTime;
    struct tm *myTime;
    time(&currentTime);
    myTime = localtime(&currentTime); 
    char string[100];
    strftime(string,sizeof(string),"%d-%m-%y %H\r\n", myTime);	// using strftime to display time
    char a[100];
    strftime(a,sizeof(a),"%Y\r\n", myTime);			// using strftime to display time
    char b[100];
    strftime(b,sizeof(b),"%H\r\n", myTime);			// using strftime to display time
    char c[100];
    strftime(c,sizeof(c),"%d-%b-%y\r\n", myTime);		// using strftime to display time

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	memset(&self,'\0',sizeof(self));
	self.sin_family = AF_INET;
	printf("Enter your port number");
	scanf("%d",&MY_PORT);
	printf("Networking 1>start server %d\n",MY_PORT);
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  
	
	
	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{	
		struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		printf("Client connected.\n");
			
		printf("The IP address of the client is:%s\n",inet_ntoa(client_addr.sin_addr));	//display IP address of the client
		printf("Port number targeted by the client's request is :%d\n",ntohs(self.sin_port));//display the port number targeted by the client’s request

		int recv_size;
        while (recv_size != 0){
			recv_size = recv(clientfd, buffer, MAXBUF, 0);
			printf("Length of the message is :%d\n",recv_size);	//Display the message length

			 if (strcmp(buffer, "date") == 0){			//if the client input message is “date” will display date in “dd-mm-yy hh”format
				send(clientfd, string, strlen(string), 0);
				continue;
			}//end if
			else if (strcmp(buffer, "date1") == 0){			//if the client input message is “date1” will display date in “yyyy”format
				send(clientfd, a, strlen(a), 0);
				continue;
			}//end if
			else if (strcmp(buffer, "date2") == 0){			//if the client input message is “date2” will display date in “hh”format
				send(clientfd, b, strlen(b), 0);
				continue;
			}//end if
			else if (strcmp(buffer, "date3") == 0){			//if the client input message is “date3” will display date in “dd-Mon-yy”format
				send(clientfd, c, strlen(c), 0);
				continue;
			}//end if
			else if (strcmp(buffer, "exit server") == 0){	//connection terminate if the client input message is “exit server”
				shutdown(clientfd,2);
				break;
			}//end if for exit
			else{
		    	for(int i=0; i<recv_size; i++){
					buffer[i]=toupper(buffer[i]);	//to uppercase the buffer
		    	}
            	send(clientfd, buffer, recv_size, 0);			//send buffer to client
			}//end else
			memset(buffer,'\0',sizeof(buffer));
		}

		/*---close connection---*/
	close(clientfd);
	}

	/*---clean up (should never get here!)---*/

	close(sockfd);
	
        WSACleanup();
	return 0;
}
