            //////////////////////////  EchoClient.c ////////////////
#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<ctype.h>
#include<string.h>


#define MAXBUF		256

int main(int argc , char *argv[])
{
    int MY_PORT;
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];
	char Server_Reply[MAXBUF];

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
    memset(Server_Reply,'\0',sizeof(Server_Reply));
    printf("Initialised.\n");
	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) == 0 )
	{
		perror("Socket");
		exit(errno);		
	}
        printf("Socket created.\n");
	
	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	memset(&self,'\0',sizeof(self));
	self.sin_family = AF_INET;		  
	printf("Enter your port number");
	scanf("%d",&MY_PORT);
	printf("Networking 1>start server %d\n",MY_PORT);
	self.sin_port = htons(MY_PORT);		// Host to Network Short (16-bit)
	self.sin_addr.s_addr =  inet_addr("127.0.0.1");  

    /* connect: create a connection with the server */
    if (connect(sockfd, (struct sockaddr *)&self, sizeof(self)) < 0) {
      printf("ERROR connecting");
      exit(0);
    }
    else{
	printf("connected to server..\n");
    }
    /* get message line from the user */
    while(1)
    {   
        //get string to send from terminal
	printf("Enter message:");
	fgets(buffer,MAXBUF,stdin);


        //send the message to server
	send(sockfd,buffer,strlen(buffer),0);

        int recv_size=recv(sockfd, Server_Reply, sizeof(Server_Reply)-1,0);
        if(  recv_size   > 0 )
        {
            Server_Reply[recv_size] = 0;
            printf("%s\n",Server_Reply);
        }
        else{
            break;
        }

    

    if( recv_size < 0)
    {
        printf("\n Server closed connection \n");
    } 
    if (strncmp(buffer, "exit server",11) == 0){	//connection between server and client will terminate if client input exit server
	shutdown(clientfd,2);
	break;
    }//end if for exit

 
    }
    close(sockfd);
    exit(0);
    WSACleanup();
}