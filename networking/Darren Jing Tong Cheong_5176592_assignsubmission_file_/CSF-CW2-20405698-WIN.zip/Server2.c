//////////////////////////  Server.c ////////////////
#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<ctype.h>
#include<string.h>


#define MAXBUF		256


int main(int argc , char *argv[])
{
    int MY_PORT;
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];


    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	printf("Enter your port number");
	scanf("%d",&MY_PORT);
	printf("Networking 1>start server %d\n",MY_PORT);
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  
	
	
	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{	
		struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);
		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		printf("Client connected.\n");
		printf("The IP address of the client is:%s\n",inet_ntoa(client_addr.sin_addr));	//display IP address of the client
		printf("Port number targeted by the client's request is :%d\n",ntohs(self.sin_port));	//display the port number targeted by the client’s request
		int i;
		int recv_size;
		while(recv_size !=0 ){
			recv_size= recv(clientfd, buffer, MAXBUF, 0);
			printf("Length of the message is :%d\n",recv_size);	//Display the message length
			if(strcmp(buffer,"exit server")== 0){	//connection terminate if the client input message is “exit server”
				shutdown(clientfd,2);
			}
			for (i=0;i<recv_size;i++){
				buffer[i]= toupper(buffer[i]);	//to uppercase the buffer
			}
		send(clientfd, buffer, recv_size , 0);	//send buffer to client
	}
		/*---close connection---*/
	close(clientfd);
	}

	/*---clean up (should never get here!)---*/

	close(sockfd);
	
        WSACleanup();
	return 0;
}
