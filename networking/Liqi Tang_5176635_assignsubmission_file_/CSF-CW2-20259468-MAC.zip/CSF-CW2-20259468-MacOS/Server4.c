#include <stdio.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <ctype.h>
#include <time.h>
#define MAX 80
#define SA struct sockaddr

struct timex
{
   int tm_hour;        /* hours, range 0 to 23             */
   int tm_mday;        /* day of the month, range 1 to 31  */
   int tm_mon;         /* month, range 0 to 11             */
   int tm_year;        /* The number of years since 1900   */
};

// Function designed for chat between client and server.
void func(int sockfd)
{
    char buff[MAX];
    char buffer[MAX];
    char buffer1[MAX];
    char buffer3[MAX];
    char buffer2[MAX];
    int n = 0;
    time_t rawtime;
    struct timex *info;
    struct timex *info1;
    struct timex *info3;
    struct timex *info2;
    time( &rawtime );
    info = localtime( &rawtime );
    info1 = localtime( &rawtime );
    info2 = localtime( &rawtime );
    info3 = localtime( &rawtime );
    // infinite loop for chat
    for (;;) {
            bzero(buff, MAX);
        bzero(buffer, MAX);
       
            // read the message from client and copy it in buffer
            read(sockfd, buff, sizeof(buff));
            // if the message is exit then exit
            if (strncmp("exit server", buff, 11) == 0) {
                   printf("exit server...\n");
                   break;
               }
            // change to the uppercase
            for (int i=0; i<MAX; i++) {
                    buff[i]=toupper(buff[i]);
                }
            // print buffer which contains the client contents
            printf("From client: %s\t To client : ", buff);
            // if input client date
            if (strncmp("DATE1", buff, 5) == 0) {
                strftime(buffer1,80,"%Y\n", info1);
                write(sockfd, buffer1, sizeof(buffer1));
                continue;
            }
        
            if (strncmp("DATE2", buff, 5) == 0) {
                strftime(buffer2,80,"%H\n", info2);
                write(sockfd, buffer2, sizeof(buffer2));
                continue;
            }
        
            if (strncmp("DATE3", buff, 5) == 0) {
                strftime(buffer3,80,"%d-%b-%y\n", info3);
               write(sockfd, buffer3, sizeof(buffer3));
                continue;
            }
        
            if (strncmp("DATE", buff, 4) == 0) {
                strftime(buffer,80,"%d-%m-%y  %H\n", info);
                write(sockfd, buffer, sizeof(buffer));
                continue;;
            }
            bzero(buff, MAX);
            n = 0;
            // copy server message in the buffer
            while ((buff[n++] = getchar()) != '\n')
                ;
       
            // and send that buffer to client
            write(sockfd, buff, sizeof(buff));
        }
}

// Driver function
int main()
{
    int sockfd, connfd, len;
    struct sockaddr_in servaddr, cli;
    int PORT;
    
    printf("please input ur port num.:");
    scanf("%d",&PORT);
    printf("start server %d\n",PORT);

    // socket create and verification
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1) {
        printf("socket creation failed...\n");
        exit(0);
    }
    else
        printf("Socket successfully created..\n");
    bzero(&servaddr, sizeof(servaddr));

    // assign IP, PORT
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(PORT);

    // Binding newly created socket to given IP and verification
    if ((bind(sockfd, (SA*)&servaddr, sizeof(servaddr))) != 0) {
        printf("socket bind failed...\n");
        exit(0);
    }
    else
        printf("Socket successfully binded..\n");

    // Now server is ready to listen and verification
    if ((listen(sockfd, 5)) != 0) {
        printf("Listen failed...\n");
        exit(0);
    }
    else
        printf("Server listening..\n");
    len = sizeof(cli);

    // Accept the data packet from client and verification
    connfd = accept(sockfd, (SA*)&cli, &len);
    if (connfd < 0) {
        printf("server accept failed...\n");
        exit(0);
    }
    else
        printf("server accept the client...\n");

    // Function for chatting between client and server
    func(connfd);

    // After chatting close the socket
    close(sockfd);
}