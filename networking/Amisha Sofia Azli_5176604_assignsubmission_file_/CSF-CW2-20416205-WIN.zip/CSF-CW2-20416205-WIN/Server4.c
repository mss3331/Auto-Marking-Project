//////////////////////////  Server4.c ////////////////
#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<time.h>

//#define MY_PORT		8989
#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/---create streaming socket---/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/---initialize address/port structure---/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons((atoi(argv[1]));	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/---assign a port number to the socket---/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/---make it a "listening socket"---/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	/---forever... ---/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);
		time_t t ;
		struct tm *tmp ;
		char buffer[256];
		time( &t );
		tmp = localtime( &t );
		//numbytes = recv(clientfd, buffer, MAXBUF, 0);

		/---accept a connection (creating a data pipe)---/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);

		printf("IP Address: %hhu\n", client_addr.sin_addr.s_addr); //
        printf("Port Number: %u\n", client_addr.sin_port);

		while(strcmp (buffer,"exit server",11)!=0){ //while the string typed isnt exit server,
		
		//display date format
		if(strcmp(buffer,"date",4)==0){ //for format dd-mm-yy hh
			strftime(MY_TIME, sizeof(MY_TIME),"%d-%m-%y %I\r\n", tmp);
			printf("Current Date and Time : %s\n", MY_TIME );
			send(clientfd, strupr(buffer), recv(clientfd, buffer, MAXBUF, 0), 0);
		}
		else if(strcmp(buffer,"date1",5)==0){ //for format yyyy
	        strftime(MY_TIME, sizeof(MY_TIME), "%y\r\n", tmp);
            printf("Formatted date & time : %d\n", tmp->tm_year+1900 );
			send(clientfd, strupr(buffer), recv(clientfd, buffer, MAXBUF, 0), 0);
        }
        else if(strcmp(buffer,"date2",5)==0){
            strftime(MY_TIME, sizeof(MY_TIME), "I\r\n",tmp); //for format hh
	        printf("Formatted date & time : %s\n", MY_TIME );
			send(clientfd, strupr(buffer), recv(clientfd, buffer, MAXBUF, 0), 0);
        }
        else if (strcmp(buffer,"date3",5)==0){
	        strftime(MY_TIME, sizeof(MY_TIME), "%d-%b-%y\r\n", tmp); //for format dd-Mon-yy
	        printf("Formatted date & time : %s\n", MY_TIME );
			send(clientfd, strupr(buffer), recv(clientfd, buffer, MAXBUF, 0), 0);
        }
		else { //else display the uppercased strings inputted by client and display the length of the message 
		int numbytes = recv(clientfd, buffer, MAXBUF,0);
		//send(clientfd, buffer, recv(clientfd, buffer, MAXBUF, 0), 0);
		send(clientfd, strupr(buffer), numbytes, 0);
		printf("\nlength of the message sent was: %d\n",numbytes);
		}
		}

		/---close connection---/
		if(strcmp(buffer,"exit server",11)==0){
		printf("Closing server...");
		close(clientfd);
		}
	}
		
	

	/---clean up (should never get here!)---/
	close(sockfd);
        WSACleanup();
	return 0;
}