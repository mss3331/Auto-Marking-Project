//////////////////////////  Server.c ////////////////

#include <io.h>
#include <stdio.h>
#include <winsock2.h>
#include <string.h>

// #define MY_PORT	8989
#define MAXBUF	256

int main(int argc , char *argv[])
{
    // Getting the argument for port, if empty default would be
    int portNum = 0;
    if (argc > 1)
        portNum = atoi(argv[1]);
    else
    {
        printf("No Port Number was defined, thus default port 8989 would be used.\n");
        portNum = 8989;
    }
    printf("Port Number to be used: %d\n", portNum);

    WSADATA wsa;
    SOCKET sockfd , clientfd;
    struct sockaddr_in self;

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

    printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
    if (portNum == 0) // Just to make sure it's not 0.
    {
        puts("Error: PortNum was defined as 0, Closing program...");
        return -1;
    }
	self.sin_port = htons(portNum);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

    puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
    
    while (1)
    {
        puts("Waiting for incoming connections...");
    
        // Setting up the server to accept a connection before conversing
        struct sockaddr_in client_addr;
	    int addrlen=sizeof(client_addr);
	    clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
        if (clientfd < 0)
        {
            puts("Connection Error was encountered");
            return -1;
        } else
        {
            printf("Connection socket established with Client [%s] on port %u. Starting conversation...\n", inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));
            char str[] = "Welcome to the Server, \"exit server\" to close the connection and \"shutdown server\" to shutdown the server.\n";
            send(clientfd, str, sizeof(str), 0);
        }
    
        char closeString[MAXBUF] = "exit server";
        char shutString[MAXBUF] = "shutdown server";
    	char buffer[MAXBUF] = "";

        // only looping a conversation when the string is the message
	    while (clientfd > 0)
	    {			
            puts("Waiting for message to be received...");
            int bytesReceived = recv(clientfd, buffer, MAXBUF, 0);
            printf("Message Received of %d characters [%d bytes]: %s", strlen(buffer)-1 /*To not count the newline character*/, bytesReceived, buffer);
		    if (bytesReceived < 0)
                break;

	        // Close the connection if the input string is "exit server\n"
            if (strncmp(buffer, closeString, strlen(closeString)) == 0 || strncmp(buffer, shutString, strlen(shutString)) == 0)
            {
                char str[] = "Closing connection...\n";
                send(clientfd, str, sizeof(str), 0);
                puts("Connection Closed.");
                break;
            }

            // Uppercase the input messages
            strupr(buffer);
            
            printf("Sending: %s\n", buffer);
            send(clientfd, buffer, bytesReceived, 0);
            memset(buffer, 0, strlen(buffer));   // clear buffer, so we could receive new message
        }
        close(clientfd); // Close the connection

        // If the input is to shut down server
        if (strncmp(buffer, shutString, strlen(shutString)) == 0)
        {
            puts("Shutdown detected. Shutting down...");
            break;
        }
    }

	// Cleanup the connection
	close(sockfd);
    WSACleanup();
	return 0;
}
