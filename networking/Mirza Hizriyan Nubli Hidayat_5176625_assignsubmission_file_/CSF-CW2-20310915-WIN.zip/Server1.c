//////////////////////////  Server.c ////////////////

#include <io.h>
#include <stdio.h>
#include <winsock2.h>
#include <string.h>

// #define MY_PORT	8989
#define MAXBUF	256

// Prototype function for uppercase function
void uppercase(char * str);

int main(int argc , char *argv[])
{
    // Getting the argument for port, if empty default would be
    int portNum = 0;
    if (argc > 1)
        portNum = atoi(argv[1]);
    else
    {
        printf("No Port Number was defined, thus default port 8989 would be used.\n");
        portNum = 8989;
    }
    printf("Port Number to be used: %d\n", portNum);

    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

    printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
    if (portNum == 0) // Just to make sure it's not 0.
    {
        puts("Error: PortNum was defined as 0, Closing program...");
        return -1;
    }
	self.sin_port = htons(portNum);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

    puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
    puts("Waiting for incoming connections...");
    
    // Setting up the server to accept a connection before conversing
    struct sockaddr_in client_addr;
	int addrlen=sizeof(client_addr);

	/*---accept a connection (creating a data pipe)---*/
	clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
    if (clientfd < 0)
    {
        puts("Connection Error was encountered");
        return -1;
    } else
    {
        puts("Connection socket established. Starting conversation...");
        char str[] = "Welcome to the Server. Send in a message to be uppercased with.\n";
        send(clientfd, str, sizeof(str), 0);
    }
    
    char closeString[MAXBUF] = "exit server";
	// only looping a conversation when the string is the message
	while (clientfd > 0)
	{			
        puts("Waiting for message to be received...");
        int bytesReceived = recv(clientfd, buffer, MAXBUF, 0);
        printf("Message Received of %d bytes: %s", bytesReceived, buffer);
		
	    // Close the connection if the input string is "exit server\n"
        if (strncmp(buffer, closeString, strlen(closeString)) == 0)
        {
            char str[] = "Closing connection...\n";
            send(clientfd, str, sizeof(str), 0);
            close(clientfd); // Close the connection
            break;
        }

        // Uppercase the input messages
        strupr(buffer);

        send(clientfd, buffer, bytesReceived, 0);
        memset(buffer, 0, strlen(buffer));   // clear buffer, so we could receive new message
    }

	// Cleanup the connection
	close(sockfd);
    WSACleanup();
	return 0;
}
