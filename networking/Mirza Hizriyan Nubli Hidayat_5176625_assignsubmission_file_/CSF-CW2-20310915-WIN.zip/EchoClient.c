#include <io.h>
#include <stdio.h>
#include <winsock2.h>
#include <string.h>

#define MAXBUF 256

// Client Socket Programming code
// It will allow to choose a port as an argument (argv[1]), tho default would be 8989
int main(int argc, char *argv[])
{
    // Getting if there is a PORT number specified to use
    int portNumber = 0;
    if (argc > 1)
    {
        portNumber = atoi(argv[1]);
        printf("Port Number defined. Port %d would be used\n", portNumber);
    }
    else
    {
        printf("No Port Number was defined, thus default port 8989 would be used.\n");
        portNumber = 8989;
    }

    printf("By default, and purpose of the program, client will connect to a localhost(127.0.0.1) socket connetion\n"); 

    WSADATA wsa;
    SOCKET sock;
    
    // Starting up WSA 
    if (WSAStartup(MAKEWORD(2,2), &wsa) != 0)
    {
        printf("Failed. Error code: %d\n", WSAGetLastError());
        return -1;
    }
    printf("WSA Initialised...\n");

    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        printf("Socket creation error.\n");
        return -1;
    }
    printf("Socket created!\n");
        
    // Setting up the server's address and port
    struct sockaddr_in serv_addr; // Server socket address struct to be used
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(portNumber);
    serv_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
   
    printf("IP Address formatted (%s).\nSetup complete! Initializing connection on port %d...\n", inet_ntoa(serv_addr.sin_addr), ntohs(serv_addr.sin_port));

    if (connect(sock, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) // Connection Error
    {
        printf("Connection failed\n");
        return -1;
    }
    
    //connect(sock, (struct sockaddr*) &serv_addr, sizeof(serv_addr));
    printf("Connection established.\n");
    
    // Conversation started...
    char initMsg[MAXBUF], buffer[MAXBUF], message[MAXBUF];
    int recv_size = 0;        
    if ((recv_size = recv(sock, initMsg, MAXBUF, 0)) < 0) // if there's an initial message to be received
    {
        initMsg[recv_size] = '\0';
        printf("%s", initMsg);
    }
    
    while (1)
    {
        printf("Enter your message [\"exit client\" to exit the client.]: ");
        fgets(message, MAXBUF, stdin);

        char exitStr[MAXBUF] = "exit client";
        if (strncmp(message, exitStr, strlen(exitStr)) == 0)
        {
            printf("Exiting client....\n");
            // Sends exit command to server before closing the connection
            strcpy(message, "exit server\n");
            send(sock, message, strlen(message), 0);
            break;
        }
        
        // Sends message
        if(send(sock, message, strlen(message), 0) < 0)
        {
            printf("Sending failed... Continuing...\n");
            continue;
        }
        else
            puts("Sent!");
        
        recv_size = 0;
        // Printing out the reply from the server
        // Below for if there is an error in receiving the message
        if ((recv_size = recv(sock, buffer, MAXBUF, 0)) < 0)
        {
            puts("Reply receiving failed... Continuing...");
            continue;
        }
        buffer[recv_size] = '\0'; // Null terminating the reply
        // Close the connnection if server sends back "Closing connection..."
        if (strncmp(buffer, "Closing connection...", strlen("Closing connection...")) == 0)
        {
            printf("Server has closed the connection. Shutting down client...");
            break;
        } 
        printf("Reply: %s\n", buffer);
        // Empty buffer and message to be used again.
        memset(message, 0, strlen(message) + 1);
        memset(buffer, 0, strlen(buffer) + 1);
    }
    
    close(sock); // closing the connection (socket)
    WSACleanup();
    return 0;
}
