//////////////////////////  Server1.c ////////////////

#include <io.h>
#include <stdio.h>
#include <winsock2.h>
#include <string.h>
#include <stdlib.h>

#define MAXBUF 256
// gcc Server1.c -o Server1 -lws2_32, - Networking 1>start server 8989
int main(int argc, char *argv[])
{
	WSADATA wsa;
	SOCKET sockfd, clientfd; // socket declaration
	struct sockaddr_in self;
	char buffer[MAXBUF];
	// initialize winsock
	printf("\nInitialising Winsock...");
	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
	{
		printf("Failed. Error Code : %d", WSAGetLastError());
		return 1;
	}

	printf("Initialised.\n");

	/*---create streaming socket---*/
	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) // addreess family(ipv4), type, protocol)
	{
		perror("Socket");
		exit(errno);
	}

	printf("Socket created.");

	/*---initialize address/port structure---*/
	char command[40];
	char *exits = "EXIT SERVER";
	char *starts = "- Networking 1>start server";
	char port[8];
	while (strlen(command) < 29)
	{
		printf("\nEnter command:\n");
		gets(command);
		int size = strlen(command) - strlen(starts) - 1; // size of port
		for (int i = 0; i < size; i++)					 // to get port
		{
			port[i] = command[i + 28];
		}
	}
	int port_num = atoi(port);
	/*---initialize address/port structure---*/
	self.sin_family = AF_INET;
	self.sin_port = htons(port_num); // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;

	/*---assign a port number to the socket---*/
	if (bind(sockfd, (struct sockaddr *)&self, sizeof(self)) != 0)
	{
		perror("socket--bind");
		exit(errno);
	}
	puts("Bind done");

	/*---make it a "listening socket"---*/
	if (listen(sockfd, 20) != 0)
	{
		perror("socket--listen");
		exit(errno);
	}

	puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{
		struct sockaddr_in client_addr;
		int addrlen = sizeof(client_addr);
		int i = 0;

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr *)&client_addr, &addrlen);

		int recv_size = recv(clientfd, buffer, MAXBUF, 0); // receive
		for (int i = 0; buffer[i] != '\0'; i++)			   // uppercase a string
		{
			if (buffer[i] >= 'a' && buffer[i] <= 'z')
			{
				buffer[i] = buffer[i] - 32;
			}
		}
		send(clientfd, buffer, recv_size, 0);
		close(clientfd);
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
	WSACleanup();
	return 0;
}
