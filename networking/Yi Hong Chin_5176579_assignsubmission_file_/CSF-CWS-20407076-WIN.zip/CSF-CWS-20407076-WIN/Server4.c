//////////////////////////  Server4.c ////////////////

#include <io.h>
#include <stdio.h>
#include <winsock2.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>

#define MAXBUF 256
// function to acquire month
char *month_name(int m)
{
    char *month;

    switch (m)
    {
    case 1:
        month = "Jan";
        break;
    case 2:
        month = "Feb";
        break;
    case 3:
        month = "Mar";
        break;
    case 4:
        month = "Apr";
        break;
    case 5:
        month = "May";
        break;
    case 6:
        month = "Jun";
        break;
    case 7:
        month = "Jul";
        break;
    case 8:
        month = "Aug";
        break;
    case 9:
        month = "Sep";
        break;
    case 10:
        month = "Oct";
        break;
    case 11:
        month = "Nov";
        break;
    case 12:
        month = "Dec";
        break;
    }
    return month;
}

// gcc Server4.c -o Server4 -lws2_32, - Networking 1>start server 8989
int main(int argc, char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd, clientfd; // socket declaration
    struct sockaddr_in self;
    int gotostart = 1;

    // initialize winsock
    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
    {
        printf("Failed. Error Code : %d", WSAGetLastError());
        return 1;
    }
    printf("Initialised.\n");

    /*---create streaming socket---*/
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) // addreess family(ipv4), type, protocol)
    {
        perror("Socket");
        exit(errno);
    }
    printf("Socket created.\n");

    // accept any port number and exit server command implemented here
    char command[40];
    const char exits[30] = "EXIT SERVER";
    char *starts = "- Networking 1>start server";
    const char date[5] = "DATE";
    const char date1[6] = "DATE1";
    const char date2[6] = "DATE2";
    const char date3[6] = "DATE3";
    char port[8];
    while (strlen(command) < 29)
    {
        printf("Enter command:\n");
        gets(command);
        int size = strlen(command) - strlen(starts) - 1; // size of port
        for (int i = 0; i < size; i++)                   // to get port
        {
            port[i] = command[i + 28];
        }
    }
    int port_num = atoi(port);

    /*---initialize address/port structure---*/
    self.sin_family = AF_INET;
    self.sin_port = htons(port_num);
    self.sin_addr.s_addr = INADDR_ANY;

    /*---assign a port number to the socket---*/
    if (bind(sockfd, (struct sockaddr *)&self, sizeof(self)) != 0)
    {
        perror("socket--bind");
        exit(errno);
    }
    printf("\n");
    puts("Bind done");

    /*---make it a "listening socket"---*/
    if (listen(sockfd, 20) != 0)
    {
        perror("socket--listen");
        exit(errno);
    }
    puts("\nWaiting for incoming connections...");

    /*---forever... ---*/
    int cond1 = 1;
    while (cond1)
    {
        struct sockaddr_in client_addr;
        int addrlen = sizeof(client_addr);

        /*---accept a connection (creating a data pipe)---*/
        clientfd = accept(sockfd, (struct sockaddr *)&client_addr, &addrlen);
        printf("\n IP ADDRESS:%s \n PORT NUMBER:%d \n", inet_ntoa(client_addr.sin_addr), port_num); // print ip and port
        int cond = 1;
        while (cond)
        {
            char buffer[MAXBUF] = "\0";
            int recv_size = recv(clientfd, buffer, MAXBUF, 0);
            for (int i = 0; buffer[i] != '\0'; i++) // uppercase a string
            {
                if (buffer[i] >= 'a' && buffer[i] <= 'z')
                {
                    buffer[i] = buffer[i] - 32;
                }
            }
            // conditions
            int condition = strcmp(buffer, exits);
            int date_cond = strcmp(buffer, date);
            int date_cond1 = strcmp(buffer, date1);
            int date_cond2 = strcmp(buffer, date2);
            int date_cond3 = strcmp(buffer, date3);
            // time initialization
            time_t t;
            t = time(NULL);
            struct tm tm = *localtime(&t);
            // send date to client
            if (date_cond == 0)
            {
                char send_date[40] = "Current date and time is: ";
                int day = tm.tm_mday;
                int month = tm.tm_mon + 1;
                int year = tm.tm_year - 100;
                int hour = tm.tm_hour;
                char s_day[5];
                char s_month[5];
                char s_year[5];
                char s_hour[5];
                itoa(day, s_day, 10);
                itoa(month, s_month, 10);
                itoa(year, s_year, 10);
                itoa(hour, s_hour, 10);
                strcat(send_date, s_day);
                strcat(send_date, "-");
                strcat(send_date, s_month);
                strcat(send_date, "-");
                strcat(send_date, s_year);
                strcat(send_date, " ");
                strcat(send_date, s_hour);
                // send date
                send(clientfd, send_date, 35, 0);
            }
            // send date1 to client
            else if (date_cond1 == 0)
            {
                char send_date1[25] = "Current year is: ";
                int year1 = tm.tm_year + 1900;
                char s_year1[5];
                itoa(year1, s_year1, 10);
                strcat(send_date1, s_year1);
                // send date
                send(clientfd, send_date1, 23, 0);
            }
            // send date2
            else if (date_cond2 == 0)
            {
                char send_date2[40] = "Current 24-hour is: ";
                int hour2 = tm.tm_hour;
                char s_hour2[5];
                itoa(hour2, s_hour2, 10);
                strcat(send_date2, s_hour2);
                // send date
                send(clientfd, send_date2, 24, 0);
            }
            // send date3
            else if (date_cond3 == 0)
            {
                char send_date3[30] = "Current date is: ";
                int day3 = tm.tm_mday;
                int month3 = tm.tm_mon + 1;
                int year3 = tm.tm_year - 100;
                char s_day3[5];
                char *s_month3 = month_name(month3);
                char s_year3[5];
                itoa(day3, s_day3, 10);
                itoa(year3, s_year3, 10);
                strcat(send_date3, s_day3);
                strcat(send_date3, "-");
                strcat(send_date3, s_month3);
                strcat(send_date3, "-");
                strcat(send_date3, s_year3);
                // send date
                send(clientfd, send_date3, 27, 0);
            }
            // exit server is prompt
            else if (condition == 0)
            {
                printf("\nterminating.....");
                break;
            }
            // send data to client and print len
            else
            {
                send(clientfd, buffer, recv_size, 0);
                int length = strlen(buffer);
                printf("\n word length is:%d\n", length);
            }
            close(clientfd);
        }
        printf("\nclient connection terminated");
        close(clientfd);
    }

    /*---clean up (should never get here!)---*/
    close(sockfd);
    WSACleanup();
    return 0;
}
