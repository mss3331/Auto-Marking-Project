//////////////////////////  EchoClient.c ////////////////

#include <io.h>
#include <stdio.h>
#include <winsock2.h>
#include <string.h>
#include <stdlib.h>

#define MY_PORT 8989
#define MAXBUF 256

// gcc EchoClient.c -o EchoClient -lws2_32, - Networking 1>start server 8989
int main(int argc, char *argv[])
{
    WSADATA wsa;
    SOCKET clientfd;
    struct sockaddr_in self;
    char exits[30] = "exit server";

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
    {
        printf("Failed. Error Code : %d", WSAGetLastError());
        return 1;
    }
    printf("Initialised.\n");

    /*---create streaming socket---*/
    if ((clientfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror("Socket");
        exit(errno);
    }
    printf("Socket created.\n");

    /*---initialize address/port structure---*/
    self.sin_family = AF_INET;
    self.sin_port = htons(MY_PORT);
    self.sin_addr.s_addr = inet_addr("127.0.0.1");

    /*---connecting---*/
    int connection = connect(clientfd, (struct sockaddr *)&self, sizeof(self));
    if (connection == 0)
        printf("\nConnected to the server.\n");
    else
        printf("Theres a connection problem......!!!\n");

    /*---forever... ---*/
    while (1)
    {
        while (1)
        {
            char message[MAXBUF] = "\0";
            char server_reply[MAXBUF] = "\0";
            puts("Enter your message:");
            gets(message);
            if (strcmp(message, exits) == 0)
            {
                break;
            }
            else
            {
                // sending message to server
                if (send(clientfd, message, strlen(message), 0) < 0)
                {
                    printf("\nSend failed!");
                }
                else
                {
                    printf("\nmessage sent succesfully!");
                }
                // receiving message from server

                if (recv(clientfd, server_reply, 256, 0) < 0)
                {
                    printf("\nreceive failure!");
                }
                else
                {
                    printf("\nmessage received succesfully!");
                    printf("\nserver replied: %s\n", server_reply);
                }
                close(clientfd);
            }
        }
        close(clientfd);
        printf("connection terminated....");
        exit(0);
    }
    WSACleanup();
    return 0;
}
