//////////////////////////  Server3.c ////////////////

#include <io.h>
#include <stdio.h>
#include <winsock2.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>

#define MAXBUF 256

// gcc Server3.c -o Server3 -lws2_32, - Networking 1>start server 8989
int main(int argc, char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd, clientfd; // socket declaration
    struct sockaddr_in self;
    int gotostart = 1;

    // initialize winsock
    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
    {
        printf("Failed. Error Code : %d", WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

    /*---create streaming socket---*/
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) // addreess family(ipv4), type, protocol)
    {
        perror("Socket");
        exit(errno);
    }

    printf("Socket created.\n");

    // accept any port number and exit server command implemented here
    char command[40];
    char exits[30] = "EXIT SERVER";
    char *starts = "- Networking 1>start server";
    char date[5] = "DATE";
    char port[8];
    while (strlen(command) < 29)
    {
        printf("Enter command:\n");
        gets(command);
        int size = strlen(command) - strlen(starts) - 1; // size of port
        for (int i = 0; i < size; i++)                   // to get port
        {
            port[i] = command[i + 28];
        }
    }
    int port_num = atoi(port);
    /*---initialize address/port structure---*/
    self.sin_family = AF_INET;
    self.sin_port = htons(port_num);
    self.sin_addr.s_addr = INADDR_ANY;

    /*---assign a port number to the socket---*/
    if (bind(sockfd, (struct sockaddr *)&self, sizeof(self)) != 0)
    {
        perror("socket--bind");
        exit(errno);
    }
    printf("\n");
    puts("Bind done");

    /*---make it a "listening socket"---*/
    if (listen(sockfd, 20) != 0)
    {
        perror("socket--listen");
        exit(errno);
    }
    puts("\nWaiting for incoming connections...");

    /*---forever... ---*/
    while (1)
    {
        struct sockaddr_in client_addr;
        int addrlen = sizeof(client_addr);

        /*---accept a connection (creating a data pipe)---*/
        clientfd = accept(sockfd, (struct sockaddr *)&client_addr, &addrlen);
        printf("\n IP ADDRESS:%s \n PORT NUMBER:%d \n", inet_ntoa(client_addr.sin_addr), port_num); // print ip and port
        while (1)
        {
            char buffer[MAXBUF] = "\0";
            int length = 0;
            int recv_size = recv(clientfd, buffer, MAXBUF, 0);
            for (int i = 0; buffer[i] != '\0'; i++) // uppercase a string
            {
                if (buffer[i] >= 'a' && buffer[i] <= 'z')
                {
                    buffer[i] = buffer[i] - 32;
                }
            }
            int condition = strcmp(buffer, exits);
            int date_cond = strcmp(buffer, date);
            // send date to client
            if (date_cond == 0)
            {
                time_t t;
                t = time(NULL);
                struct tm tm = *localtime(&t);
                char send_date[40] = "Current date and time is: ";
                int day = tm.tm_mday;
                int month = tm.tm_mon + 1;
                int year = tm.tm_year - 100;
                int hour = tm.tm_hour;
                char s_day[5];
                char s_month[5];
                char s_year[5];
                char s_hour[5];
                itoa(day, s_day, 10);
                itoa(month, s_month, 10);
                itoa(year, s_year, 10);
                itoa(hour, s_hour, 10);
                strcat(send_date, s_day);
                strcat(send_date, "-");
                strcat(send_date, s_month);
                strcat(send_date, "-");
                strcat(send_date, s_year);
                strcat(send_date, " ");
                strcat(send_date, s_hour);
                // send date
                send(clientfd, send_date, 256, 0);
            }
            // if exit server is prompt
            else if (condition == 0)
            {
                printf("\nterminating.....");
                break;
            }
            // else send data to client and print len
            else
            {
                send(clientfd, buffer, recv_size, 0);
                int length = strlen(buffer);
                printf("\n word length is:%d\n", length);
            }
        }
        printf("\nclient connection terminated");
        close(clientfd);
    }

    /*---clean up (should never get here!)---*/
    close(sockfd);
    WSACleanup();
    return 0;
}
