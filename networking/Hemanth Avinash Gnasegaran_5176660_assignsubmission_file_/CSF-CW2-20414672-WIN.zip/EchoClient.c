#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>

#define MAXBUF		256

int main(int argc , int MY_PORT , char *argv[] )
{

WSADATA wsa;

int err;
Err = WSAStartup(MAKEWORD(2,2), &wsa);
If (err != 0);
	return;

SOCKET s;
s = socket(AF_INET, SOCK_STREAM, 0);
if (s == INVALID_SOCKET) {
printf("Error code: %d\n", WSAGetLastError());
return;
}
MY_PORT = atoi(argv[1]);
struct sockaddr_in server;
server.sin_family = AF_INET;
server.sin_port = htons(MY_PORT);
server.sin_addr.s_addr = INADDR_ANY;

struct sockaddr_in server;
connect(s, (struct sockaddr *)&server, sizeof(server));

char message[256];

If( send(s, message, strlen(message, 0) < 0)
{
	printf("Insert 'exit client' to terminate\n");
}

char Server_Reply[256];
If( recv(s, Server_Reply, 256, 0) < 0)
{
	scanf("exit client\n");
	if(strcmp(bufferU, "exit client") == 0)
        {
            keepRunning = 0;
            printf("Disconnecting from the server.\n");
            exit(0);

}

close(s);
WSACleanup();
return 0;
}