#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include <string.h>
#include <ctype.h>
#include <time.h>

#define MY_PORT		8989
#define MAXBUF		256

int main(int argc , char *argv[])
{
	char exitser[]="exit server";
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    struct sockaddr_in self;
	char buffer[MAXBUF];

	time_t t = time(NULL);
    struct tm tm = *localtime(&t);
    int year = tm.tm_year - 100;
    int month = tm.tm_mon + 1;
	char monthName[4];
    int day = tm.tm_mday;
    int hour = tm.tm_hour;
    char s[100], s1[100], s2[100], s3[100];

	switch (month){ //asignning month names
		case 1:
			strcpy(monthName, "Jan");
        	break;
		
		case 2:
			strcpy(monthName, "Feb");
        	break;

		case 3:
			strcpy(monthName, "Mar");
        	break;

		case 4:
			strcpy(monthName, "Apr");
        	break;

		case 5:
			strcpy(monthName, "May");
        	break;

		case 6:
			strcpy(monthName, "Jun");
        	break;

		case 7:
			strcpy(monthName, "Jul");
        	break;

		case 8:
			strcpy(monthName, "Aug");
        	break;

		case 9:
			strcpy(monthName, "Sep");
        	break;

		case 10:
			strcpy(monthName, "Oct");
        	break;

		case 11:
			strcpy(monthName, "Nov");
        	break;

        case 12:
        	strcpy(monthName, "Dec");
        	break;
    }
	sprintf(s, "%d-%d-%d %d\r\n", day, month, year, hour);
	sprintf(s1, "%d\r\n", year + 2000);
	sprintf(s2, "%d\r\n", hour);
	sprintf(s3, "%d-%s-%d\r\n", day, monthName, year);

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

    printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/

    int PortNum; //my work
    printf("Networking 1>start server, Enter Port Number: ");
    scanf("%d", &PortNum);
    printf("Port Number targeted by the client's request are: %d\n", PortNum);

	self.sin_family = AF_INET;
	self.sin_port = htons(PortNum);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);

		printf("IP address of client is: %s\n", inet_ntoa(client_addr.sin_addr));
		
		int recv_size = recv(clientfd, buffer, MAXBUF, 0);

		if (recv_size == -1){
			break;
			shutdown(clientfd,2);
			}

		printf("the length of message is %d\n", recv_size); 

		if (strcmp(buffer, "exit server") == 0){
			break;
		}//end if for exit

		else if (strcmp(buffer, "date") == 0){
			send(clientfd, s, strlen(s), 0);
		}//end if 

		else if (strcmp(buffer, "date1") == 0){
			send(clientfd, s1, strlen(s1), 0);
		}//end if 

		else if (strcmp(buffer, "date2") == 0){
			send(clientfd, s2, strlen(s2), 0);
		}//end if 

		else if (strcmp(buffer, "date3") == 0){
			send(clientfd, s3, strlen(s3), 0);
		}//end if 

		else{
			for(int i=0; i<recv_size; i++){ //make input to be uppercase
				buffer[i]=toupper(buffer[i]);
			}
			send(clientfd, buffer, recv_size, 0);
		}//end else 
		memset(buffer, '\0', strlen(buffer)); //clear buffer

        while (recv_size != 0){ //after first input is done, go into a loop

            recv_size = recv(clientfd, buffer, MAXBUF, 0);

			if (recv_size == -1){
				break;
				shutdown(clientfd,2);
			}

			printf("the length of message is %d\n", recv_size);

			if (strcmp(buffer, "exit server") == 0){
				shutdown(clientfd,2);
				break;
			}//end if for exit

			else if (strcmp(buffer, "date") == 0){
				send(clientfd, s, strlen(s), 0);
				continue;
			}//end if

			else if (strcmp(buffer, "date1") == 0){
				send(clientfd, s1, strlen(s1), 0);
				continue;
			}//end if

			else if (strcmp(buffer, "date2") == 0){
				send(clientfd, s2, strlen(s2), 0);
				continue;
			}//end if

			else if (strcmp(buffer, "date3") == 0){
				send(clientfd, s3, strlen(s3), 0);
				continue;
			}//end if

			else{
		    	for(int i=0; i<recv_size; i++){
					buffer[i]=toupper(buffer[i]);
		    	}
            	send(clientfd, buffer, recv_size, 0);
			}//end else
			memset(buffer, '\0', strlen(buffer)); //clear buffer
        }
		/*---close connection---*/
		close(clientfd);
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
    WSACleanup();
	return 0;
}