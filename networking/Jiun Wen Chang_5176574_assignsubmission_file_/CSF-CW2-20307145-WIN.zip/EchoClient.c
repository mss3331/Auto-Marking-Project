#include<io.h>       //sorry sir, my echoclient can only run server2.exe, and even exit server
#include<stdio.h>	//wouldn't work properly as server will respond with an infinite loop
#include<winsock2.h> //or length of message = -1
#include <string.h>
#include <ctype.h>

#define MY_PORT		8989
#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd;
    struct sockaddr_in self;
	char buffer[MAXBUF];
	char serverRespond[MAXBUF];

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
    else{
    	printf("Initialised.\n");
	}

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}
	else {
    	printf("Socket created.\n");
	}

	/*---initialize address/port structure---*/
    //bzero(&self, sizeof(self));
	
    int PortNum; //Get Port Number
    printf("Networking 1>start server, Enter Port Number: ");
    scanf("%d", &PortNum);
	

	self.sin_family = AF_INET;
	self.sin_port = htons(PortNum);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = inet_addr("127.0.0.1");  

	/*-to connect-*/
    if ( connect(sockfd, (struct sockaddr *)&self, sizeof(self)) != 0){
		perror("Not able to connect");
		exit(errno);
	}
	else{
		puts("Successfully Conneted");
	}
	int i=0, c;
	/*---forever... ---*/
	while (1)
	{	//fill message with some text before sending
		printf("Client Message: ");
		fgets(buffer, MAXBUF, stdin);
		//scanf("%[^\n]s", buffer); //can't work

		if(send (sockfd, buffer, strlen(buffer), 0) <0){
			puts("Fail to send"); 
			return 1;
		}

		if (strncmp(buffer, "exit server", 11) == 0){
			printf("exit client\n");
			exit(0);
			break;
		}
		
		if (recv(sockfd, serverRespond, MAXBUF, 0) > 0){
			printf("%s\n", serverRespond); //print out server respond
		}
		else{
			puts("Fail to receive");
			return 1;
		}

		memset(buffer, '\0', strlen(buffer)); //intend to clear buffer
		memset(serverRespond, '\0', strlen(serverRespond));
		/*---close connection---*/
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
	exit(0);
    WSACleanup();
	return 0;
}