//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<string.h>
#include<winsock2.h>
#include<time.h>


#define MAXBUF 256

int main(int argc , char *argv[])
{
	time_t t = time(NULL);
	struct tm *tm = localtime(&t);

	struct date{
		int day;
		int month;
		int year;
		int hour;
	};
	
	struct date curdate;
	
	curdate.day = tm->tm_mday;
	curdate.month= tm->tm_mon+1; //add 1, because return value range is from 0-11
	curdate.year= tm->tm_year +1900; //return value is number of years since 1900, so add 1990 to get actual year, mod 100 to get last two value
	curdate.hour= tm->tm_hour;
	
	int curday=curdate.day;
	int curmonth=curdate.month;
	int curyear=curdate.year%100;
	int fourdigyear=curdate.year;
	int curhour=curdate.hour;
	
	char *month[12]={"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"}; //create a array of pointers (point to 'months' string)
	
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];
	
	int MY_PORT;
	
	printf("Networking 1>start server ");
	scanf("%d",&MY_PORT);

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");
		
		
	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);
		
		
	/*---accept a connection (creating a data pipe)---*/
	clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
	
	printf("Connection success...\nClient IP: %s\nPort: %d\n", inet_ntoa(client_addr.sin_addr), ntohs
                  (client_addr.sin_port));
	
	/*---forever... ---*/
	while(1)
	{	
		char buffer[MAXBUF];
		char temp[MAXBUF];
		char date[MAXBUF];
		
		for(;;){
					
			int recv_size = recv(clientfd, buffer, MAXBUF, 0);
			
			if(strcmp(buffer,"exit server")==0){	
				break;
			}
			
			for(int i=0;i<recv_size;i++){
				
				temp[i]=buffer[i]; //transfer char by char from buffer to temp arr
			}
			
			temp[recv_size]='\0'; //temp is use to store the buffer with a NULL terminator at the end
			
			//sprintf is used to store the formatted string inside the date arr
			// %02d specifier is used to make sure if single digit output, then give the output a 0, example 1 -> 01
			
			if(strncmp("date",temp,recv_size)==0){ //check the command if it is 'date'
				
				sprintf(date,"%02d-%02d-%02d %02d\r\n",curday,curmonth,curyear,curhour);
				
				send(clientfd, date, strlen(date), 0);
					
			}else if(strncmp("date2",temp,recv_size)==0){ //check the command if it is 'date2'
				
				sprintf(date,"%02d%\r\n",curhour);
				
				send(clientfd, date, strlen(date), 0);
				
			}else if(strncmp("date3",temp,recv_size)==0){ //check the command if it is 'date3'
				
				
				sprintf(date,"%02d-%s-%02d\r\n",curday,month[curmonth-1],curyear); 
				
				send(clientfd, date, strlen(date), 0);
				
				
			}else if(strncmp("date1",temp,recv_size)==0){ //check the command if it is 'date1'
				
				sprintf(date,"%d\r\n",fourdigyear);
				
				send(clientfd, date, strlen(date), 0);
				
				
			}else{ //if not a date command, then just uppercase and print it as usual
				
				for (int i=0; i< strlen(buffer); i++){
			
				if((buffer[i]>='a') && (buffer[i]<='z')){
					buffer[i] -= 32;
					}
				}	

				send(clientfd, buffer, recv_size, 0);
			
				for(int i=0; i<recv_size; i++){
					putchar(buffer[i]);
				
				}

				printf(" --message length: %d\n",recv_size);
			}
			
		}
		
		break;	
	}
	/*---close connection---*/
		close(clientfd);
		
	
	

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}

