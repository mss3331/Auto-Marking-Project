#include<io.h>
#include<stdio.h>
#include<string.h>
#include<winsock2.h>

#define MAXBUF 256


int main(int argc , char *argv[])
{
	WSADATA wsa;
	SOCKET s;
	struct sockaddr_in server;
	char message[MAXBUF] , buffer[MAXBUF];
	int recv_size;
	int port; //use to store the port that the client wants to connect to
	
	printf("Connect client to port>");
	scanf("%d",&port);
	
	// same first step procedure where we need to initialize the WINSOCK

	printf("\nInitialising Winsock...");
	if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
	{
		printf("Failed. Error Code : %d",WSAGetLastError());
		return 1;
	}
	
	printf("\nInitialised...\n");
	
	//Create a socket for the connection between client and server
	if((s = socket(AF_INET , SOCK_STREAM , 0 )) == INVALID_SOCKET)
	{
		printf("Could not create socket : %d" , WSAGetLastError());
	}

	printf("Client socket created...\n");
	
	
	server.sin_addr.s_addr = inet_addr("127.0.0.1");
	server.sin_family = AF_INET;
	server.sin_port = htons( port );
	
	// we do not need a listen part, as the server side will be listening to our packet (message)
	//Connect the socket we just created to the server
	if (connect(s , (struct sockaddr *)&server , sizeof(server)) < 0)
	{
		puts("connect error");
		return 1;
	}
	
	puts("Connected to server...");
	
	//Start to send the message packet to the server
	while(1){
		
		for(;;){
			
			printf("Client: ");
			scanf(" %[^\n]",message);
			
			if(strcmp(message,"exit client")==0){
				break;
			}
	
			if( send(s , message , strlen(message) , 0) < 0){
				
				puts("Send failed");
				return 1;
			}
			
	
			//Receive a reply (as buffer) from the server side
			if((recv_size = recv(s , buffer , MAXBUF , 0)) == SOCKET_ERROR){
				
				puts("recv failed");
			}

			//null terminator added at the back to make it as a complete string before printing
			
			buffer[recv_size] = '\0';
			printf("Server: %s\n",buffer);
			
		}
		
		break;
	}
	
		
	closesocket(s);
	WSACleanup();

	return 0;
	
	
}