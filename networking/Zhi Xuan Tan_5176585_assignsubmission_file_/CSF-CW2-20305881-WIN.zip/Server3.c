//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<string.h>
#include<winsock2.h>
#include<time.h>


#define MAXBUF 256

int main(int argc , char *argv[])
{
	//get the current time data
	time_t t = time(NULL);
	struct tm *tm = localtime(&t);
	
	//create a struct to process the fetched time data
	struct date{
		int day;
		int month;
		int year;
		int hour;
	};
	
	struct date curdate; //create a var which type is struct date
	
	//extract all the info from the time data and store it in the strcut date variable (curdate)
	curdate.day = tm->tm_mday;
	curdate.month= tm->tm_mon+1; //add 1, because return value range is from 0-11
	curdate.year= tm->tm_year +1900; //return value is number of years since 1900, so add 1990 to get actual year, mod 100 to get last two value
	curdate.hour= tm->tm_hour;
	
	//store the data in the struct to a int variable (for futher processing)
	int curday=curdate.day;
	int curmonth=curdate.month;
	int curyear=curdate.year%100; //we need the last two digit, so we use to modulo operator to obtain the last two digit
	int curhour=curdate.hour;
	
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];
	
	int MY_PORT;
	
	printf("Networking 1>start server ");
	scanf("%d",&MY_PORT);

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");
		
		
	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);
		
		
	/*---accept a connection (creating a data pipe)---*/
	clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
	
	printf("Connection success...\nClient IP: %s\nPort: %d\n", inet_ntoa(client_addr.sin_addr), ntohs
                  (client_addr.sin_port));
	
	/*---forever... ---*/
	while(1)
	{	
		char buffer[MAXBUF];
		char date[MAXBUF]; //date arr will store the info of the date respond
		
		for(;;){
					
			int recv_size = recv(clientfd, buffer, MAXBUF, 0);
			
			if(strcmp(buffer,"exit server")==0){	
				break;
			}
			
			if(strncmp("date",buffer,4)!=0){ //check whether the user request a 'date' command by using compare
				
				for (int i=0; i< strlen(buffer); i++){
			
				if((buffer[i]>='a') && (buffer[i]<='z')){
					buffer[i] -= 32;
					}
			}	
		
			send(clientfd, buffer, recv_size, 0);
			
			
			for(int i=0; i<recv_size; i++){
				putchar(buffer[i]);
				
			}

			printf(" --message length: %d\n",recv_size);
				
				
			}else{ //if user request date, respond by sending back the date as the packet
				
				sprintf(date,"%02d-%02d-%02d %02d\r\n",curday,curmonth,curyear,curhour);
				
				send(clientfd, date, strlen(date), 0);
				
			}
				
			
		}
		
		break;	
	}
	/*---close connection---*/
		close(clientfd);
		
	
	

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}

