//////////////////////////  Server.c ////////////////
/** by Ibraheem Haitham Abdulhameed Shanshal **/
/*server2*/

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>

//#define MY_PORT		8989   commented because we are not going to use it here
#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];
    int maxbuffer = MAXBUF; //an integer to take max buffer length (this is important for the exit server command to work)

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0) //to check for error
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/

	/** adding a function to take port address here **/
	int sel_port;
	printf("-Networking 1>start server "); // the line given to us in the instructions to take port number
	scanf("%d",&sel_port);                //getting the port number from the user(on the server side)
	self.sin_family = AF_INET;
	self.sin_port = htons(sel_port);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}

        puts("Waiting for incoming connections...");

        /*** by moving those lines outside the loop, the server will handle multiple requests***/
        struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		printf("IP address: %s\nPort number: %d\n" , inet_ntoa(client_addr.sin_addr) , ntohs(client_addr.sin_port));
	/*---forever... ---*/


	while(1)
        {

		send(clientfd, strupr(buffer), recv(clientfd, buffer, maxbuffer, 0), 0);
		printf("the length of the message is %d\n",strlen(buffer)); // to display the length of the message
		if(strcmp(buffer, "EXIT SERVER") == 0){ // exiting server statement, it is in capital letter because the message will be converted before it reaches here
                    exit (1);
                }
		buffer[strcspn(buffer, "\r\n")] = 0;
		//set memory of the buffer message to 0
		memset(buffer, 0, sizeof(buffer));


	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}
