#include <io.h>
#include <winsock2.h>
T#include <stdio.h>

#define MY_PORT port_number
#define MAXBUF 256

int main (int argc , char *argv[]){

    WSADATA wsa;
    SOCKET sockfd;

    struct sockaddr_in self;
	char buffer[MAXBUF];

	if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");
    printf("-Networking 1>start server %u \n", port_number);

    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

    self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);
	self.sin_addr.s_addr = INADDR_ANY;

    close(sockfd);
    WSACleanup();

}
