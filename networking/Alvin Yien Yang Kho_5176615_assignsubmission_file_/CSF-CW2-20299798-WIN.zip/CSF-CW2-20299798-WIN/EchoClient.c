#include<io.h>
#include<stdio.h>
#include<winsock2.h>


#define BUFFSIZE 1024

int main(int argc, char *argv[])
{
    WSADATA wsa;
    int sockfd = 0, readsize = 0;
    char recvbuff[BUFFSIZE], sendbuff[BUFFSIZE];
    struct sockaddr_in server;

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	server.sin_family = AF_INET;
	server.sin_port = htons(8989);	                                            // Host to Network Short (16-bit)
	server.sin_addr.s_addr = inet_addr("127.0.0.1");                            //IP to binary


    if( connect(sockfd, (struct sockaddr *)&server, sizeof(server)) < 0)
    {
       printf("\n Error : Connect Failed \n");                                  //if connection is not established
       return 1;
    }
    puts("Connection established.\n");                                          //indicate that server is connected

while(1)
    {   

        //get string to send from terminal
        printf("New Message To Echo: ");
        fgets(sendbuff,BUFFSIZE,stdin);
        
        if(sendbuff[0] == 10 ){
            printf("Sorry, you are trying to send an empty message\n");         //condition if user just enter without writing anything
            continue;  
        }else if (strcmp(sendbuff,"exit client\n") == 0)
        {
            printf("client exited. Thank you :D");
            break;
        }
        //send the message to server
        if( send(sockfd , sendbuff , strlen(sendbuff) , 0) < 0)                 //if message fails to send
        {
            puts("Send failed");
            return 1;
        }


        readsize = recv(sockfd, recvbuff, sizeof(recvbuff)-1,0);                //return message from server
        if( readsize > 0 )
        {
            recvbuff[readsize] = 0;
            printf("Message returned by server: %s\n",recvbuff);
        }
        else{
            break;
        }
        

    }

    if( readsize < 0)
    {
        printf("\n Server closed connection \n");
    } 

    close(sockfd);
    return 0;    
        
}