//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<time.h>


#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    struct sockaddr_in self;
	char buffer[MAXBUF];
    time_t tick;
    int MY_PORT;                                            //store port number
    char *p;                                                //store character to strtol
    tick=time(NULL);                                        //use to obtain time  
    struct tm lc = *localtime(&tick);                       //use to obtain time

    if (argc==1)
    {    
        printf("Port number is not entered!\n");    
        printf ("Enter port number:\n");                    //prompt for port number
        scanf ("%d",&MY_PORT);  
    }
        
    else if (argc>=2)
    {


        printf("Arguments have passed\n");
        for(int counter=1; counter<argc;counter++)
        {
            long conv = strtol(argv[counter], &p, 10);      //convert all argv to int form;

            if(conv=='\0')                                  //if character is compiled to int, no result is out except '\0'
            {
                continue;
            }
            else
            {
                MY_PORT=conv;                               //if argv is entered then this occurs.
            }
            
        }
    } 

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	/*---forever... ---*/
    while (1)
    {   struct sockaddr_in client_addr;
        int addrlen=sizeof(client_addr);

        /*--for clarity to know that connection has been established--*/
        clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
        if(clientfd < 0)
        {
            printf("[-]Error in connection.\n");
            exit(1);
        }
            printf("[+]Connected to Server.\n");                                                                //indicate that server is connected
            printf("ip address of client: %s\n",inet_ntoa(client_addr.sin_addr));                               //display ip address
            getsockname(sockfd, (struct sockaddr *)&client_addr, &addrlen);                                     //obtain accurate port number   
            printf("port number: %d\n",(int)ntohs(client_addr.sin_port));                                       //display port number
        for(;;)
        {
            int nBtr=recv(clientfd, buffer, MAXBUF, 0);                                                         // to obtain the number of data read
            buffer[nBtr] ='\0';
                if (strcmp(buffer,"date") == 0)                                                                 //print out date
                {
                    sprintf(buffer,"%d-%d-%d %d\r\n",lc.tm_mday,lc.tm_mon+1,lc.tm_year+1900-2000,lc.tm_hour);   //to print out date in the required format
                    send(clientfd,buffer, nBtr+7 ,0);                                                           //send back to server
                }
                else 
                {
                    for(int i=0; i<nBtr;i++)
                    {
                        buffer[i]=toupper(buffer[i]);
                    }

                    if (strcmp(buffer,"EXIT SERVER") == 0)                                                     //close if user type exit server;
                    {
                        printf("Server exit. Thank you");
                        break;

                    }
                    send(clientfd, buffer, nBtr ,0);                                                           //sending data back to client
                if(buffer[0] != 13)                                                                            //this condition must be set, to prevent program to print 
                {                                                                                              //the junk value which starts with ascii code 13
                    printf("length of message: %d\n",nBtr);
                }
                }


        }
        
        
        /*---close connection---*/
        close(clientfd);
    }
	/*---clean up (should never get here!)---*/
	close(sockfd);
    WSACleanup();
	return 0;
}

