//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<time.h>

#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    struct sockaddr_in self;
	char buffer[MAXBUF];
    time_t tick;

    int MY_PORT;
    char *p;
    tick=time(NULL);
    struct tm *lc = localtime(&tick);

    if (argc==1)
    {    
        printf("Port number is not entered!\n");    
        printf ("Enter port number:\n");                    //prompt for port number
        scanf ("%d",&MY_PORT);  
    }
        
    else if (argc>=2)
    {


        printf("Arguments have passed\n");
        for(int count=1; count<argc;count++)
        {
            long conv = strtol(argv[count], &p, 10);        //convert all argv to int form;

            if(conv=='\0')                                  //if character is compiled to int, no result is out except '\0'
            {
                continue;
            }
            else
            {
                MY_PORT=conv;                               //if argv is entered
            }
            
        }
    } 


    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	/*---forever... ---*/
    while (1)
    {   struct sockaddr_in client_addr;
        int addrlen=sizeof(client_addr);

        /*---accept a connection (creating a data pipe)---*/
        clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);

    if(clientfd < 0)
    {
         printf("Error in connection.\n");                                                                              //if connection is not established
         exit(1);
    }
        printf("Connected to Server.\n");                                                                               //indicate that server is connected
        printf("ip address of client: %s\n",inet_ntoa(client_addr.sin_addr));
        getsockname(sockfd, (struct sockaddr *)&client_addr, &addrlen);                                                 //obtain accurate port number   
        printf("port number: %d\n",(int)ntohs(client_addr.sin_port));                                                   //display port number

        for(;;)
        {
            int nBtr=recv(clientfd, buffer, MAXBUF, 0);                                                                 // to obtain the number of data read
            buffer[nBtr] ='\0';

                if (strcmp(buffer,"date") == 0)
                {
                    sprintf(buffer,"%d-%d-%d %d\r\n",lc->tm_mday,lc->tm_mon+1,lc->tm_year+1900-2000,lc->tm_hour);       //print in day,month,year and hour
                    send(clientfd,buffer, nBtr+7 ,0);
                }
                else if(strcmp(buffer,"date1") == 0)
                {
                    sprintf(buffer,"show year: %d\r\n",lc->tm_year+1900);                                               //print the year
                    send(clientfd,buffer, nBtr+10 ,0);
                }
                else if(strcmp(buffer,"date2") == 0)
                {
                    sprintf(buffer,"show hour: %d\r\n",lc->tm_hour);                                                    //print the hour back to user in 24 hour format
                    send(clientfd,buffer, nBtr+8 ,0);
                }
                else if(strcmp(buffer,"date3") == 0)
                {
                    strftime(buffer,MAXBUF,"%d-%b-%y\r\n",lc);                                                          //print the dat, month in words and year
                    send(clientfd,buffer, nBtr+5 ,0);                    
                }
                else 
                {
                for(int i=0; i<nBtr;i++)
                {
                    buffer[i]=toupper(buffer[i]);                                                                       //if not any of the above, do the original function,
                }                                                                                                       //which is to print upper case

                if (strcmp(buffer,"EXIT SERVER") == 0)
                {
                    printf("Process stop. Thank you");                                                                  //if exit server is prompt
                    break;

                }
                send(clientfd, buffer, nBtr ,0);
                if(buffer[0] != 13)                                                                                     //this condition must be set, to prevent program to print 
                {                                                                                                       //not important information
                    printf("length of message: %d\n",nBtr); 
                }

                }


        }
        
        
        /*---close connection---*/
        close(clientfd);
    }
	/*---clean up (should never get here!)---*/
	close(sockfd);
    WSACleanup();
	return 0;
}

