//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>


#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    struct sockaddr_in self;
	char buffer[MAXBUF];
    int MY_PORT;            //store port number
    char *p;                //store character to strtol


    if (argc==1)
    {    
        printf("Port number is not entered!\n");    
        printf ("Enter port number:\n");                    //prompt for port number
        scanf ("%d",&MY_PORT);  
    }
        
    else if (argc>=2)
    {

        for(int counter=1; counter<argc;counter++)
        {
            long conv = strtol(argv[counter], &p, 10);      //convert all argv to int form;

            if(conv=='\0')                                  //if character is compiled to int, no result is out except '\0'
            {
                continue;
            }
            else
            {
                MY_PORT=conv;                               //if argv is entered then this occurs.
            }
            
        }
    } 

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");
        

	/*---forever... ---*/
    while (1)
    {   struct sockaddr_in client_addr;
        int addrlen=sizeof(client_addr);

        /*--for clarity to know that connection has been established--*/
        clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
        if(clientfd < 0)
        {
            printf("[-]Error in connection.\n");                                        //if connection is not established
            exit(1);
        }
            printf("[+]Connected to Server.\n");                                        //indicate that server is connected
            printf("ip address of client: %s\n",inet_ntoa(client_addr.sin_addr));       //display ip address
            getsockname(sockfd, (struct sockaddr *)&client_addr, &addrlen);             //obtain accurate port number     
            printf("port number: %d\n",(int)ntohs(client_addr.sin_port));               //display port number
        for(;;)                                                                         //permanent loop to enable receive and send to happen till user type exit server
        {
            int nBtr = recv(clientfd,buffer,MAXBUF,0);                                  //int nBtr declared to get number of string
                buffer[nBtr] ='\0';                                                     // use to put null terminator after end of a string
                    for(int i=0; i<nBtr;i++)
                    {
                        buffer[i]=toupper(buffer[i]);                                   //to capitalise the letters in the string
                    }                       
                    if (strcmp(buffer,"EXIT SERVER") == 0)                              //close exe file if user type exit server
                    {
                        printf("Process stop. Thank you");
                        close(clientfd);
                        break;
                    }

            send(clientfd, buffer, nBtr ,0);                                    //sending data back to client
            if(buffer[0] != 13)                                                 //this condition must be set, to prevent program to print 
            {                                                                   //the junk value which starts with ascii code 13
                printf("length of message: %d\n",nBtr); 
            }
        }



        /*---close connection---*/
        close(clientfd);
    }
	/*---clean up (should never get here!)---*/
	close(sockfd);
    WSACleanup();
	return 0;
}

