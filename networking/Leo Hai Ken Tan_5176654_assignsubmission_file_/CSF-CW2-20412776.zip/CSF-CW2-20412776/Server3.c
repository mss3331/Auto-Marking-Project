#include <stdio.h>
#include <netdb.h>
#include <netinet/in.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <time.h>
#define MAX 80
#define PORT 8080
#define SA struct sockaddr

// Function designed for chat between client and server.
void func(int sockfd)
{
	char buff[MAX], client[MAX];

	// infinite loop for chat
	for (;;) {
		bzero(buff, MAX);

		// read the message from client and copy it in buffer
		read(sockfd, buff, sizeof(buff));

		int i = 0;
		char ch;

	// variables to store the date and time components
    int hours, minutes, seconds, day, month, year, years;
 
    // `time_t` is an arithmetic time type
    time_t now;
 
    // Obtain current time
    // `time()` returns the current time of the system as a `time_t` value
    time(&now);
 
    // localtime converts a `time_t` value to calendar time and
    // returns a pointer to a `tm` structure with its members
    // filled with the corresponding values
    struct tm *local = localtime(&now);
 
    hours = local->tm_hour;         // get hours since midnight (0-23)
    day = local->tm_mday;            // get day of month (1 to 31)
    month = local->tm_mon + 1;      // get month of year (0 to 11)
    year = local->tm_year + 1900;   // get year since 1900
    years = local->tm_year -100;

	while (buff[i])
	{
		client[i] = buff[i];
		i++;
	}
	// if msg contains "exit server" then server exit and chat ended.
	if (strncmp("exit server", buff, 11) == 0) {
		printf("Server Exit...\n");
		break;
	}

	//calculate string length
	char * b = buff;
	char * c = buff;
	int slen=0;
	while (*c != '\n') {
    	slen++;
		c++;
  	}
	printf("The string length is %d\n",slen);

	if (strncmp("date", buff, 4) == 0){
			if (hours < 10){
        		sprintf(buff,"%d-%d-%d 0%d\r\n",day,month,years,hours);
    		}
			else{
				sprintf(buff,"%d-%d-%d %d\r\n",day,month,years,hours);
			}
		}

	//convert buff to uppercase
	while(*b) 
    {
        *b = (*b >= 'a' && *b <= 'z') ? *b-32 : *b;
        b++;
    }

	//if msg contains date function prints date
	
		// and send that buffer to client
		write(sockfd, buff, sizeof(buff));

		b =NULL;
	}
}
// Driver function
int main()
{
	int sockfd, connfd, port;
    unsigned int * len;
	struct sockaddr_in servaddr, cli;

	// socket create and verification
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd == -1) {
		printf("socket creation failed...\n");
		exit(0);
	}
	else
		printf("Socket successfully created..\n");
	bzero(&servaddr, sizeof(servaddr));

	printf("Enter a port number :");
	scanf("%d",&port);

	// assign IP, PORT
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port = htons(port);

	// Binding newly created socket to given IP and verification
	if ((bind(sockfd, (SA*)&servaddr, sizeof(servaddr))) != 0) {
		printf("socket bind failed...\n");
		exit(0);
	}
	else
		printf("Socket successfully binded..\n");

	// Now server is ready to listen and verification
	if ((listen(sockfd, 5)) != 0) {
		printf("Listen failed...\n");
		exit(0);
	}
	else
		printf("Server listening..\n");
	unsigned int a = (sizeof(cli));
    len = &a;

	// Accept the data packet from client and verification
	connfd = accept(sockfd, (SA*)&cli, len);
	if (connfd < 0) {
		printf("server accept failed...\n");
		exit(0);
	}
	else
		printf("server accept the client...\n");

	//Display port number
	printf("Connected on port number %d\n", port);

	//Display IP adress
	printf("Connected on IP adress %s\n", inet_ntoa(cli.sin_addr));

	// Function for chatting between client and server
	func(connfd);

	// After chatting close the socket
	close(sockfd);

	len = NULL;
}
