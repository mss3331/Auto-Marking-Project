#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<ctype.h>
#include<string.h>

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET s;
    struct sockaddr_in server;
    char exitclient[] = "exit client";
    char message[256];
    char server_reply[256];

    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    s = socket(AF_INET, SOCK_STREAM, 0);
    if (s == INVALID_SOCKET)
    {
        printf("Error code: %d\n", WSAGetLastError());
        return 1;
    }

    server.sin_family = AF_INET;
    server.sin_port = htons(8989);
    server.sin_addr.s_addr = inet_addr("127.0.0.1");


    connect(s, (struct sockaddr *)&server, sizeof(server));
    printf("connected");
    while (1)
    {
        scanf(" %[^\n]",&message);
        if(strcmp (message, exitclient)==0)
        {
            break;
        }
        if (send(s, message, strlen(message), 0) < 0)
        {
            perror("Send");
            exit(errno);
        }

        if (recv(s, server_reply, 256, 0) < 0)
        {
            perror("receive");
            exit(errno);
        }
        printf("Message from server is : %s\n", server_reply);
        memset(server_reply,0,strlen(message));
    }
    close(s);
    printf("Client Disconnected");
    WSACleanup();
}



