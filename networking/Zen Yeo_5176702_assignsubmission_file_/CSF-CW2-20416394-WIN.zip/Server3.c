//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<ctype.h>
#include<string.h>
#include<time.h>
#define MAXBUF	256


int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    struct sockaddr_in self;
	char buffer[MAXBUF];
	char buffer2[MAXBUF];
	char exitserver[] = "EXIT SERVER";
	char date[] = "DATE";
    int portno = atoi(argv[1]);
    time_t rawtime;
    struct tm *info;

    time( &rawtime );
    info = localtime( &rawtime );
    printf("%i", portno);
    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(portno);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}

        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{
	    struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		char *clientip = inet_ntoa(client_addr.sin_addr);
		getsockname(sockfd, (struct sockaddr *)&client_addr, &addrlen);
		printf("Client port number: %d\n",ntohs(client_addr.sin_port));
		printf("Client IP: %s\n", clientip);

		while (1)
        {

            int recv_size = recv(clientfd, buffer, MAXBUF, 0);
            printf("%s\n", strupr(buffer));
            printf("Length of message: %d\n", recv_size);

            if (strcmp(buffer, exitserver) == 0)
            {
                close(clientfd);
                printf("Client closed\n");
                break;
            }
            if (strcmp(buffer, date) == 0) //checks for string if match date, then do the following
            {
                strftime(buffer, 256, "%d-%m-%y %H", info); //gets current time and copies it into buffer
                printf("%s\n", buffer);
                send(clientfd, buffer, strlen(buffer), 0); //sends with length of buffer instead of recv_size cos they def won't be the same size
                memset(buffer,0,strlen(buffer));
                recv_size = recv(clientfd, buffer, MAXBUF, 0); //again, prevents the second 'length of message' from being sent
                send(clientfd, buffer, recv_size, 0);
                continue; //continue, not break cos still want to receive commands
            }
            send(clientfd, buffer, recv_size, 0);
            //this block sends the newline and carriage return
            memset(buffer,0,strlen(buffer));
            recv_size = recv(clientfd, buffer, MAXBUF, 0);
            send(clientfd, buffer, recv_size, 0);
		/*---close connection---*/
        }
        //close(clientfd);
        //printf("Client closed\n");
	}
	/*---clean up (should never get here!)---*/
	close(sockfd);
    WSACleanup();
	return 0;
}




