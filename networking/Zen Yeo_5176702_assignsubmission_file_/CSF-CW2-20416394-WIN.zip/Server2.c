//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<ctype.h>
#include<string.h>
#define MAXBUF	256


int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    struct sockaddr_in self;
	char buffer[MAXBUF];
	char exitserver[12] = "EXIT SERVER"; //used uppercase bcos message will become uppercased after receiving
    int portno = atoi(argv[1]);
    int recv_size;

    printf("%i", portno);
    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(portno);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}

        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{
	    struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		char *clientip = inet_ntoa(client_addr.sin_addr);
		getsockname(sockfd, (struct sockaddr *)&client_addr, &addrlen);         //obtain accurate port number
		printf("Client port number: %d\n",ntohs(client_addr.sin_port)); //gets putty's port number
		printf("Client IP: %s\n", clientip);

		while (1) //keeps it going forever
        {
            recv_size = recv(clientfd, buffer, MAXBUF, 0); //stores size of message to be used later
            buffer[recv_size] = '\0';
            strupr(buffer); //uppercases the message to be sent back
            send(clientfd, buffer, recv_size, 0);
            printf("%s\n", buffer);
            printf("Length of message: %d\n", recv_size);

            if (strcmp(buffer, exitserver) == 0) //if message received is the same, then break out of while loop
            {
                break;
            }

            memset(buffer,0,strlen(buffer)); //empties the buffer otherwise previous characters get left over and are sent back
            recv_size = recv(clientfd, buffer, MAXBUF, 0); //this block prevents the second "message length" from being printed a second time
            send(clientfd, buffer, recv_size, 0);
		/*---close connection---*/
        }
        memset(buffer,0,strlen(buffer));
        close(clientfd);
        printf("Client closed\n");
	}
	/*---clean up (should never get here!)---*/
	close(sockfd);
    WSACleanup();
	return 0;
}





