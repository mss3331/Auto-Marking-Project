#include <stdio.h>  
#include <stdlib.h> 
#include <string.h> 
#include <winsock2.h>

#define MAXBUF 256

int main(int argc, char const *argv[])
{
    struct sockaddr_in server;
    struct hostent *serverhost;
    int serverfd, port = 8989, addrlen;
    char *server_ip;
    char buffer[MAXBUF];

    /* create socket */
    if ((serverfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror("Cannot create socket");
        exit(0);
    }

    printf("Socket created.\n");

    /* get the server's DNS entry */
    serverhost = gethostbyname(server_ip);

    if (serverhost == NULL)
    {
        fprintf(stderr, "No such host as %s\n", server_ip);
        exit(0);
    }

    /*---initialize address/port structure---*/
    server.sin_family = AF_INET;
    server.sin_port = htons(port);
    server.sin_addr.s_addr = inet_addr("127.0.0.1");
    

    /* create connection with server */
    if (connect(serverfd, (struct sockaddr *)&server, sizeof(server)) != 0)
    {
        perror("Cannot connect to server");
        exit(EXIT_FAILURE);
    }

    puts("Connected");

    /*---forever... ---*/
    while (1)
    {
        /* get input from user */
        printf("Enter message: ");
        scanf("%s", buffer);

        /*send message to server*/
        if (send(serverfd, buffer, strlen(buffer)+1, 0) < 0)
        {
            perror("Send failed");
            exit(EXIT_FAILURE);
        }

        /* read server response */
        char recv_size;

        recv_size = recv(serverfd, buffer, MAXBUF, 0);

        if (recv_size < 0)
        {
            perror("Recv failed.");
            exit(EXIT_FAILURE);
        }
        else if (strcmp(buffer, "exit client\r\n") == 0 || strcmp(buffer, "exit client\n") == 0 || strcmp(buffer, "exit client") == 0)
        {
            exit(0);
        }

        printf("Echo from server: %s\n", buffer);
    }
    
    close(serverfd);
    return 0;
}