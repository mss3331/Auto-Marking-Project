//////////////////////////  Server.c ////////////////

#include <io.h>
#include <stdio.h>
#include <winsock2.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <time.h>

#define MAXBUF 256

int main(int argc, char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd, clientfd, clientsoc[20], soc;
    struct sockaddr_in self, client_addr;
    int maxclient = 20, addrlen;
    char buffer[MAXBUF];

    fd_set readfds; // socket descriptor

    for (int i = 0; i < 20; i++)
    {
        clientsoc[i] = 0;
    }

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
    {
        printf("Failed. Error Code : %d", WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

    /*---create streaming socket---*/
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror("Socket");
        exit(errno);
    }

    printf("Socket created.\n");

    /*---initialize address/port structure---*/
    /* bzero(&self, sizeof(self));*/
    self.sin_family = AF_INET;
    self.sin_port = htons(atoi(argv[1])); // accept any port number
    self.sin_addr.s_addr = INADDR_ANY;

    /*---assign a port number to the socket---*/
    if (bind(sockfd, (struct sockaddr *)&self, sizeof(self)) != 0)
    {
        perror("socket--bind");
        exit(errno);
    }

    puts("Bind done");

    /*---make it a "listening socket"---*/
    if (listen(sockfd, 20) != 0)
    {
        perror("socket--listen");
        exit(errno);
    }

    puts("Waiting for incoming connections...");

    addrlen = sizeof(struct sockaddr_in);

    /*---forever... ---*/
    while (1)
    {
        FD_ZERO(&readfds); // clear socket

        FD_SET(sockfd, &readfds); // add sockfd

        for (int i = 0; i < maxclient; i++) // add child sockets
        {
            soc = clientsoc[i];
            if (soc > 0)
            {
                FD_SET(soc, &readfds);
            }
        }

        // wait for connection
        int connection = select(0, &readfds, NULL, NULL, NULL);

        if (connection == SOCKET_ERROR) // if socket error
        {
            printf("Connection failed.");
            exit(EXIT_FAILURE);
        }

        if (FD_ISSET(sockfd, &readfds)) // accept connection
        {
            if ((clientfd = accept(sockfd, (struct sockaddr *)&client_addr, (int *)&addrlen)) < 0) // if nothing, fail
            {
                perror("accept");
                exit(EXIT_FAILURE);
            }

            puts("\nNew connection");
            printf("IP address is: %s\n", inet_ntoa(client_addr.sin_addr));
            printf("Port number is: %d\n", ntohs(self.sin_port));

            for (int i = 1; i <= maxclient; i++)
            {
                if (clientsoc[i] == 0) // keep track of how many requests handled
                {
                    clientsoc[i] = clientfd;
                    printf("Request: %d\n", i);
                    break;
                }
            }
        }

        for (int i = 0; i < maxclient; i++)
        {
            soc = clientsoc[i];

            if (FD_ISSET(soc, &readfds))
            {
                getpeername(soc, (struct sockaddr *)&client_addr, (int *)&addrlen); // get client details

                int recv_size;

                recv_size = recv(soc, buffer, MAXBUF, 0); // get client input

                if (recv_size == 0) // if client disconnected
                {
                    printf("Disconnected.\n");

                    closesocket(soc);
                    clientsoc[i] = 0;
                }
                else // if not disconnected, continue to process the input
                {
                    time_t t;
                    t = time(NULL);
                    struct tm ctime = *localtime(&t); // get current date & time

                    if (strcmp(buffer, "exit server\r\n") == 0 || strcmp(buffer, "exit server\n") == 0 || strcmp(buffer, "exit server") == 0) // command for exit server
                    {
                        exit(0);
                    }
                    else if (strcmp(buffer, "date\r\n") == 0 || strcmp(buffer, "date\n") == 0 || strcmp(buffer, "date") == 0)
                    {
                        printf("Current Date and Time: %d-%d-%d %d\r\n", ctime.tm_mday, ctime.tm_mon + 1, (ctime.tm_year + 1900) % 100, ctime.tm_hour);
                    }
                    else if (strcmp(buffer, "date1\r\n") == 0 || strcmp(buffer, "date1\n") == 0 || strcmp(buffer, "date1") == 0)
                    {
                        printf("Current Date and Time: %d\r\n", ctime.tm_year + 1900);
                    }
                    else if (strcmp(buffer, "date2\r\n") == 0 || strcmp(buffer, "date2\n") == 0 || strcmp(buffer, "date2") == 0)
                    {
                        printf("Current Date and Time: %d\r\n", ctime.tm_hour);
                    }
                    else if (strcmp(buffer, "date3\r\n") == 0 || strcmp(buffer, "date3\n") == 0 || strcmp(buffer, "date3") == 0)
                    {
                        printf("Current Date and Time: %d", ctime.tm_mday);

                        switch (ctime.tm_mon + 1)
                        {
                            case 1:
                                printf("-Jan-");
                                break;
                            case 2:
                                printf("-Feb-");
                                break;
                            case 3:
                                printf("-Mar-");
                                break;
                            case 4:
                                printf("-Apr-");
                                break;
                            case 5:
                                printf("-May-");
                                break;
                            case 6:
                                printf("-June-");
                                break;
                            case 7:
                                printf("-July-");
                                break;
                            case 8:
                                printf("-Aug-");
                                break;
                            case 9:
                                printf("-Sep-");
                                break;
                            case 10:
                                printf("-Oct-");
                                break;
                            case 11:
                                printf("-Nov-");
                                break;
                            case 12:
                                printf("-Dec-");
                                break;
                        }
                        printf("%d\r\n", (ctime.tm_year + 1900) % 100);
                    }
                    else
                    {
                        // change input to uppercase
                        for (int i = 0; i < recv_size; i++)
                        {
                            buffer[i] = toupper(buffer[i]);
                        }

                        // get string length
                        int a = strlen(buffer) - 2; // don't count '\r\n'
                        printf("Length of message: %d\n", a);

                        send(soc, buffer, recv_size, 0);

                        /*---close connection---*/
                        close(clientfd);
                    }
                }
            }
        }
    }

    /*---clean up (should never get here!)---*/
    close(sockfd);
    WSACleanup();

    return 0;
}
