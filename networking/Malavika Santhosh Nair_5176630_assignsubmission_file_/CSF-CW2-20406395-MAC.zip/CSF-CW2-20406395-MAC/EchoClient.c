#include<io.h>
#include<stdio.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<string.h>

#define MY_PORT		8989
#define MAXBUF		256

int main(int argc , char *argv[])
{
    int sockfd;
    struct sockaddr_in self;
    char message[1000], reply[2000];

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if(sockfd == -1)

{
    printf("No socket created");
}
puts("Socket created");

self.sin_family = AF_INET;
self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
self.sin_addr.s_addr = INADDR_ANY;  




if (connect(sockfd , (struct sockaddr*)&self , sizeof(self)) < 0)
    {
        perror("Failed. Error code");
        return 1;
    }

    puts("Connected\n");

while(1)
    {
	memset(&reply, 0, sizeof(reply) );
        printf("Enter message : ");
        scanf("%s" , message);

        // Data sent to server
        if( send(sockfd , message , strlen(message) , 0) < 0)
        {
            puts("Send failed");
            return 1;
        }

        // Reply recieved from server
        if( recv(sockfd , reply , 2000 , 0) < 0)
        {
            puts("recv failed");
            break;
        }

        puts("Server reply :");
        puts(reply);
    
    }

    // Terminates client
    if( message == "exit client"){
        close(sockfd);
        return 0;
    }

    close(sockfd);
    return 0;
}

