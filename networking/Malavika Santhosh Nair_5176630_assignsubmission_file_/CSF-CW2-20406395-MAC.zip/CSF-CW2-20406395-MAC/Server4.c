//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<string.h>

#define MAXBUF	256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
		int valread;
	char buffer[MAXBUF];

	fd_set readfds;

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(12000);     // Host to Network Short (16-bit)
    self.sin_addr.s_addr = INADDR_ANY;
    self.sin_addr.s_addr = inet_addr("192.168.0.168");  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 ) //Bind the socket to local host port 12000
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 ) //implement maximum of 20 pending connections for socket
	{
		perror("socket--listen");
		exit(errno);
	}

        puts("Waiting for incoming connections..."); //accept the incoming connection

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		
		send(clientfd, buffer, recv(clientfd, buffer, MAXBUF, 0), 0);
		printf("The server received the data: %s \n", clientfd);

		/*---close connection---*/
		close(clientfd);
	}

    // Outputs in Uppercase
	int i;
	while(clientfd[i]) 
	{ 
		clientfd[i] = toupper(clientfd[i]);
     		i++;
   	}

	 // New socket added 
            for (i = 0; i < 20; i++)  
            {  
                //If position is empty 
                if( clientfd[i] == 0 )  
                {  
                    clientfd[i] = new_socket;  
                    printf("Adding to list of sockets as %d\n" , i);  
                         
                    break;  
                }  
            }  
          
             
        // Else its operation on another socket
        for (i = 0; i < 20; i++)  
        {  
            sd = clientfd[i];  
                 
            if (FD_ISSET( sd , &readfds))  
            {  
                // Checks if it was for closing , and reads the 
                // incoming message 
                if ((valread = read( sd , buffer, MAXBUF)) == 0)  
                {  
                    // In case of disconnection, details collected and printed
                    getpeername(sd , (struct sockaddr*)&address , \
                        (socklen_t*)&addrlen);  
                    printf("Host disconnected, ip %s , port %d \n" , 
                          inet_ntoa(self.sin_addr) , ntohs(self.sin_port));  
                         
                    // Closes the socket for the reuse of any available connection
                    close( sd );  
                    clientfd[i] = 0;  
                }  
                     
                // Returns the message 
                else 
                {  
                    // Sets the string terminating NULL 
                    buffer[valread] = '\0';  
                    send(sd , buffer , strlen(buffer) , 0 );  
                }  
            }  
        }    
          
	// Displays the IP Address of client
        char *IPbuffer;
        struct hostent *host_entry;
  
        // Retrieves host information
        checkHostEntry(host_entry);
    
        // Converts an Internet network into ASCII
        IPbuffer = inet_ntoa(*((struct in_addr*) host_entry->h_addr_list[0]));
  
        printf("Host IP: %s", IPbuffer);

        // Displays port number targeted by the client's request
        getsockname(sockfd, (struct sockaddr *)&address, &length);
        printf("Port number = %d \n", self.sin_port);

    // Displays Different Date and Time formats
        char currentDateTime[128], Year[128], Hour[128], Date[128];
        time_t t;
        struct tm* time;
        t = time(NULL);
        time = localtime(&t);
    
        strftime(currentDateTime, 128, "%d-%b-%Y %H", time);
        strftime(year, 128, "%Y", time);
        strftime(hour, 128, "%H", time);
        strftime(date, 128, "%d-%b-%Y", time);

         if(clientfd == "date"){
                printf("Current Date and Time: %s\n", currentDateTime);
            }
    
            {
            else(clientfd == "date1"){
                printf("Year: %s\n", Year);
            }

            else(clientfd == "date2"){
                printf("Hour: %s\n", Hour);
            }

            else(clientfd == "date3"){
                printf("Date: %s\n", Date);
            }

            break;
        }

    // Implement "exit server"
    if(clientfd == "exit server"){
        return 0;
    }


	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}

