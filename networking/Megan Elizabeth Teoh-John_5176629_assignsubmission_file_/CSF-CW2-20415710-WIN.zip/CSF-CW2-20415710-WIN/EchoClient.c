#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<time.h>

#define MAXBUF 256

int main(int argc , char *argv[])
{

    WSADATA wsa;
    int err;
    err = WSAStartup(MAKEWORD(2,2), &wsa);

    If (err != 0) //error checking
    return;

    SOCKET s
    s = socket(AF_INET, SOCK_STREAM, 0);
    if (s == INVALID_SOCKET)
    {
        printf("Error code: %d\n", WSAGetLastError());
        return;
    }

    Struct sockaddr_in server;

    server.sin_family + AF_INET;
    server.sin_port = htons(8989); 
    server.sin_addr + AF_INET;

	char buffer[MAXBUF]; //handle values from server

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0) //error checking
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 ) //(IP, TCP, SOCKET)
	{
		perror("Socket");
		exit(errno);
	}

     printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET; //ip adresss
	self.sin_port = htons(atoi(argv[1]));	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  //save address

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr; //transport address/port
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen); //client add -> client

        while( strncmp(buffer, "exit server",11) != 0) //while the buffer
        {
          int message = recv(clientfd, buffer, MAXBUF, 0);

          send(clientfd, strupr(buffer),message, 0);
        }

        /*---close connection---*/
		close(clientfd);
	
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
    WSACleanup();
	return 0;
}