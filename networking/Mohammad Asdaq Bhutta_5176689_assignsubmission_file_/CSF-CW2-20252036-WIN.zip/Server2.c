//////////////////////////  Server2.c ////////////////
#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<windows.h>
#include<string.h>
#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];

    int port_no=0;

    port_no=atoi(argv[3]);

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(port_no);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
        printf("Port number is: %d\n",port_no);                             //Prints port number
        printf("i.p adress is: %s\n",inet_ntoa(client_addr.sin_addr));      //Prints ip
		int recv_size;
        
        while(1)
        {
            memset(buffer,0,MAXBUF);                                        //Clears buffer
            recv_size=recv(clientfd, buffer, MAXBUF, 0);                    //Receives client message
            if(recv_size > 0)//If statement to avoid printing infinite loop
            {
                if(strcmp(buffer,"exit server")!=0) //Runs while user hasn't entered "exit server"
                {
                    if(buffer[0] != '\r')           //Prints as long as first character isn't carriage return
                    {
                        printf("Message entered by client: %s, the length of the message is %d \n",strupr(buffer),strlen(buffer)); //Prints message & num of characters of thr message
                    }
                send(clientfd, strupr(buffer),recv_size, 0); //Sending message back to client
                memset(buffer,0,MAXBUF);                     //Clears buffer so new string can be entered
                }
                else
                    break;
            }
            else
                break;  //Break out of loop when client exits without typing "exit server"
        }

		/*---close connection---*/
		close(clientfd);
        return 0;
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}

