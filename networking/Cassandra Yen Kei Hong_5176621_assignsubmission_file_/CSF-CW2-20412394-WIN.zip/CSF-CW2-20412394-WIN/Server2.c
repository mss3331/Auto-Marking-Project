//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>


#define MAXBUF		256

int main(int argc, char* argv[])
{
	WSADATA wsa;
	SOCKET sockfd, clientfd;
	struct sockaddr_in self;
	char buffer[MAXBUF];
	int nBytes;

	struct clients
	{
		int connected;
		SOCKET ss;
	};

	struct clients clients[10];


	int PORT_Input;
	if (argc == 2)
	{
		PORT_Input = atoi(argv[1]);
	}


	printf("\nInitialising Winsock...");
	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
	{
		printf("Failed. Error Code : %d", WSAGetLastError());
		return 1;
	}

	printf("Initialised.\n");

	/*---create streaming socket---*/
	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		perror("Socket");
		exit(errno);
	}

	printf("Socket created.\n");

	/*printf("Please enter port number\n");
	scanf("%d\n", uInput);*/

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;

	self.sin_port = htons(PORT_Input);	  // Host to Network Short (16-bit)

	self.sin_addr.s_addr = INADDR_ANY;



	/*---assign a port number to the socket---*/
	if (bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0)
	{
		perror("socket--bind");
		exit(errno);
	}

	puts("Bind done");

	/*---make it a "listening socket"---*/
	if (listen(sockfd, 20) != 0)
	{
		perror("socket--listen");
		exit(errno);
	}

	puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{
		struct sockaddr_in client_addr;
		int addrlen = sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);

		int clients_connected = 0;

		if (clientfd != INVALID_SOCKET)
		{

			clients[clients_connected].ss = clientfd;
			clients[clients_connected].connected = 1;

			clients_connected++;

		}


		printf("Client IP: %s\n", inet_ntoa(client_addr.sin_addr));
		printf("Client Port: %d\n", PORT_Input);

		nBytes = 1;
		int test;


		nBytes = recv(clientfd, buffer, MAXBUF, 0);


		if (strcmp(strupr(buffer), "EXIT SERVER") == 0) //Normalizing input
		{
			printf("Shutting down\n");
			shutdown(clientfd, SD_BOTH);
		}
		else
		{
			send(clientfd, strupr(buffer), nBytes, 0);

			printf("Input length: %d\n", strlen(buffer));

		}




		/*---close connection---*/
		close(clientfd);
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
	WSACleanup();
	return 0;
}

