#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>

#define MAXBUF		256

int main(int argc, char* argv[])
{
	WSADATA wsa;
	SOCKET sockfd, serverfd;
	struct sockaddr_in server;
	char buffer[MAXBUF];
	int nBytes;
	char serverReply[MAXBUF];


	int PORT_Input;
	if (argc == 2)
	{
		PORT_Input = atoi(argv[1]);
	}


	printf("\nInitialising Winsock...");
	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
	{
		printf("Failed. Error Code : %d", WSAGetLastError());
		return 1;
	}

	printf("Initialised.\n");

	/*---create streaming socket---*/
	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		perror("Socket");
		exit(errno);
	}

	printf("Socket created.\n");


	char* server_ip = "127.0.0.1";

	server.sin_family = AF_INET;
	server.sin_addr.s_addr = inet_addr(server_ip);
	server.sin_port = htons(PORT_Input);

	//Connect to server
	if (connect(sockfd, (struct sockaddr*)&server, sizeof(server)) < 0)
	{
		perror("Cannot connect to server\n");
		exit(errno);
	}
	else
	{
		printf("Succesfully connected to server\n");
	}

	char input[MAXBUF];
	scanf("%s", input);


	if (strcmp(strupr(input), "EXIT CLIENT") == 0) //Normalizing input
	{
		printf("Exiting client\n");
		exit;
	}
	else
	{
		struct sockaddr_in server_addr;
		int addrlen = sizeof(server_addr);

		/*---accept a connection (creating a data pipe)---*/
		serverfd = accept(sockfd, (struct sockaddr*)&server_addr, &addrlen);

		send(serverfd, input, strlen(input), 0);
		recv(serverfd, serverReply, MAXBUF, 0);
		printf("%s\n", serverReply);
	}

	/*---close connection---*/
	close(serverfd);

}