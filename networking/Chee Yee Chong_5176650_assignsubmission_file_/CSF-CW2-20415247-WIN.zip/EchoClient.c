#include<io.h>
#include<stdio.h>
#include<string.h>
#include<winsock2.h>

#define MAXBUF		256
#define PORTSIZE 10

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    struct sockaddr_in server;
	char operation[MAXBUF],response[MAXBUF];
	char newportnum[PORTSIZE];

	printf("Please enter prefered port number : ");
	gets(newportnum);

	int latest_port = atoi (newportnum);

    // TCP uses port 0 - 65535
	if(latest_port > 65535 && latest_port < 1)
	{
        printf("Error. Please enter valid port number.");
        exit(0);
	}


    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

    printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	server.sin_family = AF_INET;
	server.sin_port = htons(latest_port);
	server.sin_addr.s_addr = inet_addr("127.0.0.1");

	/*---connect socket to server---*/
    if (connect(sockfd, (struct sockaddr*)&server, sizeof(server)) < 0 )
	{
		printf("Failed to connect. Error Code : %d",WSAGetLastError());
		exit(errno);
	}

    puts("Connected to server.");

	/*---infinite send and receive tunnel... ---*/
	while (1)
	{
		//ask client for operation
		printf("\nEnter operation: ");
		gets(operation);

		//if operation match with "exit client", terminate
		if (strcmp(operation, "exit client") == 0)
		{
		break;
		}

		//send the operation to respective server
        if((send(sockfd, operation, strlen(operation), 0)) < 0)
		{
			printf("Failed to send operation. Error Code : %d",WSAGetLastError());
			exit(errno);
		}

		//accept response
		int Input = recv(sockfd, response, MAXBUF, 0);

		response[Input] = '\0';

		printf("Reply : %s\n", response);

	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
    WSACleanup();
	return 0;
}
