//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>

#define MY_PORT		8989
#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}

        puts("Waiting for incoming connections...");

	/*---forever... ---*/
while (1)
	{
        struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);
		int Input;//declaring the amount of input

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		//when clientfd exist, print it's  ip address and port number
		if(clientfd > 0)
        {

            printf("Client's IP Address: %s \n", inet_ntoa(client_addr.sin_addr));
            printf("Client requested Port Number: %d \n", ntohs(self.sin_port));

		}

		while(1){
            memset(buffer, 0, MAXBUF);//clear up the buffer char array
            Input = recv(clientfd, buffer, MAXBUF, 0);

            //declaring variables of time.h, to display the current time
            char buf[256] = {0};
            time_t taim = time(NULL);
            struct tm *date = localtime(&taim);

                //if client type "exit server", the connection end
                if(strcmp(buffer, "exit server") == 0)
                {
                    printf("connection closed");
                    break;
                }
                if(Input > 0)//when there's input, goes on
                {
                    if(strcmp(buffer, "date") == 0)//when user type "date" display dd-mm-yy hh to client
                    {
                        strftime(buf,256,"%d-%m-%y  %H",date);
                        printf("%s\n",buf);
                        send(clientfd, buf, strlen(buf), 0);
                        memset(buf,NULL,strlen(buf));
                    }
                    if(strcmp(buffer, "date1") == 0)//when user type "date1" display yyyy to client
                    {
                        strftime(buf,256,"%Y",date);
                        printf("%s\n",buf);
                        send(clientfd, buf, strlen(buf), 0);
                        memset(buf,NULL,strlen(buf));
                    }
                    if(strcmp(buffer, "date2") == 0)//when user type "date2" display hh to client
                    {
                        strftime(buf,256,"%H",date);
                        printf("%s\n",buf);
                        send(clientfd, buf, strlen(buf), 0);
                        memset(buf,NULL,strlen(buf));
                    }
                    if(strcmp(buffer, "date3") == 0)//when user type "date3" display dd-Mon-yy to client
                    {
                        strftime(buf,256,"%d-%b-%y ",date);
                        printf("%s\n",buf);
                        send(clientfd, buf, strlen(buf), 0);
                        memset(buf,NULL,strlen(buf));
                    }
                    if(buffer[0] != 13)//print the input and input's length to server
                    {
                        printf("Input: %s\t\t",buffer);
                        printf("Input length: %d\n", strlen(buffer));
                    }
                    //when the input isnt date or date123, send the uppercase input to client
                     if(strcmp(buffer,"date") != 0 && strcmp(buffer,"date1") != 0 && strcmp(buffer,"date2") != 0 && strcmp(buffer,"date3") != 0)
                    {
                        send(clientfd, strupr(buffer), Input, 0);
                    }
                }
                else
                    break;
		}
		/*---close connection---*/
		char end[14]="connection end";// display "connection end" to client when the connection end
		send(clientfd, end, strlen(end), 0);
		close(clientfd);
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}

