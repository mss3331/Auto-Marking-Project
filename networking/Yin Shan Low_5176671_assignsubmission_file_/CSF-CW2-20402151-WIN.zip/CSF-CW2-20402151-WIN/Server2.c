//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>

		
#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    struct sockaddr_in self;
	char buffer[MAXBUF];
	unsigned short MY_PORT;
	
	// if the string input is more than 4 then print error and exit
	if(argc != 4){
		printf("error");
		exit(1);
	}

    // set my port to the 4th string enter in the command prompt 
	// example >Server4 start server 8989
	// the port number will be the 8989 which is the 4th string enter
	sscanf(argv[3],"%d", &MY_PORT);
	
    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY; 
  
	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

    struct sockaddr_in client_addr;
	int addrlen=sizeof(client_addr);
	// move the accept out of the while loop so that the input and output will print in a loop until we enter 'exit server'
	clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
	// find the client port number
	int client_port=ntohs(client_addr.sin_port);
	printf("\nIP address of client: %s \nPort number client request: %d\n", inet_ntoa(client_addr.sin_addr), client_port);	
	while (1)
	{	
		// make sure the buffer is always empty to start a new loop
		memset(buffer, 0, MAXBUF);
		
		int recv_size = recv(clientfd, buffer, MAXBUF, 0);
		
		//avoid printing the \r and \n as the junk value
		if(buffer[0] == '\r'||buffer[0] == '\n')
			continue;
		
		// if the recv_size is smaller than the MAXBUF then set the buffer to '\0' to prevent printing junk value
		if(recv_size < MAXBUF){
		buffer[recv_size] = '\0';
		buffer[strcspn(buffer, "\r")] = '\0';
		buffer[strcspn(buffer, "\n")] = '\0';
		}
		
		//if the buffer is exit server or EXIT SERVER then proceed to exit the server
		if(strncmp(buffer, "exit server", 11) == 0 ||strncmp(buffer, "EXIT SERVER", 11) == 0 ){
            close(clientfd);
            printf("[-]Disconnected from server.\n");
			exit(1);
		}
		else{
		printf("\nUppercase:%s\n", strupr(buffer));
		printf("Length:%d\n",strlen(buffer));
		}
		send(clientfd, buffer, strlen(buffer), 0);
    	
	}    
		
	

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}