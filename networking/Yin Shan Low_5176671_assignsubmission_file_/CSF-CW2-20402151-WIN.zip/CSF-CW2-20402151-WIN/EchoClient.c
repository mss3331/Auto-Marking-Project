//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>

#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
	SOCKET sockfd;
    struct sockaddr_in self;
	char buffer[MAXBUF];
	char server_reply[MAXBUF];
	unsigned short MY_PORT;
	
	printf("Enter the port number: ");
	scanf("%d", &MY_PORT);

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");
		

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  
	self.sin_addr.s_addr = inet_addr("127.0.0.1");  

	// establish connection
    if ( connect(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("Connection error");
		exit(errno);
	}

        puts("Connected");

	/*---forever... ---*/
	while (1)
	{
	    memset(buffer, 0, MAXBUF);// set the buffer empty to prevent external output respond
	    memset(server_reply, 0, MAXBUF);// set the server_reply empty to prevent external output respond-junk value
		
		fgets(buffer, MAXBUF,stdin);//get the client input
		
		// in case if there is \r and \n just countinue
		if(buffer[0] == '\r'||buffer[0] == '\n') 
			continue;

		//if exit client is enter then exit
		if(strncmp(buffer, "exit client", 10) == 0 ||strncmp(buffer, "EXIT CLIENT", 10) == 0 ){
            break;
            printf("[-]Disconnected from server.\n");
			exit(1);
		}
		//if there is no 'exit client' enter then continue to send input to server and give respond 
		else{
		
		send(sockfd, buffer, MAXBUF-1, 0);
		
		recv(sockfd, server_reply, MAXBUF, 0);
		
		puts(server_reply);
		}
		
	}

	// close 
	close(sockfd);
        WSACleanup();
	return 0;
}
