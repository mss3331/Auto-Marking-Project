#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<ctype.h>

#define MY_PORT		8989
#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);
	self.sin_addr.s_addr = INADDR_ANY;

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);

    int result;		//store the output of string comparison later either equal '0' or not equal'1'

	while (1) //enable multiple inputs
	{
		recv(clientfd, buffer, MAXBUF, 0);		//receive input from client 
 		
		result = strcmp(buffer,"\r\n");			//compare the string buffer with \r which is the carriage return character, if equal result will be '0' or else it will be '1' 

		if(result==0)							//if result are equal then do nothing 
		{
			/*Do Nothing*/	
		}

		else 									//after comparison if result not equal then do the following instructions
		{
			
			printf("IP address: %s\n",inet_ntoa(client_addr.sin_addr));  //print out the ip address value on server side 
			printf("The Port Number is %d\n",ntohs(client_addr.sin_port)); //print out the port number on server side 
			printf("The Length Of the String %d\n",strlen(buffer));	//print out the length of the string on server side 

			strupr(buffer);  //capatilise string in buffer 

       			send(clientfd, buffer, strlen(buffer), 0); //send the modified string back to client 
		
			memset(buffer, '\0', sizeof(buffer)); //reset the string buffer back to null
			
		}
		
	}
		/*---close connection---*/
		close(clientfd);
	
                   

	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}