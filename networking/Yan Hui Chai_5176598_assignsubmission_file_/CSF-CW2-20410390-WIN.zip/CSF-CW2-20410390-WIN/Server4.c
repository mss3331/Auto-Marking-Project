#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<ctype.h>
#include<time.h>

#define MY_PORT     8989
#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);
	self.sin_addr.s_addr = INADDR_ANY;

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		
	time_t z;
    struct tm *mytime;

    int result;
	int t; //Date
	int a; //Date1
	int b; //Date2
	int c; //Date3
    int n; //variable for null in receive
	int l; //variable for ERROR
    
	while (1)
	{

		n=recv(clientfd, buffer, MAXBUF, 0); //declare n as input receive from client
		buffer[n]='\0'; //set array n in buffer to null
		
		result = strcmp(buffer,"\r\n"); //strcmp to compare the string buffer with \r which is the carriage return character, if equal result with be '0' or else it will be '1' 
		
		t=strcmp(strupr(buffer),"DATE"); //strcmp to compare if the string enter is "DATE" strupr to capitalise user input so it will work even when user enter "date" if comparison equal result with be '0' or else it will be '1'
		
		a=strcmp(strupr(buffer),"DATE1"); //strcmp to compare if the string enter is "DATE1" strupr to capitalise user input so it will work even when user enter "date1" if comparison equal result with be '0' or else it will be '1'

		b=strcmp(strupr(buffer),"DATE2"); //strcmp to compare if the string enter is "DATE2" strupr to capitalise user input so it will work even when user enter "date2" if comparison equal result with be '0' or else it will be '1'

		c=strcmp(strupr(buffer),"DATE3"); //strcmp to compare if the string enter is "DATE3" strupr to capitalise user input so it will work even when user enter "date3" if comparison equal result with be '0' or else it will be '1'

        l=memcmp(strupr(buffer), "TIME ",5); //memcmp to compare if the string enter is "TIME(space)" strupr to capitalise user input so it will work even when user enter "time(space)" if comparison equal result with be '0' or else it will be '1'
		
		if(result==0) //after comparison if result are equal then do nothing 
		{
			/*Do Nothing*/	
		}

		else if(t==0) //if user input "DATE" comparison will be equal, therefore the following instructions will be carried out
		{
		time_t current_time = time(NULL);
        time_t val=1;
       	struct tm *tm = localtime(&current_time); //function to obtain the time on your device 
		sprintf( buffer,"Current Date and Time %d-%d-%d %02d\n",tm->tm_mday,(tm->tm_mon+1),(tm->tm_year + 1900),tm->tm_hour ); //to print out the date and time on the client side 
		send(clientfd, buffer, strlen(buffer), 0); //to send back the modified string to client 
		memset(buffer, '\0', sizeof(buffer)); //to reset the string buffer back to null
		}	
		

		else if(a==0) //if user input "DATE1" comparison will be equal, therefore the following instructions will be carried out 
		{
		time_t current_time = time(NULL);
        time_t val=1;
       	struct tm *tm = localtime(&current_time); //function to obtain the time on your device 
		sprintf( buffer,"Year %d\n",(tm->tm_year + 1900)); //to print out the date and time on the client side 
		send(clientfd, buffer, strlen(buffer), 0); //to send back the modified string to client 
		memset(buffer, '\0', sizeof(buffer)); //to reset the string buffer back to null
		}	
		
		
		else if(b==0) //if user input "DATE2" comparison will be equal, therefore the following instructions will be carried out 
		{
        time_t current_time = time(NULL);
        time_t val=1;
       	struct tm *tm = localtime(&current_time); //function to obtain the time on your device 
		sprintf( buffer,"Current Time %02d\n",tm->tm_hour ); //to print out the date and time on the client side 
		send(clientfd, buffer, strlen(buffer), 0); //to send back the modified string to client 
		memset(buffer, '\0', sizeof(buffer)); //to reset the string buffer back to null
		}	
		
		
		else if(c==0) //if user input "DATE3" comparison will be equal, therefore the following instructions will be carried out 
		{
		time_t current_time = time(NULL);
       	struct tm *tm = localtime(&current_time); //function to obtain the time on your device 
    
        
        const char* months[12]={"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
        int i=tm->tm_mday-1;
		sprintf ( buffer,"Current Date and Time %02d-%s-%d\n",(tm->tm_mon+1),months[i],(tm->tm_year + 1900)); //to print out the date and time on the client side 
		send(clientfd, buffer, strlen(buffer), 0); //to send back the modified string to client 
		memset(buffer, '\0', sizeof(buffer)); //to reset the string buffer back to null
        }
		else if(l==0) //if user input "TIME(space)" comparison will be equal, therefore the following instructions will be carried out   
		{
			snprintf(buffer,7,"ERROR"); //to print out "ERROR" when user enter "TIME(space)"
			send(clientfd, buffer, strlen(buffer), 0); //to send back the modified string to client 
			memset(buffer, '\0', sizeof(buffer)); //to reset the string buffer back to null
		}
		
		else
		{
			
			printf("IP address: %s\n",inet_ntoa(client_addr.sin_addr)); //to print out the ip address value in the server side
			printf("The Port Number is %d\n",ntohs(client_addr.sin_port)); //to print out the port number in the server side
			printf("The Length Of the String %d\n",strlen(buffer)); //to print out the length of the string in the server side (strlen is a function to determine the length of the string)

			strupr(buffer); //strupr to capatilise string in buffer

       	    send(clientfd, buffer, strlen(buffer), 0); //to send back the modified string to client 
				
			memset(buffer, '\0', sizeof(buffer)); //to reset the string buffer back to null
			
		}
	
		
		/*---close connection---*/
    	close(clientfd);
	}
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}