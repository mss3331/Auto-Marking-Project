#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<ctype.h>

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd ;
    struct sockaddr_in self;
	
	

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
     sockfd = socket(AF_INET, SOCK_STREAM, 0);
     if ( sockfd==INVALID_SOCKET) 
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	self.sin_family = AF_INET;
	self.sin_port = htons(8989);
	self.sin_addr.s_addr =  inet_addr("127.0.0.1");

	/*client connect*/
    	if(connect(sockfd,(struct sockaddr*)&self,sizeof(self))<0)
	{
	      printf("Client connection failed\n");
	      return -1;
	}

	
	/*---forever... ---*/
     char msg[256];
	 char serre[256];
	 int n;
	 int x;

	while (1)
    { 
	       printf("*Client side*\n");
	       printf("Type "exit client" to terminate\n");
	       printf("Enter the message: ");
	       fgets(msg,256,stdin); //to get the string input from user
           msg[strlen(msg)-1]='\0'; //set the array msg back to null

	       x=strcmp(strupr(msg),"EXIT CLIENT");  //strcmp to compare if the string enter is "EXIT CLIENT" strupr to capitalise user input so it will work even when user enter "exit client" if comparison equal result with be '0' or else it will be '1'

	       if(x==0) //if user input "EXIT CLIENT" comparison will be equal, therefore the following instructions will be carried out which is ending the program
	       { 
	           close(sockfd);
         	   WSACleanup();
               return 0;	
	       }

	       else
	       {
	         if (send(sockfd, msg,strlen(msg),0)<0) //for error checking and send is to send string to server
	         {
		      printf("Error Sending\n"); //if less than 0 print out error meassage
	         }
	       }
	         if((n=recv(sockfd,serre, 256, 0))<0) //for error checking and receive string server reply from server
	         {
		     printf("Error Receiving\n");
	         }
	          serre[n]='\0'; //set array serre to null
	          printf("*Server side*\n"); 
	          printf("From Server: %s\n",serre); //print server reply 
	}
}