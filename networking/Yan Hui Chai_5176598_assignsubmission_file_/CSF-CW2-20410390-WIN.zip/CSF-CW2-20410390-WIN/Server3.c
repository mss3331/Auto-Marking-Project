#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<ctype.h>
#include<time.h>

#define MY_PORT		8989
#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);
	self.sin_addr.s_addr = INADDR_ANY;

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);

    int result; //variable for result used to store the output of string comparison later either equal '0' or not equal'1'
	int t; //variable for time function 

	while (1) //enable multiple inputs
	{

		recv(clientfd, buffer, MAXBUF, 0);	//receive input from client 

		result = strcmp(buffer,"\r\n");	//compare the string buffer with \r which is the carriage return character, if equal result with be '0' or else it will be '1' 
		
		t= strcmp(strupr(buffer),"DATE"); //compare if the string entered is "DATE" 
                                          //strupr to capitalise user input so it will work even when user enter "date" if comparison equal result will be '0' else will be '1'
		
		
		if(result==0) //after comparison if result are equal then do nothing 
		{
			/*Do Nothing*/	
		}

		else if(t==0) //if user input "DATE" the following instructions will be carried out
		{
		
		time_t current_time = time(NULL);
        time_t val=1;
       	struct tm *tm = localtime(&current_time); //function to obtain the time on your device 
		sprintf( buffer,"Current Date and Time %d-%d-%d %02d\n",tm->tm_mday,(tm->tm_mon+1),(tm->tm_year + 1900),tm->tm_hour ); //to print out the date and time on the client side 
		send(clientfd, buffer, strlen(buffer), 0); //to send back the modified string to client 
		memset(buffer, '\0', sizeof(buffer)); //to reset the string buffer back to null
		}	

		else // if result not equal then do the following instructions
		{
			
			printf("IP address: %s\n",inet_ntoa(client_addr.sin_addr)); //print out the ip address value on server side
			printf("The Port Number is %d\n",ntohs(client_addr.sin_port)); //print out the port number on server side
			printf("The Length Of the String %d\n",strlen(buffer)); //print out the length of the string on server side 

			strupr(buffer); //capatilise string in buffer 


       	    send(clientfd, buffer, strlen(buffer), 0); //to send the modified string back to client 
				
			memset(buffer, '\0', sizeof(buffer)); //reset the string buffer back to null
			
		}
	
		
		/*---close connection---*/
    	close(clientfd);
	}
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}
