/////////////////////////  EchoClient.c ////////////////

#include<io.h>
#include<stdio.h>
#include<string.h>
#include<winsock2.h>

#define MAXBUF		256

int main(int argc , char *argv[])
{
    char MY_PORT[6];
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    struct sockaddr_in server;
	char userInput[MAXBUF], server_reply[MAXBUF];

	printf("Enter port number: ");
	gets(MY_PORT);

	int port = atoi(MY_PORT);

	if (port > 65535 || port < 0){
        printf("Port does not exist, terminating program...");
        exit(0);
	}

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize server address/port structure---*/
	server.sin_family = AF_INET;
	server.sin_port = htons(port);
	server.sin_addr.s_addr = inet_addr("127.0.0.1");

	/*---connect socket to server---*/
    if (connect(sockfd, (struct sockaddr*)&server, sizeof(server)) < 0 )
	{
		printf("Connection failed. Error Code: %d",WSAGetLastError());
		exit(errno);
	}

    puts("Connected to server.");

	/*---infinite send and receive tunnel... ---*/
	while (1)
	{
		printf("\nEnter message: ");
		gets(userInput);

        if(strcmp(userInput, "exit client")==0){
            break;
        }

		if((send(sockfd, userInput, strlen(userInput), 0)) < 0)
		{
			printf("Failed sending. Error Code : %d",WSAGetLastError());
			exit(errno);
		}

		int recvsize = recv(sockfd, server_reply, MAXBUF, 0);
		server_reply[recvsize] = '\0';
		printf("Server reply: %s\n", server_reply);

	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
    WSACleanup();
	return 0;
}
