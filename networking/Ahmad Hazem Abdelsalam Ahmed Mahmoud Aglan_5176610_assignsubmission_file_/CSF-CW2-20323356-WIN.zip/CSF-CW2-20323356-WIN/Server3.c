//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include <string.h>
#include <time.h>

#define MY_PORT		8989
#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];
	int portnumber;
	int j;
	int length = 0;

    time_t i;
    struct tm *tmp ;//Structure containing a calendar date and time broken down into its components.
    char timenow[MAXBUF];
    time( &i );
    int h;

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

    portnumber = atoi(argv[3]);

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(portnumber);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}

        puts("Waiting for incoming connections...");


	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);

        printf("The port number is:%s\n",portnumber);
        printf("The IP number is:%d\n",inet_ntoa(client_addr.sin_addr));

		while (1){

        memset(buffer, 0, MAXBUF);
        int recv_size = recv(clientfd, buffer, MAXBUF, 0);

        j = strcmp(buffer,"exit server");
        if(j==0){
            puts("\n terminated \n");
            exit(1);
        }

        h = strcmp(buffer,"date");
        if(h==0){
        tmp = localtime(&i);//getting the time now and storing it.
        strftime(timenow, sizeof(timenow), "%d-%m-%y %H\r\n", tmp);//using strftime to formate the time to the desired formate.

        send(clientfd, timenow, 11, 0);
        }

        else{
        if(buffer[0]!= '\r'){
        length = strlen(buffer);
        printf("The length of the message is %d \n",length);}
        printf("\n%s\n",strupr(buffer));
		send(clientfd, strupr(buffer), recv_size, 0);
		}}

		/*---close connection---*/
		close(clientfd);
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}

