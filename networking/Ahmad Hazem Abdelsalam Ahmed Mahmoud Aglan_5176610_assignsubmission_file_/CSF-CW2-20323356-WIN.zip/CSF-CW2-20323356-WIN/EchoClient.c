#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include <string.h>

int main(){
    WSADATA wsa;
    SOCKET socketf;
    int err;
    struct sockaddr_in self;
    char message[256];
    int port;

    printf("Input port number please:");//getting the port number from the user
    scanf("%d",&port);
    getchar();

    //initialise WinSock
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    //create socket
    socketf = socket(AF_INET, SOCK_STREAM, 0);

    //Assigning Addresses to said socket
    self.sin_family = AF_INET;
	self.sin_port = htons(port);
	self.sin_addr.s_addr = inet_addr("127.0.0.1");

    //connect to the server
	connect(socketf, (struct sockaddr *)&self, sizeof(self));

	while(1){
        gets(message);

        if(strcmp(message,"exit client")==0){// the code for exiting using strcmp to compare the strings
            printf("EXIT");
            exit(1);
        }

        send(socketf, message, strlen(message),0);//send
        recv(socketf, message, 256, 0);//receive
        puts(message);//printing what we received from the server

	}
    close(socketf);
    WSACleanup();
}
