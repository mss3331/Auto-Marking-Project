//////////////////////////  EchoClient.c 20307595  ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<windows.h>
#include<string.h>

#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF], userinput[MAXBUF];

	int MY_PORT;
	printf("Enter your port number: ");
	scanf("%d",&MY_PORT);

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = inet_addr("127.0.0.1");  

    /*---Connect to server---*/
	if (connect(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0) {
        printf("connection with the server failed...\n");
        exit(errno);
    }
    else
        printf("connected to the server..\n");


	/*---forever... ---*/
    printf("Enter 'exit client' to close client\n\n");
	while (1)
	{	
        printf("YOUR input: "); //Get our input
        gets(userinput);
        printf("\n");
      
        if(strlen(userinput) > 0)
        {
        
            int sendresult = send(sockfd, userinput, strlen(userinput) + 1, 0); //Send our input to Server
            if (sendresult != SOCKET_ERROR)
            {
             
                int bytesreceived = recv(sockfd, buffer, MAXBUF, 0); //Get reply from Server
                if (bytesreceived > 0)
                {
                    printf("SERVER reply: %s\n\n", buffer);
                    
                }
            }
            
        }
        
        if ((strncmp(userinput, "exit client", 10)) == 0) //Exit client (similar to Exit server)
        {
            close(sockfd);
            exit(errno);
        }
        memset(buffer, 0, sizeof(buffer)); //Reset buffer
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}

