//////////////////////////  Server3.c 20307595  ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<windows.h>
#include<string.h>
#include<time.h>

#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];

	int MY_PORT;
	printf("- Networking 1>start server ");
	scanf("%d",&MY_PORT);

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = htonl(INADDR_ANY);  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);
		time_t timetoday;
		struct tm * timeinfo;
		time(&timetoday);
		timeinfo = localtime(&timetoday);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		printf("Connection accepted\n");
		printf("IP ADDRESS: 127.0.0.1\n");
		printf("PORT NUMBER: %d", MY_PORT);

		for(int i=0;i>=0;i++){
		recv(clientfd, buffer, MAXBUF, 0);
		printf("\n\nThe length of the latest message is: %d", strlen(buffer));
		if (strncmp("date", buffer, MAXBUF) == 0)
		{
			strftime(buffer,MAXBUF,"%d-%m-%y %H",timeinfo); //date dd-mm-yy hh
		}
		if (strncmp("exit server", buffer, 11) == 0)
		exit(errno);
		else
		strupr(buffer);
		send(clientfd, buffer, MAXBUF, 0);
		memset(buffer, 0, sizeof(buffer));
		}

	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}