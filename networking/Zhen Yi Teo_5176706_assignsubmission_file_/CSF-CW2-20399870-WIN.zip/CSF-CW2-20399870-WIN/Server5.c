//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<time.h>  // for this task 4 time/date

#define MY_PORT		12000
#define MAXBUF		256





int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];
	int n;
	int i,j;
	time_t tick;
	char str[100];



    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;
	self.sin_addr.s_addr = inet_addr("127.0.0.1");
	self.sin_port = htons(12000);

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}

        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);


		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		printf("-Networking 1> start server %d\n", ntohs(self.sin_port));
		printf("The IP address of the client is: %s\n", inet_ntoa(client_addr.sin_addr));
        printf("The port number targeted by the client's request is: %d\n", (int) ntohs(client_addr.sin_port));


		send(clientfd, buffer, recv(clientfd, buffer, MAXBUF, 0), 0);


        n = read(clientfd,buffer,255);

        if  (strcmp(buffer,"date")==0){     //if client input "date"
        char buf[MAXBUF] = {0};
        time_t rawtime = time(NULL);
        struct tm *ptm = localtime(&rawtime);
        strftime(buf, MAXBUF, "\r\r\r\r%d-%m-%y %H", ptm); // time format dd-mm-yy hh in a single line using ascii \r
        send(clientfd,buf,30,0);                // send the time back to the client
       }

        else if  (strcmp(buffer,"date1") == 0){     //if client input "date1"
        char buf[MAXBUF] = {0};
        time_t rawtime = time(NULL);
        struct tm *ptm = localtime(&rawtime);
        strftime(buf, MAXBUF, "\r\r\r\r\r %Y" , ptm); // time format YYYY in a single line using ascii \r
        send(clientfd,buf,30,0);                // send the time back to the client
       }


       else if  (strcmp(buffer,"date2") == 0){     //if client input "date2"
        char buf[MAXBUF] = {0};
        time_t rawtime = time(NULL);
        struct tm *ptm = localtime(&rawtime);
        strftime(buf, MAXBUF, "\r\r\r\r\r   %H"  , ptm); // time format hh in a single line using ascii \r
        send(clientfd,buf,30,0);                // send the time back to the client
       }


       else if  (strcmp(buffer,"date3") == 0){     //if client input "date3"
        char buf[MAXBUF] = {0};
        time_t rawtime = time(NULL);
        struct tm *ptm = localtime(&rawtime);
        strftime(buf, MAXBUF, "\r\r\r\r\r%d-%b-%y", ptm); // time format dd-Mon-yy in a single line using ascii \r
        send(clientfd,buf,30,0);                // send the time back to the client
       }

        else if (strcmp(buffer,"exit server")==0){
            close(clientfd);
            close(sockfd);
         }


         else{
        for (i = 0; buffer[i]!='\0'; i++) {                //convert client msg to uppercase
         if(buffer[i] >= 'a' && buffer[i] <= 'z') {
         buffer[i] = buffer[i] - 32;
      }
        }
        for (j = 0; buffer[j] != '\0'; ++j);     //length of the message

        printf("Client Message:%s\n",buffer);
        printf("Length of the message input is: %d\n", j);

         }



		/*---close connection---*/
		close(clientfd);
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}
