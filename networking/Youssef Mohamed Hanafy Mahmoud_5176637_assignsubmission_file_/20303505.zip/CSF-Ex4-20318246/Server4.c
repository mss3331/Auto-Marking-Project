#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<ctype.h>
#include<string.h>
#include<time.h>
#include <windows.h>

#define MY_PORT		8989
#define MAXIMUMBUFFER	256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , client_fd;
    	struct sockaddr_in self;
	char buf[MAXIMUMBUFFER];
	int i,j ,temporary;// Counters for Loops and Temporary Variables 
	int num_of_bytes,a;
	struct tm *info;
    time_t rawtime ;
    int ctr=0;

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}

        puts("Waiting for incoming connections...");

	/*---forever... ---*/
    while (1){

        struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);

		char *ip = inet_ntoa(client_addr.sin_addr);

        while (1){
        time_t t;
        char *p;
        int len;
        struct tm *info;

        memset(buffer,0,sizeof(buffer));
        num_of_bytes = recv(client_fd, buf, MAXIMUMBUFFER, 0);
        ctr=0;
    if (strncmp(buf,"TIME",4)==0)
        {



                   // if TIME PST, TIME MST etc.....
                     time( &rawtime );
                     info = localtime( &rawtime );


                    if(strcmp(buf,"TIME")==0||strcmp(buf,"TIME GMT")==0)
                    info->tm_hour=(info->tm_hour+0)%24;


                    else if (strcmp(buf,"TIME PST")==0){
                    info->tm_hour=(info->tm_hour-8)%24;
                    }
                    else if (strcmp(buf,"TIME MST")==0){
                    info->tm_hour=(info->tm_hour-7)%24;
                    }
                    else if (strcmp(buf,"TIME CST")==0){
                    info->tm_hour=(info->tm_hour-6)%24;
                    }
                    else if (strcmp(buf,"TIME EST")==0){
                    info->tm_hour=(info->tm_hour-5)%24;
                    }
                    else if (strcmp(buf,"TIME CET")==0){
                    info->tm_hour=(info->tm_hour-1)%24;
                    }
                    else if (strcmp(buf,"TIME MSK")==0){
                    info->tm_hour=(info->tm_hour+3)%24;
                    }
                    else if (strcmp(buf,"TIME JST")==0){
                    info->tm_hour=(info->tm_hour+9)%24;
                    }
                    else if (strcmp(buf,"TIME AEST")==0){
                    info->tm_hour = (info->tm_hour+10)%24;
                    }
                    else
                    {
                    //send(clientfd, "ERROR" ,5 , 0);
                    ctr++;
                    }




                if (ctr==0){   // counter equals zero means timezone command can be executed
                    p = asctime(info);
                    len = strlen(p);
                    send(client_fd, p ,len , 0);
                }

                else
                    send(client_fd, "ERROR" ,5 , 0);



                }  // end if

        else
        {
        int length = strlen(buf)-1;
        if (buf[0]!='\r'&&buf[0]!='\n')
        {

        printf("\nIP address of the client : %s",ip);
        printf("\nPort number targeted by client's request : %d",client_addr.sin_port);

        printf("\nlength of the message sent was: %d\n",numbytes);


        for (i = 0 ; i < num_of_bytes; i++)
            {
            if (buf[i]!='\n')
            buf[i] =  toupper(buf[i]);
            }

      for (i = 0, j = length ; i < j; i++, j--)
            {
            temporary = buf[i];
            buf[i] = buf[j];
            buf[j] = temporary;
            }

        }  // end if statement

            send(client_fd,buf, num_of_bytes , 0);
        }  // end else statement

      //  memset(buf,0,sizeof(buf));
        memset(buf,0,num_of_bytes);

        }



		/*---close connection---*/

		close(client_fd);
    }




	/*---clean up (should never get here!)---*/
	close(sockfd);
    WSACleanup();

	return 0;
    }



//gcc Server4.c -o Server4 -lws2_32
