#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<ctype.h>
#include<string.h>
#include<time.h>
#include <windows.h>

#define MY_PORT		8989
#define MAXIMUMBUFFER	256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , client_fd;
    	struct sockaddr_in self;
	char buf[MAXIMUMBUFFER];
	int i,j ,temporary;// Counters for the loops and temporary variable for swapping
	int num_of_bytes,a;

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0) // Condition to check initialisation
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}

        puts("Waiting for incoming connections...");

	/*---forever... ---*/
    while (1){

        struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		client_fd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);

		char *ip = inet_ntoa(client_addr.sin_addr);

        while (1){

        time_t t;
        char *p;
        int len;

        memset(buf,0,sizeof(buf));

        num_of_bytes = recv(client_fd, buf, MAXIMUMBUFFER, 0);
        if (strncmp(buf,"DATE",4)==0){



            time(&t);
            p = ctime(&t);

            len= strlen(p);


            if(*(p+len-1)=='\n')
            *(p+len-1) = 0;



            strcat(p ,"-GMT\r\n");



            send(client_fd, p , 28 , 0);

        }
        else

        {
         int length=strlen(buf)-1;

        if (buf[0]!='\r'&&buf[0]!='\n')
        {

        printf("\nIP address of the client : %s",ip);
        printf("\nPort number targeted by client's request : %d",client_addr.sin_port);

        printf("\nlength of the message sent was: %d\n",numbytes);


        for (i = 0 ; i < num_of_bytes; i++)//Loop to change character to uppercase
            {
            if (buf[i]!='\n')
            buf[i] =  toupper(buf[i]);
            }

      for (i = 0, j = length ; i < j; i++, j--)//Loop for swapping
            {
            temporary = buf[i];
            buf[i] = buf[j];
            buf[j] = temporary;
            }
        }  // end if statement

            send(client_fd,buf, num_of_bytes , 0);

            memset(buf,0,num_of_bytes);
        }  // end else statement



        }

		/*---close connection---*/

		close(client_fd);

            }


	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();

	return 0;
    }


//gcc Server3.c -o Server3 -lws2_32
