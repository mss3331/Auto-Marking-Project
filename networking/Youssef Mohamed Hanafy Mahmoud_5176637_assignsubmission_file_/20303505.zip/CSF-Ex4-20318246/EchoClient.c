#include <winsock2.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <io.h>
#define MAX 80
#define PORT 8989
#define SA struct sockaddr



int main(int argc,char *argv[])
{
    int sockfd, connfd;
    struct sockaddr_in servaddr, cli;
    WSADATA wsa;

     printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

    // socket create and varification
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1) {
        printf("socket creation failed...\n");
        perror("socket");
        exit(errno);
    }
    else
        printf("Socket successfully created..\n");

    memset(&servaddr, 0 , sizeof(servaddr));

    // assign IP, PORT
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
    servaddr.sin_port = htons(PORT);

    // connect the client socket to server socket
    if (connect(sockfd, (SA*)&servaddr, sizeof(servaddr)) != 0) {
        printf("connection with the server failed...\n");
        exit(errno);
    }
    else
    {
        printf("connected to the server..\n");


    char buff[MAX];
    int n;
    for (;;)
        {
        memset(buff,0, sizeof(buff));
        printf("Enter the string : ");

        n = 0 ;

      while ((buff[n++] = getchar())!= '\n');



        int length = strlen(buff)-1;

        send(sockfd, buff, length ,0);

        char servreply[256];

        memset(servreply,0,256);

        recv(sockfd, servreply, 256 ,0);

        printf("From Server : %s\n", servreply);

        if ((strncmp(buff, "EXIT", 4)) == 0)
            {
            printf("Client Exit...\n");
            break;
            }
        }  // end for loop

    }
    // close the socket
    close(sockfd);

    //close(connfd);
    WSACleanup();
    return 0;
}
  //gcc EchoClient.c -o EchoClient -lws2_32
