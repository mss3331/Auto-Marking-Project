//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<ctype.h>
#include<string.h>

#define MY_PORT		8989
#define MAXIMUMBUFFER		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buf[MAXIMUMBUF];
	int i,j , temporary;//Counters for Loops and the temporary variable for swapping
	int number_of_bytes=0;
	int a;

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)//condition to check if startup is initialised or not
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}

        puts("Waiting for incoming connections...");

	/*---forever... ---*/
    while (1){

        struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);

		char *ip = inet_ntoa(client_addr.sin_addr);

        printf("\nIP address of the client : %s",ip);
        printf("\nPort number targeted by client's request : %d ",client_addr.sin_port);

        while (1){




        memset(buf,0,sizeof(buf));



        number_of_bytes = recv(clientfd, buf,MAXIMUMBUF, 0);


        int length=strlen(buf)-1;

       if (buf[0]!='\r'&&buf[0]!='\n')
            {

        printf("\nlength of the message sent was: %d\n",number_of_bytes);


            for (i = 0 ; i < number_of_bytes; i++)
                {
            if (buf[i]!='\n')
            buf[i] =  toupper(buf[i]);
                }

            for (i = 0, j = length; i < j; i++, j--)
                {
                temporary = buf[i];
                buf[i] = buf[j];
                buf[j] = temporary;
                }


            send(clientfd, buf,number_of_bytes, 0);

              memset(buf,0,number_of_bytes);

        }

        }

		/*---close connection---*/
		close(clientfd);


        }

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
    }

// gcc Server2.c -o Server2 -lws2_32
