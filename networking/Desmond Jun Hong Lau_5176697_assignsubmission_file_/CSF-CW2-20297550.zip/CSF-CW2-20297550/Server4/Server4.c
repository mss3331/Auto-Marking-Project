//////////////////////////  Server4.c ////////////////

#include<stdio.h>
#include<time.h>
#include<stdlib.h>
#include<string.h>
#include<winsock2.h>

#include<sys/types.h>

#define MY_PORT		8989
#define MAXBUF		256

int main(int argc , char *argv[])
{
    char server_message[256] = "You have reached the server!";

    //create the server socket
    int server_socket;
    server_socket = socket(AF_INET, SOCK_STREAM, 0);

    //define the server address
    struct sockaddr_in server_address;
    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(8001);
    server_address.sin_addr.s_addr = INADDR_ANY;

    //bind the socket to the specified IP and port
    bind(server_socket, (struct sockaddr*) &server_address, sizeof(server_address));

    listen(server_socket, 5);

    int client_socket;
    while(1){
            client_socket = accept(server_socket, NULL, NULL);
            send(client_socket, http_header,sizeof(http_header), 0);
            close(client_socket);
    }

    //send the message
    send(client_socket, server_message, sizeof(server_message), 0);

    //close the socket
    close(server_socket);

    FILE *html_data;
    html_data = fopen("index.html", "r")

    char response_data[1024];
    fgets(response_data, 1024, html_data)

    char http_header[2048] = "HTTP1.1 200 OK\r\n\n"
    strcat(http_header, response_data);

    char buff[MAX];
    int n;
    // infinite loop for chat
    for (;;) {
        bzero(buff, MAX);

        // read the message from client and copy it in buffer
        read(connfd, buff, sizeof(buff));
        // print buffer which contains the client contents
        printf("From client: %s\t To client : ", buff);
        bzero(buff, MAX);
        n = 0;
        // copy server message in the buffer
        while ((buff[n++] = getchar()) != '\n')
            ;

        // and send that buffer to client
        write(connfd, buff, sizeof(buff));

        // if message contains "exit server" then server exit and chat ended.
        if (strncmp("exit server", buff, 4) == 0) {
            printf("Server Exit...\n");
            break;
        }
    }

    int command;
    printf("Enter date format: ")
    scanf("%d", &command);
    printf("Date format = %d", command);



    while(command = date){
        time_t tm;
        time(&tm);
        printf("Default date = %s", ctime(&tm));
        getch();
        return 0;
    }

    while(command = date1){
        time_t s, val = 1;
        struct tm* current_time;

        s = time(NULL);

        current_time = localtime(&s);


        printf("Date format 1 = %d\n",(current_time->tm_year + 1900));

        return 0;
    }

    while(command = date2){
        time_t s, val = 1;
        struct tm* current_time;

        s = time(NULL);

        current_time = localtime(&s);

        printf("Date format 2 = %02d\n",
           current_time->tm_hour,

        return 0;
    }
    while(command = date3){
        time_t t;
        t = time(NULL);
        struct tm tm = *localtime(&t);
        int m;
        printf("Today's Date: %d ", tm.tm_mday);
        m = tm.tm_mon+1;

        switch(m){
            case 1:
                printf("Jan, ");
                break;
            case 2:
                printf("Feb, ");
                break;
            case 3:
                printf("Mar, ");
                break;
            case 4:
                printf("Apr, ");
                break;
            case 5:
                printf("May, ");
                break;
            case 6:
                printf("June, ");
                break;
            case 7:
                printf("July, ");
                break;
            case 8:
                printf("Aug, ");
                break;
            case 9:
                printf("Sep, ");
                break;
            case 10:
                printf("Oct, ");
                break;
            case 11:
                printf("Nov, ");
                break;
            case 12:
                printf("Dec, ");
                break;

    return 0;
    }

    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}

        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);

		send(clientfd, buffer, recv(clientfd, buffer, MAXBUF, 0), 0);

		/*---close connection---*/
		close(clientfd);
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}
