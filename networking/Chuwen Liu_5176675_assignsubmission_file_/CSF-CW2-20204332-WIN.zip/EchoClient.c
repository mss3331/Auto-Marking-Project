//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<ctype.h>
#include<windows.h>
#include<string.h>

#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    struct sockaddr_in self;
	int error;	
	int port=8989;
	char EC[]="exit client";
	error=WSAStartup(MAKEWORD(2,2),&wsa);
	char *ip = "127.0.0.1";
	if(error!=0)
	{
		return 0;
	}
	SOCKET s;
	s=socket(AF_INET,SOCK_STREAM,0);
	
	if(s == INVALID_SOCKET)
	{
		printf("Error code : %d\n",WSAGetLastError());
		return 0;
	}
	
	struct sockaddr_in client;
	client.sin_family = AF_INET;
	client.sin_port = htons(8989);
	client.sin_addr.s_addr = inet_addr(ip);
	

	connect(s,(struct sockaddr *)&client,sizeof(client));
	printf("Connected to Server\n");
	
	char buffer[256];
	while(1)
	{
		scanf(" %[^\n]*c",&buffer);
		if(strcmp(buffer,EC)==0)
		{
			break;
		}
		if( send(s, buffer, strlen(buffer),0)<0)	
		{
			perror("socket--send");
			exit(errno);
		}
		
		char Server_Reply[256];
		if(recv(s,Server_Reply,256, 0)<0)
		{
			perror("socket--receive");
			exit(errno);
		}
		printf("Message from Server is : %s\n", Server_Reply);
		memset(Server_Reply,0,strlen(buffer));
	
	
	}
	close(s);
	printf("Client Disconnected");
	WSACleanup();
}

	
	
