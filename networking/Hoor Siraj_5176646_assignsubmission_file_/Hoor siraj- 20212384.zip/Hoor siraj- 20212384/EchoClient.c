#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include <windows.h>
#include <string.h>
#define MY_PORT     8989
#define MAXMSG		256

int main(int argc, char *argv[]){
    WSADATA wsa;
    SOCKET sockfd;
    char message[MAXMSG]; //used as a buffer
    struct sockaddr_in client; //assigning addresses
    printf("\nInitialising Winsock...");

    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
    printf("Initialised.\n");
    //creating a socket
    if ( (sockfd = socket(AF_INET, SOCK_STREAM,0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

    printf("Socket created.\n");

    client.sin_family=AF_INET;
    client.sin_port=htons(MY_PORT);
    client.sin_addr.s_addr = inet_addr("127.0.0.1");

    //connect to server
    if (connect(sockfd,(struct sockaddr *)&client, sizeof(client))!=0){
        printf("Error with connection.");
        return 0;
    }
    printf("Connected.\n");
    while (1){
        printf("Enter a message: ");
        fgets(message, sizeof(message),stdin);//gets the message from the client
        send(sockfd,message, strlen(message),0);
        if (strcmp(message, "exit client")!=0){//terminate client when exit client written
            recv(sockfd , buffer, 256,0);
            printf("Server Message: %s \n", buffer);
        }
        else {
            printf("Disconnected.");
            close(sockfd);
            break;
        }
    }
    WSACleanup();
}
