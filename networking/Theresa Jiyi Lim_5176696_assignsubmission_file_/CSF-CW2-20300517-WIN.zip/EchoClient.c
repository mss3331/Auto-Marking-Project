//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<windows.h>
#define MY_PORT		8989
#define MAXBUF		256

int main(int argc , char *argv[])
{
	WSADATA wsa;
	SOCKET clientfd;
	struct sockaddr_in client;
	char buffer[MAXBUF],sreply[MAXBUF];
	int addrlen=sizeof(client);

	printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");
	
	/*---create streaming socket---*/
	if ((clientfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");
	
	/*---initialize address/port structure---*/
	client.sin_family = AF_INET;
	client.sin_port = htons(MY_PORT);
	client.sin_addr.s_addr = inet_addr("127.0.0.1");

	/*--- Connect to the server.---*/
    if (connect(clientfd, (struct sockaddr *)&client, addrlen) < 0)
    {
        perror("Connect()");
        exit(errno);
    }
	
	getsockname(clientfd, (struct sockaddr*)&client, &addrlen);//get port number and ip address
	printf("\nClient Name: %s\n", inet_ntoa(client.sin_addr));//points to buffer with ip address and returns string in form of "."
	printf("Client port is: %d\n", ntohs(client.sin_port));//returns in host byte order


	while(1)
	{
		memset(sreply, 0, sizeof(sreply));//clear to prevent interfering with receiving new input
		memset(buffer, 0, sizeof(buffer));
		printf("Enter message: ");//enter message
		scanf(" %[^\n]s",buffer);
		
		if (send(clientfd, buffer, sizeof(buffer), 0) < 0)
		{
			printf("Error sending message to client");
			exit(1);
		}
		
		if(strcmp("exit client",buffer)==0)
		{
			break;//break loop and terminate if exit client is entered
		}
		
		if( recv(clientfd, sreply, sizeof(sreply), 0) < 0)
		{
			printf("Error receiving server response");
			exit(1);
		}
		else
			printf("Server response: %s\n\n",sreply);
	}	
	
	/*---clean up (should never get here!)---*/
	close(clientfd);
        WSACleanup();
	return 0;
}

