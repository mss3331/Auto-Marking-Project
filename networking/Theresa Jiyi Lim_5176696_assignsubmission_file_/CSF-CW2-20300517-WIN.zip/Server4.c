//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<time.h>
#include<windows.h>
#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    struct sockaddr_in self;
	char buffer[MAXBUF];
	int MY_PORT, clientrd;
	
    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
		printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}
        printf("Socket created.\n");
	
	MY_PORT = atoi(argv[1]);//port number from cmd
	printf("Port number: %d\n",MY_PORT);
	
	/*---initialize address/port structure---*/
	self.sin_family = AF_INET;
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	
	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}
        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);
		time_t date;
		struct tm* ptr;
		
		time(&date);//returns time in seconds
		ptr = localtime(&date);//converts seconds into days months etc
		
		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);

		getpeername(clientfd, (struct sockaddr*)&client_addr, &addrlen);//get port number of socket connected to server
		printf("\nClient Name: %s\n", inet_ntoa(client_addr.sin_addr));//returns string in form of "."
		printf("Client port is: %d\n", ntohs(client_addr.sin_port));//ntohs returns in host byte order
		memset(buffer, 0, sizeof(buffer));//clear buffer for new connection
		
		while(strstr(buffer,"exit server")==NULL&&strstr(buffer,"exit client")==NULL)//exit while loop if input contains "exit server" or "exit client"
		{
			memset(buffer, 0, sizeof(buffer));//clear buffer
			clientrd = recv(clientfd,buffer,MAXBUF,0);
			if(*buffer<126&&*buffer>31)//avoid 'action' characters according to ASCII table
			{
				if(strstr(buffer, "date") != NULL)//return first occurence of the word date in string
				{
					if(strstr(buffer, "date1") != NULL)//detect date1
					{
						memset(buffer, 0, sizeof(buffer));//clear buffer to input date and time
						strftime(buffer, MAXBUF,"%Y",ptr);//formatting and storing as string
						strcat(buffer,"\r\n");//add carriage return and line feed at the end
					}
					else if(strstr(buffer, "date2") != NULL)//detect date2
					{
						memset(buffer, 0, sizeof(buffer));
						strftime(buffer, MAXBUF,"%H",ptr);
						strcat(buffer,"\r\n");
					}
					else if(strstr(buffer, "date3") != NULL)//detect date3
					{
						if(strlen(buffer)<9)//minimum length needed is 9
						{
							strcat(buffer,"abcd");
						}
						memset(buffer, 0, sizeof(buffer));
						strftime(buffer, MAXBUF,"%d-%b-%y",ptr);
						strcat(buffer,"\r\n");
					}
					else
					{
						if(strlen(buffer)<11)//minimum length needed is 11
						{
							strcat(buffer,"abcdefg");//supplement with this string so that the entire dd-mm-yy hh string can be displayed
						}
						memset(buffer, 0, sizeof(buffer));
						strftime(buffer, MAXBUF,"%d-%m-%y %H",ptr);
						strcat(buffer,"\r\n");
					}
					send(clientfd, buffer, MAXBUF, 0);
				}
				else
				{
					if(strstr(buffer,"exit server")==NULL&&strstr(buffer,"exit client")==NULL)//don't execute if input contains "exit server" or "exit client"
					{
						printf("Length of message: %d\n",strlen(buffer));
						for(int i=0;buffer[i]!='\0';i++)//change string to uppercase
						{
							if(buffer[i]>='a' && buffer[i]<='z')
							buffer[i] -= 32;
						}
						send(clientfd, buffer, MAXBUF, 0);
					}
				}
				
			}
		}
		/*---close connection---*/
		close(clientfd);
		printf("Connection with client has been terminated\n");
		if(strstr(buffer,"exit server")!=NULL)//close server window if "exit server" detected
			break;
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}

