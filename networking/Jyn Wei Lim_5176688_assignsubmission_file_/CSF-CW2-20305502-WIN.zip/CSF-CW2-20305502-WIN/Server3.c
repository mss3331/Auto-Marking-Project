//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<strings.h>
#include<time.h>
		
#define MAXBUF		1024

int main(int argc , char *argv[])
{
    int port;
    char ip_add[16];
    char exit1[100];
    char str1[]="exit server";
    char str2[]="date";
	int i=0;
    int var1,var2;
    char time[MAXBUF]={0};

    time_t tick =time(NULL);
    struct tm* time1=localtime(&tick);
    

    WSADATA wsa;
    SOCKET sockfd , clientfd;
    struct sockaddr_in self;
	char buffer[MAXBUF]={};

    printf("Start Server:");
    scanf("%d",&port);

    
	while(port!=0)
	{
    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(EXIT_SUCCESS);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(port);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0)
	{
        
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
        puts("Waiting for incoming connections...");


	/*---forever... ---*/
    struct sockaddr_in client_addr;
	int addrlen=sizeof(client_addr);
    clientfd = accept(sockfd, (struct sockaddr*) &client_addr, &addrlen);
   
    printf("IP address is: %s\n", inet_ntoa(client_addr.sin_addr));
    printf("Port number:%d \n",port);

   
    while(1)
    {
    recv(clientfd, buffer, MAXBUF, MSG_PEEK);
    if (strcmp(str1,buffer)==0)
    {
        exit(errno);
    }
    send(clientfd, strupr(buffer), recv(clientfd, buffer, MAXBUF, MSG_PEEK), 0);


    if(strncmp("exit server",buffer,11)!=0 && strncmp("date",buffer,4)!=0 )
    {
    var2=recv(clientfd, buffer, MAXBUF, 0);
    printf("Length of string:%d \n",var2-2);
    }   

    if(strncmp("date",buffer,4)==0)
    {
            strftime(time, MAXBUF, "%d-%m-%y %H", time1); // store time format in DD-MM-YY HH.
            send(clientfd,time,MAXBUF,0);
    }

    
    }


        close(clientfd);
    



	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
    
}

}