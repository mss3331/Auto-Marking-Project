//////////////////////////  Server.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>

#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self, client_addr;
	char buffer[MAXBUF];
	int port;
	port = atoi(argv[1]);

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	self.sin_port = htons(port);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;  

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}
        
	puts("Waiting for incoming connections...");

	int addrlen=sizeof(client_addr);
	
	/*changed the way of listening the socket*/
	if((clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen)) < 0) {
		perror("Error w/ server accepting connection");
		exit(1);				
	} else {
		printf("Accepted connection from: %s\n", inet_ntoa(client_addr.sin_addr));
		printf("Port Number: %d\n", port);
	}

	while (1) {
		addrlen = sizeof(client_addr);
		int recv_size = recv(clientfd, buffer, MAXBUF, 0);
		int len = strlen(buffer), i, count = 0;
		if (recv_size <= 0) { /* Only called when client receives error or client disconnected */
			if (recv_size == 0) {
				printf("Client disconnected\n");
				/* Upon client disconnecting, server waits to accept the next client */
				if ((clientfd = accept(sockfd, (struct sockaddr *)&client_addr, &addrlen)) < 0) {
					perror("Error w/ server accepting connection");
					exit(1);				
				} else {
					printf("Accepted connection from: %s\n", inet_ntoa(client_addr.sin_addr));
					printf("Port Number: %d\n", port);
				}
			} else {
				perror("Recv error:");
				return 1;				
			}
		} else { 
			/* When server received a valid reply from client */
			printf("Received message from client: %s\n", buffer);
			for(i=0 ; i<len ; i++){
					count = count+1;
				}
			printf("Length of the message from client: %d\n", count);
		}
	send(clientfd, strupr(buffer), recv_size, 0);
	memset(&buffer[0], 0, sizeof(buffer));
	}
	/*---close connection---*/
	close(clientfd);
	close(sockfd);
        WSACleanup();
	return 0;
}

