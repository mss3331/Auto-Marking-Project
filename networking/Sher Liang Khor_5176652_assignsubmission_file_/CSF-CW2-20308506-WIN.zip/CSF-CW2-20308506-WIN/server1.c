//////////////////////////  Server1.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>

#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    struct sockaddr_in self;
	struct sockaddr_in actual_address;
	int addr_size = sizeof(actual_address);
	//int port_num;
	char buffer[MAXBUF];

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");


	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET;
	//printf("Server::  About to set %hu as the port...\n", (unsigned short)strtoul(argv[1], NULL, 0));
	self.sin_port = htons(0);//htons((unsigned short)strtoul(argv[1], NULL, 0));	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY;
	//memset(&self.sin_port, '\0', sizeof(self));

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}
	//printf("Server:: About to listen on port %hu...\n", ntohs(self.sin_port));
	getsockname(sockfd, (struct sockaddr *)&actual_address, &addr_size);
	printf("The selected port is %d.\n", ntohs(actual_address.sin_port));

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}

        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{
		struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		int recv_size = recv(clientfd, buffer, MAXBUF, 0);
		if(strcmp(buffer,"exit server") == 0)
		{
			printf("Disconnected\n");
			break;
		}else{
			for(int i=0; buffer[i] != '\0' ; i++)
			{
				if(buffer[i] >= 97 && buffer[i] <= 122)
				{
					buffer[i]-=32;
				}
			}
			send(clientfd, buffer, recv_size, 0);
			printf("Modified string sent to client\n");
		}
		/*---close connection---*/
		close(clientfd);
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
    WSACleanup();
	return 0;
}
