#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>

#define MAXBUF		256

int main()
{
    WSADATA wsa;
    SOCKET client;
    struct sockaddr_in addr;
    char buffer[MAXBUF];

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

    if ( (client = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

    addr.sin_family = AF_INET;
    addr.sin_port = 8989;
    addr.sin_addr.s_addr = INADDR_ANY;

    connect(client, (struct sockaddr*)&client, sizeof client);
    printf("Enter a string: ");
    scanf("%s", buffer);

    while(1)
    {
        if(strcmp(buffer, "exit client") == 0)
        {
            break;
        }
        else
        {
            send(client, buffer, sizeof(buffer),0);
            recv(client, buffer, sizeof(buffer),0);
        }
    }
    close(client);
    WSACleanup();
	return 0;
}
