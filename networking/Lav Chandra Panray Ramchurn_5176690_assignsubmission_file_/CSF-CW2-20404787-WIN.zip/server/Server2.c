#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define MY_PORT		8989

int main(int argc , char *argv[]){

    int sockfd, ret;
    struct sockaddr_in serverAddr;

    int clientfd;
    struct sockaddr_in newAddr;

    socklen_t addr_size;

    char buffer[256];
    pid_t childpid;
   

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
     
    printf("Initialised.\n");

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if(sockfd < 0){
        printf("Error in connection.\n");
        exit(1);
    }
    printf("Socket created.\n");

    memset(&serverAddr, '\0', sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(MY_PORT	);
    serverAddr.sin_addr.s_addr = INADDR_ANY;

    ret = bind(sockfd, (struct sockaddr*)&serverAddr, sizeof(serverAddr));
    if(ret < 0){
        printf("Error in binding.\n");
        exit(1);
    }
    printf("Bind Done");

    if(listen(sockfd, 10) == 0){
        printf("Listening..\n");
    }else{
        printf("Error in binding.\n");
    }


    while(1){
        clientfd= accept(sockfd, (struct sockaddr*)&newAddr, &addr_size);
        if(clientfd < 0){
            exit(1);
        }
        printf("Connection accepted from %s:%d\n", inet_ntoa(newAddr.sin_addr), ntohs(newAddr.sin_port));

        if((childpid = fork()) == 0){
            close(sockfd);

            while(1){
                recv(clientfd, buffer, 256,0);
                if(strcmp(buffer, ":exit server ") == 0){
                    printf("Disconnected from %s:%d\n", inet_ntoa(newAddr.sin_addr), ntohs(newAddr.sin_port));
                    break;
                }else{
                    printf("Client: %s\n", buffer);
                    send(sockfd, buffer, strlen(buffer), 0);
                    bzero(buffer, sizeof(buffer));
                }
            }
        }

     }

    close(clientfd);
      WSACleanup();

    return 0;
}