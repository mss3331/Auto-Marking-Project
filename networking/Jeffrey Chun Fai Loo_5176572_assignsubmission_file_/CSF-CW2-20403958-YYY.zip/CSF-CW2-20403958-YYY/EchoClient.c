#include<io.h>
#include<stdio.h>
#include<string.h>
#include<winsock2.h>

#define MY_PORT 8989
#define MAXBUF 256

int main()
{
    WSADATA wsa;
    SOCKET clientSocket;
    struct sockaddr_in server;
    int err;
    int addrlen=sizeof(server);
    char buffer[MAXBUF];

    //Initializing Winsock...
    err=WSAStartup(MAKEWORD(2,2), &wsa);
    if (err!=0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
    printf("Initialised.\n");

    //Create socket (used to initialize connection with the server). Utilizes the socket() function.
    clientSocket=socket(AF_INET, SOCK_STREAM, 0);
    if (clientSocket==INVALID_SOCKET)
    {
        printf("Error in connection: %d",WSAGetLastError());
        exit(errno);
    }
    printf("Socket has been created.\n"); //the socket() returns a SOCKET descriptor for new socket.

    server.sin_family = AF_INET;
	server.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	server.sin_addr.s_addr = INADDR_ANY;

	//Establish a connection with the server using connect() function.
	connect(clientSocket, (struct sockaddr*)&server, addrlen);

	while (1)
    {
        scanf("%s", &buffer);
        send(clientSocket, buffer, strlen(buffer), 0); //send() function sends the input message to the server

        if (strncmp("exit client", buffer, 11)==0) //the first 11 characters of "exit client" and the buffer is compared.
        {
            close(clientSocket); //client is closed and terminated if the condition is met.
            exit(errno);
        }

        else if (recv(clientSocket, buffer, MAXBUF, 0)>0) //recv() function receives the response from server.
        {
            printf("Error! Failed to receive message.\n");
        }
        else
        {
            printf("Server response: %s\n", buffer);
        }
    }

	close(clientSocket);
	WSACleanup();
	return 0;
}
