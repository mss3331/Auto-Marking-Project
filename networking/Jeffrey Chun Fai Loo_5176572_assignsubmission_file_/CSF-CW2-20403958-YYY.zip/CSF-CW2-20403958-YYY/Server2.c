//////////////////////////  Server2.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>

#define MY_PORT     8989
#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];

	printf("Networking 1>start server %d", MY_PORT);

    while (MY_PORT!=0){
    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET; //used to designate the type of address for socket to communicate.
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY; //used when socket can be binded with any IP address.

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}

        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		if (clientfd<0)
        {
            exit(errno); //if there is no connection between the client and the server, it closes and is terminated.
        }
        printf("IP address of the client: %s\n", inet_ntoa(client_addr.sin_addr)); //inet_ntoa() function converts the internet address into a IPv4 dotted-decimal notation.
        printf("Port number targeted by the client's request: %d\n", ntohs(client_addr.sin_port)); //prints out the port number of client (each client has a different port number).

        while (1)
        {
            printf("Length of message (number of characters)= %d\n", recv(clientfd, buffer, MAXBUF, 0)); //recv() function represents the length of buffer.

            if (strncmp("exit server", buffer, 11)==0) //the first 11 characters of "exit server" and the buffer is compared.
            {
                exit(errno); //Line 81 to 84 is implementation of command "exit server".
            }
            else
            {
                send(clientfd, buffer, recv(clientfd, buffer, MAXBUF, 0), 0);
            }
        }
	}

		/*---close connection---*/
		close(clientfd);
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}

