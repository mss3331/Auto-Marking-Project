//////////////////////////  Server4.c ////////////////

#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>
#include<time.h>

#define MY_PORT     8989
#define MAXBUF		256

int main(int argc , char *argv[])
{
    WSADATA wsa;
    SOCKET sockfd , clientfd;
    	struct sockaddr_in self;
	char buffer[MAXBUF];

	printf("Networking 1>start server %d", MY_PORT);

    while (MY_PORT!=0){
    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

	/*---create streaming socket---*/
    if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		perror("Socket");
		exit(errno);
	}

        printf("Socket created.\n");

	/*---initialize address/port structure---*/
	/* bzero(&self, sizeof(self));*/
	self.sin_family = AF_INET; //used to designate the type of address for socket to communicate.
	self.sin_port = htons(MY_PORT);	  // Host to Network Short (16-bit)
	self.sin_addr.s_addr = INADDR_ANY; //used when socket can be binded with any IP address.

	/*---assign a port number to the socket---*/
    if ( bind(sockfd, (struct sockaddr*)&self, sizeof(self)) != 0 )
	{
		perror("socket--bind");
		exit(errno);
	}

        puts("Bind done");

	/*---make it a "listening socket"---*/
	if ( listen(sockfd, 20) != 0 )
	{
		perror("socket--listen");
		exit(errno);
	}

        puts("Waiting for incoming connections...");

	/*---forever... ---*/
	while (1)
	{	struct sockaddr_in client_addr;
		int addrlen=sizeof(client_addr);

		/*---accept a connection (creating a data pipe)---*/
		clientfd = accept(sockfd, (struct sockaddr*)&client_addr, &addrlen);
		if (clientfd<0)
        {
            exit(errno); //if there is no connection between the client and the server, it closes and is terminated.
        }
        printf("IP address of the client: %s\n", inet_ntoa(client_addr.sin_addr)); //inet_ntoa() function converts the internet address into a IPv4 dotted-decimal notation.
        printf("Port number targeted by the client's request: %d\n", ntohs(client_addr.sin_port)); //prints out the port number of client (each client has a different port number)

        while(1)
        {
            struct tm *currentday; //used to hold the current system date and time.
            time_t now; //stores the system time values.

            time(&now);
            currentday=localtime(&now);
            int today;

            if (strncmp("date", buffer, 5)==0) //the first 5 characters of "date" and the buffer is compared.
            {
                today=strftime(buffer, MAXBUF, "\n\r%d-%m-%y %I", currentday); //strftime() is used to format date and time. \r(ASCII code 13) and \n(ASCII code 10) are used.
                send(clientfd, buffer, today, 0);
            }
            else if (strncmp("date1", buffer, 5)==0) //the first 5 characters of "date1" and the buffer is compared. (same goes from line 97 to 106).
            {
                today=strftime(buffer, MAXBUF, "\n\r%Y", currentday);
                send(clientfd, buffer, today, 0);
            }
            else if (strncmp("date2", buffer, 5)==0)
            {
                today=strftime(buffer, MAXBUF, "\n\r%I", currentday);
                send(clientfd, buffer, today, 0);
            }
            else if (strncmp("date3", buffer, 5)==0)
            {
                today=strftime(buffer, MAXBUF, "\n\r%d-%b-%y", currentday);
                send(clientfd, buffer, today, 0);
            }
            else if (strncmp("exit server", buffer, 11)==0) //the first 11 characters of "exit server" and the buffer is compared.
            {
                exit(errno); //server is closed and terminated if conditions are met.
            }
            else
            {
                send(clientfd, buffer, recv(clientfd, buffer, MAXBUF, 0), 0); //no conditions met, sends back to client normally.
            }
        }
	}
	/*---close connection---*/
		close(clientfd);
	}

	/*---clean up (should never get here!)---*/
	close(sockfd);
        WSACleanup();
	return 0;
}
