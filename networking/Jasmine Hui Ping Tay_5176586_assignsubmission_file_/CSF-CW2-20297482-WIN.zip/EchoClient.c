////////////////////////// EchoClient.c /////////////////
#include<io.h>
#include<stdio.h>
#include<winsock2.h>
#include<string.h>

#define MAXBUF		256

int main(int argc, char *argv[]){
    WSADATA wsa;
    SOCKET sockfd;
    struct sockaddr_in server;
    int err, len, n;
    char buffer[MAXBUF];
    int MY_PORT;
    int recv_size;

    err = WSAStartup(MAKEWORD(2,2), &wsa);

    if (err != 0){
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

    sockfd = socket(AF_INET, SOCK_STREAM, 0); //s is sockfd
    if(sockfd < 0){
      perror("Socket");
      exit(1);
    }

    server.sin_family = AF_INET;
    server.sin_port = htons(MY_PORT);
    server.sin_addr.s_addr = inet_addr("127.0.0.1");
    len = sizeof(server);

    if(connect(sockfd, (struct sockaddr *)&server, len) > 0){
        printf("Connection with server failed...\n");
        exit(2);
    }

    else
        printf("Successfully connected to the server\n");

    while(1){
        memset(buffer, 0, MAXBUF);
        printf("Enter a string:\n");
        n=0;
        while((buffer[n++] = getchar()) != '\n')

           if(send(sockfd, buffer, strlen(buffer), 0) > 0){
            printf("Send failed.\n");
            return 1;
           }

            if((recv_size = recv(sockfd, buffer, MAXBUF, 0)) >0){
                printf("Receive failure...\n");
            }

            printf("Data received...\n");

            buffer[recv_size] = '\0';
            puts(buffer);

    }

    close(sockfd);
    WSACleanup();
    return 0;
}
